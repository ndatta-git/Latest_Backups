function openAddWindow(link,w,h) {
  var wind = window.open(link,"","width="+w+",height="+h+",top=20,left=20,resizable=yes,scrollbars=no");
  if (wind.opener == null)
    wind.opener = self ;
}
function openFormWindow(link1,w,h) {
  var wind=window.open(link1,"","width="+w+",height="+h+",top=20,left=20,resizable=yes,scrollbars=yes,status=yes,locationbar=yes");
  if (wind.opener == null)
    wind.opener = self ;
}

function sample_submit(){
  //submit mutliple deletes for a sample
  document.payform.cmd.value='mdel';
  document.payform.module.value='BaseTable';
  document.payform.payyear.value=document.payform.payyear1.options[document.payform.payyear1.selectedIndex].value;
  document.payform.submit();
}
 
function command_submit(theform, module, cmd, tab)
{
   theform.cmd.value=cmd;   
   theform.module.value=module;
   theform.tab.value=tab;
   theform.submit();
}

function selectAll(thecheckbox)
{
   var togglecheck = thecheckbox[thecheckbox.length-1].checked;

   for (var count = 0; count < thecheckbox.length; count++)
   {
      if (thecheckbox[count].disabled == false)
      {
         thecheckbox[count].checked = togglecheck;
      }
   }
}

function accessgroupcheck(theform, module, cmd, tab)
{
   //alert(module);
   //alert(cmd);
   //alert(tab);
   
   for (var index = 0; index < theform.addunselect.options.length; index++)
   {
      theform.addunselect.options[index].selected = true;
   }

   for (var index = 0; index < theform.addselect.options.length; index++)
   {
      theform.addselect.options[index].selected = true;
   }
  command_submit(theform, module, cmd, tab);
}

function move(fbox,tbox)
{
   for(var i=0;i<fbox.options.length;i++)
   {
      if(fbox.options[i].selected && fbox.options[i].value != '')
	   {
         var no = new Option();
         no.value = fbox.options[i].value;
         no.text = fbox.options[i].text;
         tbox.options[tbox.options.length]=no;
         fbox.options[i] = null;
         i--;
      }
   }
}

function moveall(fromlist, tolist)
{ 
  while (fromlist.options.length != 0)
  {
     var no = new Option();
     no.value = fromlist.options[0].value;
     no.text = fromlist.options[0].text;
     tolist.options[tolist.options.length]=no;
     fromlist.options[0] = null;  
  }
}

function newWin(width,height)
{
	window.open("","myNewWin","width="+width+",height="+height+",toolbar=0,resizable=yes"); 
}

function checkEmail(emailString) 
{
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(emailString))
	{
		return true;
	}
	return false;
}

function isEarlier(eday, emonth, eyear, lday, lmonth, lyear) 
{
	if(eyear == lyear) {
			if(emonth == lmonth) {
					if(eday <= lday)
		 				{return true;} 
					else 
		 				{return false;}
		    }else if(emonth < lmonth) 
		    		{return true;}
		    else {return false;}
	}else if(eyear < lyear)
			 {return true;}
	else
			 {return false;}
}


function validDate(day,month,year) 
{
	if(year.length!=4) 
		{return false;}
	if(month.length == 1)
	    {day='0'+day;}
	if(day.length == 1) 
		{day='0'+day;}
	if(isNaN(year)) 
		{return false;}
	var DayArray = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
	var MonthArray = new Array(1,2,3,4,5,6,7,8,9,10,11,12);
	var inDate = day+month+year;
	var filter = /^[0-9]{2}[0-9]{2}[0-9]{4}$/;
	
	if(!filter.test(inDate)) 
		 {return false;}
	var N = Number(year);
	if((N%4==0&& N%100!=0) || (N%400==0))
		 {DayArray[1]=29;}
	for(var i=0; i<=11; i++) 
	{
		if(MonthArray[i]==month)
			 {
			 	if(day <= DayArray[i] && day>0)
			 		 {return true;}
			 	else 
			 		 {return false;}
			 }
	}
}

function IsNumeric(sText)
{
   var ValidChars = "0123456789.";
   var IsNumber=true;
   var Char;

 
   for (i = 0; i < sText.length && IsNumber == true; i++) 
      { 
      Char = sText.charAt(i); 
      if (ValidChars.indexOf(Char) == -1) 
         {
         IsNumber = false;
         }
      }
   return IsNumber;
}

function IsSpecialCharacter(sText)
{
   var InValidChars = "'\\\";<>!@#$%^&*()";
   var IsValid=false;
   var Char;

 
   for (i = 0; i < sText.length && IsValid == true; i++) 
      { 
      Char = sText.charAt(i); 
      if (InValidChars.indexOf(Char) == 1) 
         {
         IsValid = true;
         }
      }
   return IsValid;
}

function checkDate(startDate,endDate)
{
	if(startDate>endDate)
	{
		return false;
	}
	else
	{
		return true;
	}
}
/*
var bShowslashr = false;
var bEscapegtlt = true;
function replace(str, original, replacement) {
	var result;
	result = "";
	while(str.indexOf(original) != -1) {
	if (str.indexOf(original) > 0)
		result = result + str.substring(0, str.indexOf(original)) + replacement;
		else
		result = result + replacement;
		str = str.substring(str.indexOf(original) + original.length, str.length);
	}
	return result + str;
}
function parse(text) 
{
	var strParse = text;
	strParse = replace(strParse, "\\", "\\\\");
	if (bShowslashr)
		strParse = replace(strParse, "\r", "\\r");
	else
	    strParse = replace(strParse, "\r", "");
		strParse = replace(strParse, '"', '\\"');
		strParse = replace(strParse, "'", "\\'");
		strParse = replace(strParse, "\t", "\\t");
	
	if (bEscapegtlt) 
	{
		strParse = replace(strParse, "<", "\\<");
		strParse = replace(strParse, ">", "\\>");
	}
	while(strParse.indexOf("\n") != -1)
	strParse = strParse.substring(0, strParse.indexOf("\n")) + "\\n" + strParse.substring(strParse.indexOf("\n") + 1, strParse.length);
	return strParse;
}

function showslashr(text) {
	bShowslashr = !bShowslashr;
	parse(text);
}
function escapegtlt(text) {
	bEscapegtlt = !bEscapegtlt;
	parse(text);
}
*/

var dtCh= "/";
var minYear=1900;
var maxYear=2100;

function isInteger(s){
	var i;
    for (i = 0; i < s.length; i++){   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

function stripCharsInBag(s, bag){
	var i;
    var returnString = "";
    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.
    for (i = 0; i < s.length; i++){   
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}

function daysInFebruary (year){
	// February has 29 days in any year evenly divisible by four,
    // EXCEPT for centurial years which are not also divisible by 400.
    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
}
function DaysArray(n) {
	for (var i = 1; i <= n; i++) {
		this[i] = 31
		if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
		if (i==2) {this[i] = 29}
   } 
   return this
}

function isDate(dtStr){
	var daysInMonth = DaysArray(12)
	var pos1=dtStr.indexOf(dtCh)
	var pos2=dtStr.indexOf(dtCh,pos1+1)
	var strDay=dtStr.substring(0,pos1)
	var strMonth=dtStr.substring(pos1+1,pos2)
	var strYear=dtStr.substring(pos2+1)
	strYr=strYear
	if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
	if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
	for (var i = 1; i <= 3; i++) {
		if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
	}
	month=parseInt(strMonth)
	day=parseInt(strDay)
	year=parseInt(strYr)
	if (pos1==-1 || pos2==-1){
		//alert("The date format should be : dd/mm/yyyy")
		return false
	}
	if (strMonth.length<1 || month<1 || month>12){
		//alert("Please enter a valid month")
		return false
	}
	if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
		//alert("Please enter a valid day")
		return false
	}
	if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
		//alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
		return false
	}
	if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
		//alert("Please enter a valid date")
		return false
	}
	return true
}


