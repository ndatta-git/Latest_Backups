var fontface = "Arial, Helvetica, sans-serif";
var fontsize = -1;
var gNow = new Date();
var ggWinCal;
Calendar.Months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
Calendar.Weeks = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
Calendar.DOMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
Calendar.lDOMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
function Calendar(p_item, p_WinCal, p_month, p_year, p_day) {
  if ((p_month == null) && (p_year == null)) return;
  if (p_WinCal == null)
    this.gWinCal = ggWinCal;
  else
    this.gWinCal = p_WinCal;
  this.gMonthName = Calendar.get_month(p_month);
  this.gMonth = new Number(p_month);
  this.gYear = p_year;
  this.gDay = p_day;
  this.gReturnItem = p_item;
}
Calendar.get_month = Calendar_get_month;
Calendar.get_daysofmonth = Calendar_get_daysofmonth;
Calendar.calc_month_year = Calendar_calc_month_year;
function Calendar_get_month(monthNo) {
  return Calendar.Months[monthNo];
}
function Calendar_get_daysofmonth(monthNo, p_year) {
  if ((p_year % 4) == 0) {
    if ((p_year % 100) == 0 && (p_year % 400) != 0)
      return Calendar.DOMonth[monthNo];
    return Calendar.lDOMonth[monthNo];
  }
  else
    return Calendar.DOMonth[monthNo];
}
function Calendar_calc_month_year(p_Month, p_Year, incr) {
  var ret_arr = new Array();
  if (incr == -1) {
    if (p_Month == 0) {
      ret_arr[0] = 11;
      ret_arr[1] = parseInt(p_Year) - 1;
    }
    else {
      ret_arr[0] = parseInt(p_Month) - 1;
      ret_arr[1] = parseInt(p_Year);
    }
  }
  else if (incr == 1) {
    if (p_Month == 11) {
      ret_arr[0] = 0;
      ret_arr[1] = parseInt(p_Year) + 1;
    }
    else {
      ret_arr[0] = parseInt(p_Month) + 1;
      ret_arr[1] = parseInt(p_Year);
    }
  }
  return ret_arr;
}
new Calendar();
Calendar.prototype.getMonthlyCalendarCode = function() {
  var vCode = "";
  var vHeader_Code = "";
  var vData_Code = "";
  vCode = vCode + "        <table width='245' border=0 cellspacing=0 cellpadding=0 bgcolor=#c6e1f2>\n";
  vHeader_Code = this.cal_header();
  vCode = vCode + vHeader_Code
  vCode = vCode + "        </table>\n";
  vCode = vCode + "      </td>\n";
  vCode = vCode + "    </tr>\n";
  vCode = vCode + "    <tr>\n";
  vCode = vCode + "      <td>\n";
  vCode = vCode + "        <table width='245' border=0 cellspacing=0 cellpadding=0>\n";
  vData_Code = this.cal_data();
  vCode = vCode + vData_Code;
  vCode = vCode + "\n        </table>";
  return vCode;
}
Calendar.prototype.show = function() {
  var vCode = "";
  this.gWinCal.document.open();
  this.wwrite("<html>");
  this.wwrite("<head><title>Calendar</title>");
  this.wwrite("<style type='text/css'>");
  this.wwrite("<!--");
  this.wwrite("a:active {  text-decoration: none; color: #1c4f70}");
  this.wwrite("a:hover {  text-decoration: none; color: #1c4f70}");
  this.wwrite("a:link {  text-decoration: none; color: #1c4f70}");
  this.wwrite("a:visited {  text-decoration: none; color: #1c4f70}");
  this.wwrite("-->");
  this.wwrite("</style>");
  this.wwrite("</head>");
  this.wwrite("<body>");
  this.wwrite("<table width='245' border=1 cellspacing=0 cellpadding=0 align=center bordercolor=#1c4f70>");
  this.wwrite("  <tr>");
  this.wwrite("    <td>");
  var prevMMYYYY = Calendar.calc_month_year(this.gMonth, this.gYear, -1);
  var prevMM = prevMMYYYY[0];
  var prevYYYY = prevMMYYYY[1];
  var nextMMYYYY = Calendar.calc_month_year(this.gMonth, this.gYear, 1);
  var nextMM = nextMMYYYY[0];
  var nextYYYY = nextMMYYYY[1];
  this.wwrite("        <table width='245' border=0 cellspacing=0 cellpadding=0 bgcolor='#c6e1f2'>");
  this.wwrite("          <tr>");
  this.wwrite("            <td width='25' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><a href=\"javascript:window.opener.Build('" + this.gReturnItem + "', '" + this.gMonth + "', '" + (parseInt(this.gYear)-1) + "', '" + this.gDay + "');\" alt='Prev Year'><b>&lt;&lt;</b></a></font>");
  this.wwrite("            </td>");
  this.wwrite("            <td width='20' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><a href=\"javascript:window.opener.Build('" + this.gReturnItem + "', '" + prevMM + "', '" + prevYYYY + "', '" + this.gDay + "');\" alt='Prev Month'><b>&lt;</b></a></font>");
  this.wwrite("            </td>");
  this.wwrite("            <td width='120' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><b>" + this.gMonthName + " " + this.gYear + "</b></font>");
  this.wwrite("            </td>");
  this.wwrite("            <td width='20' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><a href=\"javascript:window.opener.Build('" + this.gReturnItem + "', '" + nextMM + "', '" + nextYYYY + "', '" + this.gDay + "');\" alt='Next Month'><b>&gt;</b></a></font>");
  this.wwrite("            </td>");
  this.wwrite("            <td width='25' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><a href=\"javascript:window.opener.Build('" + this.gReturnItem + "', '" + this.gMonth + "', '" + (parseInt(this.gYear)+1) + "', '" + this.gDay + "');\" alt='Next Year'><b>&gt;&gt;</b></a></font>");
  this.wwrite("            </td>");
  this.wwrite("          </tr>");
  this.wwrite("        </table>");
  vCode = this.getMonthlyCalendarCode();
  this.wwrite(vCode);
  this.wwrite("    </td>");
  this.wwrite("  </tr>");
  this.wwrite("</table>");
  this.wwrite("</body>");
  this.wwrite("</html>");
  this.gWinCal.document.close();
}
Calendar.prototype.wwrite = function(wtext) {
  this.gWinCal.document.writeln(wtext);
}
Calendar.prototype.cal_header = function() {
  var vCode = "";
  vCode = vCode + "          <tr>\n";
  for (i=0; i<7; i++) {
    vCode = vCode + "            <td width='35' height='20' align=center><font size='" + fontsize + "' face='" + fontface + "' color='#1c4f70'><b>"+Calendar.Weeks[i]+"</b></font></td>\n";
  }
  vCode = vCode + "          </tr>\n";
  return vCode;
}
Calendar.prototype.cal_data = function() {
  var vDate = new Date();
  vDate.setDate(1);
  vDate.setMonth(this.gMonth);
  vDate.setFullYear(this.gYear);
  var vFirstDay=vDate.getDay();
  var vDay=1;
  var vLastDay=Calendar.get_daysofmonth(this.gMonth, this.gYear);
  var vOnLastDay=0;
  var vCode = "";
  vCode = vCode + "          <tr>\n";
  for (i=0; i<vFirstDay; i++) {
    vCode = vCode + "            <td width='35' height='20' align=center>&nbsp;</td>\n";
  }
  for (j=vFirstDay; j<7; j++) {
    vCode = vCode + "            <td width='35' height='20' align=center><font size='" + fontsize + "' face='" + fontface + "'><a href='#' onClick=\"self.opener.document.getElementById('" + this.gReturnItem + "').value='" + this.format_data(vDay) + "';window.close();\">" + this.format_day(vDay) + "</a></font></td>\n";
    vDay=vDay + 1;
  }
  vCode = vCode + "          </tr>\n";
  for (k=2; k<7; k++) {
    vCode = vCode + "          <tr>\n";
    for (j=0; j<7; j++) {
      vCode = vCode + "            <td width='35' height='20' align=center><font size='" + fontsize + "' face='" + fontface + "'><a href='#' onClick=\"self.opener.document.getElementById('" + this.gReturnItem + "').value='" + this.format_data(vDay) + "';window.close();\">" + this.format_day(vDay) + "</a></font></td>\n";
      vDay=vDay + 1;
      if (vDay > vLastDay) {
        vOnLastDay = 1;
        break;
      }
    }
    if (j == 7)
      vCode = vCode + "          </tr>\n";
    if (vOnLastDay == 1)
      break;
  }
  for (m=1; m<(7-j); m++) {
    vCode = vCode + "            <td width='35' height='20' align=center>&nbsp;</td>\n";
  }
  vCode = vCode + "          </tr>\n";
  for (n=k+1; n<7; n++) {
    vCode = vCode + "          <tr>\n";
    for (j=0; j<7; j++) {
      vCode = vCode + "            <td width='35' height='20' align=center>&nbsp;</td>\n";
    }
    vCode = vCode + "          </tr>\n";
  }
  return vCode;
}
Calendar.prototype.format_day = function(vday) {
  if (vday == parseInt(this.gDay))
    return ("<font color=\"red\"><b>" + vday + "</b></font>");
  else
    return ("<b>" + vday + "</b>");
}
Calendar.prototype.format_data = function(p_day) {
  var vData;
  var vMonth = 1 + this.gMonth;
  vMonth = (vMonth.toString().length < 2) ? "0" + vMonth : vMonth;
  var vY4 = new String(this.gYear);
  var vDD = (p_day.toString().length < 2) ? "0" + p_day : p_day;
  vData = vDD + "/" + vMonth + "/" + vY4;
  return vData;
}
function Build(p_item, p_month, p_year, p_day) {
  var p_WinCal = ggWinCal;
  gCal = new Calendar(p_item, p_WinCal, p_month, p_year, p_day);
  gCal.show();
}
function show_calendar(p_item) {
	show_calendar(p_item, '');
}
function show_calendar(p_item, set_year) {
  var p_obj;
  var p_D;
  var p_M;
  var p_Y;
  var p_month;
  var p_year;
  var p_day;
  var p_value;
  p_obj = eval("document.getElementById('"+p_item+"')");
  p_value = p_obj.value;
  
  if (p_value == '') {
    p_month = new String(gNow.getMonth());
    
    //Modified by James Yong
    if (set_year != '') { p_year = set_year; }
    else { p_year = new String(gNow.getFullYear().toString()); }
    
    p_day = new String(gNow.getDate());
  }
  else {
    if (p_value.length != 10 || p_value.substr(2,1) != "/" || p_value.substr(5,1) != "/" || isNaN(p_value.substr(0,2)) || isNaN(p_value.substr(3,2)) || isNaN(p_value.substr(6,4))) {
      p_month = new String(gNow.getMonth());
      p_year = new String(gNow.getFullYear().toString());
      p_day = new String(gNow.getDate());
    }
    else {
      p_D = new Number(p_value.substr(0,2));
      p_M = new Number(p_value.substr(3,2));
      p_Y = new Number(p_value.substr(6,4));
      
      //Modified by James Yong
      if (p_Y == 1) {
      	if (set_year != '') { p_Y = set_year; }
      	else {p_Y=gNow.getFullYear().toString();}
      }
      
      if (p_M >12 || p_M < 1) {
        p_month = new String(gNow.getMonth());
        p_year = new String(gNow.getFullYear().toString());
        p_day = new String(gNow.getDate());
      }
      else {
        if (p_D > Calendar.get_daysofmonth(p_M - 1, p_Y) || p_D < 1) {
          p_month = new String(gNow.getMonth());
          p_year = new String(gNow.getFullYear().toString());
          p_day = new String(gNow.getDate());
        }
        else {
          p_month = new String(p_M - 1);
          p_year = new String(p_Y);
          p_day = new String(p_D);
        }
      }
    }
  }
  vWinCal = window.open("", "Calendar", "width=270,height=190,status=no,resizable=no,top=200,left=200");
  vWinCal.opener = self;
  ggWinCal = vWinCal;
  Build(p_item, p_month, p_year, p_day);
}

function isValidateDate(p_item) {
  var p_obj;
  var p_value;
  p_obj = eval("document."+p_item);
  p_value = p_obj.value;
  if (p_value != '') {
      var strVal = p_value;
      var iYear = strVal.substr(6,4);
      var iMonth  = strVal.substr(3,2);
      var str1 = strVal.substr(2,1);
      var str2 = strVal.substr(5,1);
      var iDay = strVal.substr(0,2);
      if (isValidDate(iYear, iMonth, iDay)==false || str1!='/' || str2!='/') {
        alert('Date format(DD/MM/YYYY) expected.');
        p_obj.focus();
        return false;
      }
    }
   return true;
}
function isValidDate(iY, iM, iD) {
  var undefined
  if (iY != undefined && !isNaN(iY) && iY >=0 && iY<=9999 && iM != undefined && !isNaN(iM) && iM >=1 && iM<=12 && iD != undefined && !isNaN(iD) && iD >=1 && iD<=31) {
    if (iY<50)
      iY = 2000+iY;
    else
      if (iY<100)
        iY=1900+iY;
  if (iM == 2 && (isLeapYear(iY) && iD > 29 || !isLeapYear(iY) && iD>28) || iD == 31 && (iM<7 && iM%2==0 || iM>7 && iM%2==1))
    return false;
  else
    return true;
  }
  else
    return false;
}
function isLeapYear(iYear) {
  var undefined
  if ( iYear != undefined && !isNaN(iYear) && iYear > 0 && (iYear%4==0 && iYear%100 !=0 || iYear%400==0))
    return true;
  else
    return false;
}