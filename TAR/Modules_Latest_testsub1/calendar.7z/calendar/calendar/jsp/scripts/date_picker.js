var fontface = "Arial, Helvetica, sans-serif";
var fontsize = -1;
var gNow = new Date();
var ggWinCal;
Calendar.Months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
Calendar.Weeks = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
Calendar.DOMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
Calendar.lDOMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
function Calendar(p_item, p_WinCal, p_month, p_year, p_day,p_item2) {
  if ((p_month == null) && (p_year == null)) return;
  if (p_WinCal == null)
    this.gWinCal = ggWinCal;
  else
    this.gWinCal = p_WinCal;
  this.gMonthName = Calendar.get_month(p_month);
  this.gMonth = new Number(p_month);
  this.gYear = p_year;
  this.gDay = p_day;
  this.gReturnItem = p_item;
  this.gReturnItem2 = p_item2;
}
Calendar.get_month = Calendar_get_month;
Calendar.get_daysofmonth = Calendar_get_daysofmonth;
Calendar.calc_month_year = Calendar_calc_month_year;
function Calendar_get_month(monthNo) {
  return Calendar.Months[monthNo];
}
function Calendar_get_daysofmonth(monthNo, p_year) {
  if ((p_year % 4) == 0) {
    if ((p_year % 100) == 0 && (p_year % 400) != 0)
      return Calendar.DOMonth[monthNo];
    return Calendar.lDOMonth[monthNo];
  }
  else
    return Calendar.DOMonth[monthNo];
}

function Calendar_calc_month_year(p_Month, p_Year, incr) {
  var ret_arr = new Array();
  if (incr == -1) {
    if (p_Month == 0) {
      ret_arr[0] = 11;
      ret_arr[1] = parseInt(p_Year) - 1;
    }
    else {
      ret_arr[0] = parseInt(p_Month) - 1;
      ret_arr[1] = parseInt(p_Year);
    }
  }
  else if (incr == 1) {
    if (p_Month == 11) {
      ret_arr[0] = 0;
      ret_arr[1] = parseInt(p_Year) + 1;
    }
    else {
      ret_arr[0] = parseInt(p_Month) + 1;
      ret_arr[1] = parseInt(p_Year);
    }
  }
  return ret_arr;
}
new Calendar();
Calendar.prototype.getMonthlyCalendarCode = function() {
  var vCode = "";
  var vHeader_Code = "";
  var vData_Code = "";
  vCode = vCode + "        <table width='245' border=0 cellspacing=0 cellpadding=0 bgcolor=#c6e1f2>\n";
  vHeader_Code = this.cal_header();
  vCode = vCode + vHeader_Code
  vCode = vCode + "        </table>\n";
  vCode = vCode + "      </td>\n";
  vCode = vCode + "    </tr>\n";
  vCode = vCode + "    <tr>\n";
  vCode = vCode + "      <td>\n";
  vCode = vCode + "        <table width='245' border=0 cellspacing=0 cellpadding=0>\n";
  vData_Code = this.cal_data();
  vCode = vCode + vData_Code;
  vCode = vCode + "\n        </table>";
  return vCode;
}
Calendar.prototype.show = function() {
  var vCode = "";
  this.gWinCal.document.open();
  this.wwrite("<html>");
  this.wwrite("<head><title>Calendar</title>");
  this.wwrite("<style type='text/css'>");
  this.wwrite("<!--");
  this.wwrite("a:active {  text-decoration: none; color: #1c4f70}");
  this.wwrite("a:hover {  text-decoration: none; color: #1c4f70}");
  this.wwrite("a:link {  text-decoration: none; color: #1c4f70}");
  this.wwrite("a:visited {  text-decoration: none; color: #1c4f70}");
  this.wwrite("-->");
  this.wwrite("</style>");
  this.wwrite("</head>");
  this.wwrite("<body>");
  this.wwrite("<table width='245' border=1 cellspacing=0 cellpadding=0 align=center bordercolor=#1c4f70>");
  this.wwrite("  <tr>");
  this.wwrite("    <td>");
  var prevMMYYYY = Calendar.calc_month_year(this.gMonth, this.gYear, -1);
  var prevMM = prevMMYYYY[0];
  var prevYYYY = prevMMYYYY[1];
  var nextMMYYYY = Calendar.calc_month_year(this.gMonth, this.gYear, 1);
  var nextMM = nextMMYYYY[0];
  var nextYYYY = nextMMYYYY[1];
  this.wwrite("        <table width='245' border=0 cellspacing=0 cellpadding=0 bgcolor='#c6e1f2'>");
  this.wwrite("          <tr>");
  this.wwrite("            <td width='25' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><a href=\"javascript:window.opener.Build('" + this.gReturnItem + "', '" + this.gMonth + "', '" + (parseInt(this.gYear)-1) + "', '" + this.gDay + "','"+this.gReturnItem2+"');\" alt='Prev Year'><b>&lt;&lt;</b></a></font>");
  this.wwrite("            </td>");
  this.wwrite("            <td width='20' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><a href=\"javascript:window.opener.Build('" + this.gReturnItem + "', '" + prevMM + "', '" + prevYYYY + "', '" + this.gDay + "','"+this.gReturnItem2+"');\" alt='Prev Month'><b>&lt;</b></a></font>");
  this.wwrite("            </td>");
  this.wwrite("            <td width='120' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><b>" + this.gMonthName + " " + this.gYear + "</b></font>");
  this.wwrite("            </td>");
  this.wwrite("            <td width='20' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><a href=\"javascript:window.opener.Build('" + this.gReturnItem + "', '" + nextMM + "', '" + nextYYYY + "', '" + this.gDay + "','"+this.gReturnItem2+"');\" alt='Next Month'><b>&gt;</b></a></font>");
  this.wwrite("            </td>");
  this.wwrite("            <td width='25' height='20' align=center>");
  this.wwrite("              <font face='" + fontface + "' size='" + fontsize + "' color='#1c4f70'><a href=\"javascript:window.opener.Build('" + this.gReturnItem + "', '" + this.gMonth + "', '" + (parseInt(this.gYear)+1) + "', '" + this.gDay + "','"+this.gReturnItem2+"');\" alt='Next Year'><b>&gt;&gt;</b></a></font>");
  this.wwrite("            </td>");
  this.wwrite("          </tr>");
  this.wwrite("        </table>");
  vCode = this.getMonthlyCalendarCode();
  this.wwrite(vCode);
  this.wwrite("    </td>");
  this.wwrite("  </tr>");
  this.wwrite("</table>");
  this.wwrite("</body>");
  this.wwrite("</html>");
  this.gWinCal.document.close();
}
Calendar.prototype.wwrite = function(wtext) {
  this.gWinCal.document.writeln(wtext);
}
Calendar.prototype.cal_header = function() {
  var vCode = "";
  vCode = vCode + "          <tr>\n";
  for (i=0; i<7; i++) {
    vCode = vCode + "            <td width='35' height='20' align=center><font size='" + fontsize + "' face='" + fontface + "' color='#1c4f70'><b>"+Calendar.Weeks[i]+"</b></font></td>\n";
  }
  vCode = vCode + "          </tr>\n";
  return vCode;
}
Calendar.prototype.cal_data = function() {
  var vDate = new Date();
  vDate.setDate(1);
  vDate.setMonth(this.gMonth);
  vDate.setFullYear(this.gYear);
  var vFirstDay=vDate.getDay();
  var vDay=1;
  var vLastDay=Calendar.get_daysofmonth(this.gMonth, this.gYear);
  var vOnLastDay=0;
  var vCode = "";
  vCode = vCode + "          <tr>\n";
  for (i=0; i<vFirstDay; i++) {
    vCode = vCode + "            <td width='35' height='20' align=center>&nbsp;</td>\n";
  }
  for (j=vFirstDay; j<7; j++) {
    vCode = vCode + "            <td width='35' height='20' align=center><font size='" + fontsize + "' face='" + fontface + "'><a href='#' onClick=\"self.opener.document." + this.gReturnItem + ".value='" + this.format_data(vDay);
	vCode = vCode + "';self.opener.document." +this.gReturnItem2+ ".value='" + this.format_data(vDay);
	vCode = vCode + "';window.close();\">" + this.format_day(vDay) + "</a></font></td>\n";
    vDay=vDay + 1;
  }
  vCode = vCode + "          </tr>\n";
  for (k=2; k<7; k++) {
    vCode = vCode + "          <tr>\n";
    for (j=0; j<7; j++) {
      vCode = vCode + "            <td width='35' height='20' align=center><font size='" + fontsize + "' face='" + fontface + "'><a href='#' onClick=\"self.opener.document." + this.gReturnItem + ".value='" + this.format_data(vDay) + "';self.opener.document." +this.gReturnItem2+ ".value='" + this.format_data(vDay)+"';window.close();\">" + this.format_day(vDay) + "</a></font></td>\n";
      vDay=vDay + 1;
      if (vDay > vLastDay) {
        vOnLastDay = 1;
        break;
      }
    }
    if (j == 7)
      vCode = vCode + "          </tr>\n";
    if (vOnLastDay == 1)
      break;
  }
  for (m=1; m<(7-j); m++) {
    vCode = vCode + "            <td width='35' height='20' align=center>&nbsp;</td>\n";
  }
  vCode = vCode + "          </tr>\n";
  for (n=k+1; n<7; n++) {
    vCode = vCode + "          <tr>\n";
    for (j=0; j<7; j++) {
      vCode = vCode + "            <td width='35' height='20' align=center>&nbsp;</td>\n";
    }
    vCode = vCode + "          </tr>\n";
  }
  return vCode;
}
Calendar.prototype.format_day = function(vday) {
  if (vday == parseInt(this.gDay))
    return ("<font color=\"red\"><b>" + vday + "</b></font>");
  else
    return ("<b>" + vday + "</b>");
}
Calendar.prototype.format_data = function(p_day) {
  var vData;
  var vMonth = 1 + this.gMonth;
  vMonth = (vMonth.toString().length < 2) ? "0" + vMonth : vMonth;
  var vY4 = new String(this.gYear);
  var vDD = (p_day.toString().length < 2) ? "0" + p_day : p_day;
  vData = vDD + "/" + vMonth + "/" + vY4;
  return vData;
}
function Build(p_item, p_month, p_year, p_day,p_item2) {
  var p_WinCal = ggWinCal;
  gCal = new Calendar(p_item, p_WinCal, p_month, p_year, p_day,p_item2);
  gCal.show();
}
function show_calendar(p_item,p_item2) {
	//alert('show calendar...epayslip folder');
  var p_obj;
  var p_obj2;
  var p_D;
  var p_M;
  var p_Y;
  var p_month;
  var p_year;
  var p_day;
  var p_value;
  p_obj = eval("document."+p_item);
  p_obj2 = eval("document."+p_item2);
  
/*  var field = p_obj.name;
  var str="";
  for(int i=0; i<field.length(); i++) {
  	 var char = field.substring(i, i+1);
	 if(char >= "0" || char <= "9") 
	 	str = str+char; 	
  }
alert('str...'+str);
  var p_obj2 = eval("document.entry_form.dateOut"+str);*/
  p_value = p_obj.value;
  if (p_value == '') {
    p_month = new String(gNow.getMonth());
    p_year = new String(gNow.getFullYear().toString());
    p_day = new String(gNow.getDate());
  }
  else {
    if (p_value.length != 10 || p_value.substr(2,1) != "/" || p_value.substr(5,1) != "/" || isNaN(p_value.substr(0,2)) || isNaN(p_value.substr(3,2)) || isNaN(p_value.substr(6,4))) {
      p_month = new String(gNow.getMonth());
      p_year = new String(gNow.getFullYear().toString());
      p_day = new String(gNow.getDate());
    }
    else {
      p_D = new Number(p_value.substr(0,2));
      p_M = new Number(p_value.substr(3,2));
      p_Y = new Number(p_value.substr(6,4));
      if (p_M >12 || p_M < 1) {
        p_month = new String(gNow.getMonth());
        p_year = new String(gNow.getFullYear().toString());
        p_day = new String(gNow.getDate());
      }
      else {
        if (p_D > Calendar.get_daysofmonth(p_M - 1, p_Y) || p_D < 1) {
          p_month = new String(gNow.getMonth());
          p_year = new String(gNow.getFullYear().toString());
          p_day = new String(gNow.getDate());
        }
        else {
          p_month = new String(p_M - 1);
          p_year = new String(p_Y);
          p_day = new String(p_D);
        }
      }
    }
  }
  vWinCal = window.open("", "Calendar", "width=270,height=190,status=no,resizable=no,top=200,left=200");
  vWinCal.opener = self;
  ggWinCal = vWinCal;
  Build(p_item, p_month, p_year, p_day,p_item2);
}
