package com.iadmin.calendar.utility;

/**
 * <p>Title: LeaveAdmin 3.0</p>
 * <p>Description: Program Pattern</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: www.i-admin.com</p>
 * @author Steven Liu
 * @version 1.0
 */

public final class ParamConst {

  //Image path of leave system, i.e. defaulroot/leave/image/
  public static final String LEAVE_IMAGE_PATH = "/leave/image/";

  //suppose there are 3 roles in leaveAdmin system
  public static final String ROLE_EMP = "emp";
  public static final String ROLE_MANAGER = "manager";
  public static final String ROLE_ADMIN = "admin";
  public static final String ROLE_CONTACT = "contact";

  //WEB form commands
  public static final String CONFIRM = "confirm"; //to confirm values in a form  
  public static final String APPLY = "apply"; //to apply in a form
  public static final String EDITAPPLY = "editapply"; //to apply in a form
  public static final String EDIT = "edit"; //to update values in a form
  public static final String EDIT_ONE = "editSingle";
  public static final String EDIT_DEP = "editDep"; //Edit dependent information
  public static final String PROCESSALL = "processAll"; //to process all application
  
  public static final String EDIT_SAVE = "editsave"; //store the modification
  public static final String REAPPLY= "reapply";
  public static final String DEL = "delete"; //to delete the record
  public static final String DELETEALL = "deleteAll"; //to delete the recor
  public static final String DEL_DEP = "delDep";
  public static final String CANCEL = "cancel"; //clear all the fields
  
  public static final String VIEW = "view"; //to view values in a form
  public static final String VIEW_ONE = "viewSingle"; //to view values in a form
  public static final String VIEW_EMP = "viewEmp"; // View Employee Information
  public static final String VIEW_JOB = "viewJob"; // View Job Information
  public static final String VIEW_DEP = "viewDep"; // View Dependent Information
  public static final String EXECUTE = "execute"; //to execute values in a form
  
  public static final String DELETE = "del"; //to delete the record
  public static final String MULTI_DEL = "mdel"; //multiple deletes

  public static final String ADD = "add"; //open a window to add a new record
  public static final String ADD_DEP = "addDep";
  public static final String ADD_SAVE = "addsave"; //add the new record
  public static final String ADD_MORE = "addmore"; //add the new record and still keep the form for further addition
  
  public static final String ADD_CAL = "addcal"; //for add year details after adding a new calendar
  public static final String ADD_YEAR = "addyear"; //for add year details after adding a new calendar
  public static final String ADD_HOLIDAY = "addholiday"; //for add holidays details after adding a new year

  public static final String GENERATE_ADMIN = "generateadmin";
  public static final String GENERATE_MGR = "generatemgr";
  public static final String LOAD_SPEC = "loadspec";

  public static final String SEARCH = "search"; //search data by the filter criteria
 
   
  
  public static final String PARAMETER_MODULE = "module"; //module parameter used in servletrequest
  public static final String PARAMETER_COMMAND = "cmd"; //action of HTML form, the parameter used in servletrequest
  public static final String PARAMETER_TAB = "tab"; //tab of HTML form, the parameter used in servletrequest
  public static final String PARAMETER_LANG = "lang"; //language of HTML form, the parameter used in servletrequest
  
  	//database connect string parameters in leave.properties
  	public static final String DB_NAME = "db_name.";
  	
  	//others in leave.properties
    public static final String I18N_LANG = "i18n_lang.";
    
  	public static final String MAIL_Host = "mail_host";
  	public static final String MAIL_Charset = "mail_charset";
  	public static final String MAIL_Authentication = "mail_authentication";
  	public static final String MAIL_SenderEmail = "mail_mailSender";
    public static final String MAIL_ServerUserName = "mail_username";
    public static final String MAIL_ServerPassword = "mail_password";


  //audit log string parameters in auditlog.properties 
  public static final String AL_APPLICATION = "logapplication";
  public static final String AL_SUMMARY = "logsummary";
  public static final String AL_PURGE = "purge";
  
  //the max number of rows of one page is 10
  final public static int MAX_ROWS_PER_PAGE = 10;

  //warning messages
  final public static int MAX_ERROR_MSG_LENTH = 1200;
  
  // Tabs available
  //public static final String TAB_LOGIN = "Login";
  public static final String TAB_EMPLOYEE = "employee";
  public static final String TAB_MANAGER = "manager";
  public static final String TAB_ADMIN = "admin";
  public static final String TAB_CONTACT = "contact";
  
  // modules available. to be deleted. use ModuleConst
  public static final String MOD_LOGIN = "Login";
  public static final String MOD_EMPLOYEE_APPLICATION = "EmployeeApplication";
  public static final String MOD_EMPLOYEE_SUMMARY = "EmployeeSummary";
  public static final String MOD_MANAGER_APPROVAL = "ManagerApproval";
  public static final String MOD_ADMIN_SEARCH = "AdminSearch";
  public static final String MOD_ADMIN_ACCESS_CONTROL = "AdminAccessControl";
  
  // new stuff
  public static final String LOGIN_LOGIN = "login";
  public static final String LOGIN_LANG = "lang";
  public static final String LOGIN_LOGOUT = "logout";

  //login status
  public static final String LOGIN_USER_ID = "user_id";
  public static final String LOGIN_PASSWD = "passwd";
  public static final String LOGIN_STATUS_SUCCESS = "Login Success";
  public static final String LOGIN_STATUS_PASSWORD_ERR = "Password Error";
  public static final String LOGIN_STATUS_USERID_ERR = "UserId Error";
  
  //if id exist
  public static final String BASETABLE_DELETE_WITHOUT_CHECK = "deleteWithoutCheck";
  
  // access control
  
  //Leave Grade(ADMIN)
  public static final String ADMIN_LEAVEGRADE_MAIN = "leavegrade";
  public static final String ADMIN_LEAVEGRADE_ID = "GRADE_ID";
  public static final String ADMIN_LEAVEGRADE_NAME = "NAME";
  
  public static final String ADMIN_GRADECONF_GRD_ID = "GRD_ID";
  public static final String ADMIN_GRADECONF_LEAVE_TYPE = "LEAVE_TYPE";
  public static final String ADMIN_GRADECONF_PROBATION = "PROBATION";
  public static final String ADMIN_GRADECONF_ROUND = "ROUND";
  public static final String ADMIN_GRADECONF_CF_PCT = "CF_PCT";
  public static final String ADMIN_GRADECONF_CF_MAX = "CF_MAX";
  public static final String ADMIN_GRADECONF_MAX_LEAVE = "MAX_LEAVE";
  public static final String ADMIN_GRADECONF_YEAR_TYPE = "TYPE_LEAVE";
  public static final String ADMIN_GRADECONF_ACCRUED = "ACCRUED";
  public static final String ADMIN_GRADECONF_APPLY = "APPLY";
  public static final String ADMIN_GRADECONF_DAY_TYPE = "DAY_TYPE";
  public static final String ADMIN_GRADECONF_MAX_EARN= "MAX_EARN";
  public static final String ADMIN_GRADECONF_GENDER = "GENDER";
  public static final String ADMIN_GRADECONF_MARITAL_STATUS = "MARITAL_STATUS";
  public static final String ADMIN_GRADECONF_CHILDREN = "CHILDREN";
  public static final String ADMIN_GRADECONF_CAL_METHOD = "CAL_METHOD";
  public static final String ADMIN_GRADECONF_HR_APPROVAL = "HR_APPROVAL";

  public static final String ADMIN_GRADERULE_GRD_ID = "GRD_ID";
  public static final String ADMIN_GRADERULE_LEAVE_TYPE = "LEAVE_TYPE";
  public static final String ADMIN_GRADERULE_FROM_MTH = "FROM_MTH";
  public static final String ADMIN_GRADERULE_TO_MTH = "TO_MTH";
  public static final String ADMIN_GRADERULE_BASE_DAYS = "BASE_DAYS";
  public static final String ADMIN_GRADERULE_INCR_DAYS = "INCR_DAYS";
  public static final String ADMIN_GRADERULE_INTERVAL = "INTERVAL";

  //Employee Application(Employee)
  public static final String EMPLOYEE_DAYS_TAKEN = "daystaken";
  
  
  //Access Group(Super USer)
  public static final String SUPER_USER = "SUPER_USER";
 
}
