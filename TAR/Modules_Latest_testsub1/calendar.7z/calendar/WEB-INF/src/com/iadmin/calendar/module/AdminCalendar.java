 package com.iadmin.calendar.module;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import catalog.Catalog;
import catalog.controller.Controller;
import catalog.exception.RequestPopulationException;
import catalog.model.ValueLabelBean;
import catalog.sso.GlobalSession;
import catalog.utility.CR;
import catalog.utility.DB;
import catalog.utility.PR;

import com.iadmin.calendar.module.DTO.CalendarAddYearBean;
import com.iadmin.calendar.module.DTO.CalendarHolidayBean;
import com.iadmin.calendar.module.DTO.CalendarHolidayBeanGroup;
import com.iadmin.calendar.module.DTO.CalendarNewBean;
import com.iadmin.calendar.module.DTO.CalendarRestDayBean;
import com.iadmin.calendar.module.DTO.ExtraDaysGeneralBean;
import com.iadmin.calendar.security.UserSession;

import edu.yale.its.tp.cas.client.filter.CASFilter;



public final class AdminCalendar extends Controller
{
	private UserSession getUserSession()
	{
		return (UserSession)Catalog.getRequest().getSession().getAttribute("USER_SESSION");
	}

	/*private GlobalSession getGlobalSession(){
		return (GlobalSession)Catalog.getRequest().getSession().getAttribute("");
	}*/

	//======================
	//1. Add New Calendar ID
	//======================

	/*
	 * populate the form data into a bean
	 */
	public final CalendarNewBean customPopulator() throws RequestPopulationException
	{
		CalendarNewBean jbean = new CalendarNewBean();
		PR.populateBeanFromRequest(jbean);

		List rbean = new ArrayList();
		PR.populateListFromRequest(rbean, CalendarRestDayBean.class, "table", "rest_day");

		jbean.setRestDays(rbean);

		return jbean;
	}

	/*
	 * Go to the calendar page
	 */
	private final String Page_AddCalendar(CalendarNewBean jbean)
	{
		List rest_day_type = new ArrayList();
		rest_day_type.add(new ValueLabelBean("R", "admin.calendar.whole"));
		rest_day_type.add(new ValueLabelBean("H", "admin.calendar.half"));
		Catalog.getRequest().setAttribute("rest_day_type", rest_day_type);

		List type = new ArrayList();
		type.add(new ValueLabelBean("5.0", "5.0"));
		type.add(new ValueLabelBean("5.5", "5.5"));
		type.add(new ValueLabelBean("6.0", "6.0"));
		type.add(new ValueLabelBean("6.5", "6.5"));
		type.add(new ValueLabelBean("7.0", "7.0"));
		Catalog.getRequest().setAttribute("type", type);

		List rest_day = new ArrayList();
		rest_day.add(new ValueLabelBean("1", "admin.calendar.sunday"));
		rest_day.add(new ValueLabelBean("2", "admin.calendar.monday"));
		rest_day.add(new ValueLabelBean("3", "admin.calendar.tueday"));
		rest_day.add(new ValueLabelBean("4", "admin.calendar.wednesday"));
		rest_day.add(new ValueLabelBean("5", "admin.calendar.thursday"));
		rest_day.add(new ValueLabelBean("6", "admin.calendar.friday"));
		rest_day.add(new ValueLabelBean("7", "admin.calendar.saturday"));

		Catalog.getRequest().setAttribute("rest_day", rest_day);

		Catalog.getRequest().setAttribute("jbean", jbean);

		return "admin_calendar_add.jsp";
	}

	/*
	 * Go to page that adds new Calendar
	 */
	public String add()
	{
		return Page_AddCalendar(new CalendarNewBean());
 	}

	//when the user click on "type" dropdown in Add New Calendar page
	public String onTypeChange() throws RequestPopulationException
	{
		String checkEdit = Catalog.getRequest().getParameter("checkEdit");
		if (CR.isNN(checkEdit) && checkEdit.equals("1"))
			Catalog.getRequest().setAttribute("checkEdit","1");

		return Page_AddCalendar(customPopulator());
	}

	/**
	 * Save the data entered in the Add New Calendar page.
	 * Throw back if validation fails
	 */
	public String addSave() throws RequestPopulationException, SQLException
	{
		CalendarNewBean jbean = customPopulator();

		//==========
		//Validation
		//==========
		Vector error = jbean.validate();
		if (error.size()>0){
			Catalog.getRequest().setAttribute("FeedBackPanel", error);
			return Page_AddCalendar(jbean);
		}

		//Check calendar_id is unique.
		if (DB.exist("select * from ela_calendar where calendar_id=?", new Object[]{jbean.getCalendar_id()} )){
        	Catalog.getRequest().setAttribute("FeedBackPanel", "admin.setup.calendarIdExist");
        	return Page_AddCalendar(jbean);
        }

        //========
        //Database
        //========
		DB.insertSQL("insert into ela_audit_user values(?,sysdate)", new Object[]{getUserSession().getUserId()});

        List exclude = new ArrayList();
        exclude.add("restDays");
        DB.insertSimple(jbean, "ela_calendar", exclude);

        List restDays = jbean.getRestDays();
        String sql ="insert into ela_calendar_wke values('" + jbean.getCalendar_id() + "', ?, ?)";
        for (int i=0; i<restDays.size(); i++){
        	CalendarRestDayBean crd = (CalendarRestDayBean)restDays.get(i);
        	DB.insertSQL(sql, new Object[]{crd.getRest_day(), crd.getRest_day_type()} );
        }

        //James Yong: Goes from Step One to Step Two
        CalendarAddYearBean jbean1 = new CalendarAddYearBean();
        jbean1.setCalendar_id(jbean.getCalendar_id());
        return Page_AddYear(jbean1);
	}

	/*
	 * James Yong: Show the view for editing calendar info like description, type etc
	 */
	public final String editCalendarInfo() throws SQLException
	{
		//get the calendar id to show
		String calendar_id = Catalog.getRequest().getParameter("calendarId");

		//=========
		//Edit Mode
		//=========
		Catalog.getRequest().setAttribute("checkEdit","1");

		//==========
		//Validation
		//==========
		if (calendar_id == null) {
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.setup.calendarIsNotExist");
			return Page_AddCalendar(new CalendarNewBean());
		}

		//========
		//Database
		//========
		CalendarNewBean jbean = (CalendarNewBean) DB.selectToBean("select * from ela_calendar where calendar_id=?", new Object[]{calendar_id}, CalendarNewBean.class );


		//If no data
		if (jbean == null){
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.setup.calendarIsNotExist");
			return Page_AddCalendar(new CalendarNewBean());
		}

		List list = DB.selectToList("select * from ela_calendar_wke where calendar_id=?", new Object[]{calendar_id}, CalendarRestDayBean.class );
		if (list != null)
			jbean.setRestDays(list);

		//========
		//Callback
		//========
		return Page_AddCalendar(jbean);
	}

	public final String editCalendarInfoSave() throws RequestPopulationException, SQLException
	{
		CalendarNewBean jbean = customPopulator();

		//=========
		//Edit Mode
		//=========
		Catalog.getRequest().setAttribute("checkEdit","1");

		//==========
		//Validation
		//==========
		if (jbean.getCalendar_id()!=null && !"".equals(jbean.getCalendar_id())) {

			//========
			//Database
			//========
			DB.updateSQL("update ela_calendar ec set name=? where calendar_id=?", new Object[]{jbean.getName(), jbean.getCalendar_id()});

			/*
			//Delete before insert new
			db.deleteSQL("delete from ela_calendar_wke where calendar_id=?", jbean.getCalendar_id());
			List list = jbean.getRestDays();
			for (int i=list.size(); --i>=0; ){
				CalendarRestDayBean subBean = (CalendarRestDayBean)list.get(i);
				db.insertSQL("insert into ela_calendar_wke (calendar_id, rest_day, rest_day_type) values(?,?,?)",
					new Object[]{jbean.getCalendar_id(), subBean.getRest_day(), subBean.getRest_day_type()} );
			}*/

			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.saved");
		}

		//========
		//Callback
		//========
		return Page_AddCalendar(jbean);
	}

	//================
	//2. Add New Year
	//================
	public final String Page_AddYear(CalendarAddYearBean jbean)
	{
		//get the current year and plus 10 years to display at the year drop down list
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		List yearList = new ArrayList();
		for(int i = currentYear-2; i < currentYear+10; i++) {
			yearList.add(new ValueLabelBean(i+"", i+""));
		}
		Catalog.getRequest().setAttribute("yearList", yearList);

		Catalog.getRequest().setAttribute("jbean", jbean);

		return "admin_calendar_addYear.jsp";
	}

	public final String addYearSave() throws RequestPopulationException, SQLException
	{
		CalendarAddYearBean jbean = new  CalendarAddYearBean();
		PR.populateBeanFromRequest(jbean);

		//==========
		//Validation
		//==========
		Vector error = jbean.validate();
		if (error.size()>0){
			Catalog.getRequest().setAttribute("FeedBackPanel", error);
			return Page_AddYear(jbean);
		}

		populateYear(jbean);

		CalendarHolidayBeanGroup newbean = new CalendarHolidayBeanGroup();
		newbean.setCalendar_id(jbean.getCalendar_id());
		newbean.setYear(jbean.getYear());
		newbean.setNumberOfRecords(new Integer (5));
        return Page_AddHoliday(newbean);
	}

	private void populateYear(CalendarAddYearBean jbean) throws SQLException
	{
		List bean = DB.selectToList("select * from ela_calendar_wke where calendar_id=?",
				new Object[]{jbean.getCalendar_id()}, CalendarRestDayBean.class);

		GregorianCalendar addCalendarData = new GregorianCalendar();
		addCalendarData.set(Calendar.YEAR, Integer.parseInt(jbean.getYear()));

		//loop through every month of the year
		for (int i=0; i<12; i++)
		{
			addCalendarData.set(Calendar.MONTH,i);
			addCalendarData.set(Calendar.DATE,1);
			int daysInMonth = addCalendarData.getActualMaximum(Calendar.DATE);
			StringBuffer daysPattern = new StringBuffer(); //WWWWWRRWWWWWRR..

			//loop through every day of the month
			for(int k=1; k<=daysInMonth; k++)
			{
				addCalendarData.set(Calendar.DATE,k);
				int dayOfWeek = addCalendarData.get(Calendar.DAY_OF_WEEK);//Sun=1,Mon=2,Tues=3,Wed=4,Thurs=5,Fri=6,Sat=7

				boolean flag = false;
				for (int j=0; j<bean.size(); j++){
					CalendarRestDayBean crb = (CalendarRestDayBean)bean.get(j);
					if (crb.getRest_day().equals(dayOfWeek+"")){
						//System.out.println("Type of Rest Day:"+crb.getRest_day_type());
						daysPattern.append(crb.getRest_day_type());
						flag = true;
						break;
					}
				}

				if (flag) continue;
				daysPattern.append("W");
			}

			DB.insertSQL("insert into ela_calendar_data values(?,?,?,?)",
					new Object[]{jbean.getCalendar_id(), new Integer(jbean.getYear()), new Integer(i+1), daysPattern.toString() });
		}
	}

	//James Yong: When user wanted to add additional year to existing calendar.
	public final String addCalendarWorkYear() throws RequestPopulationException
	{
		AdminCalendarBean jbean = new AdminCalendarBean();
		PR.populateBeanFromRequest(jbean);

		//============
		//AddMore Mode
		//============
		Catalog.getRequest().setAttribute("addMore","1");

		CalendarAddYearBean jbean1 = new CalendarAddYearBean();
        jbean1.setCalendar_id(jbean.getCalendarId());
        return Page_AddYear(jbean1);
	}
	public final String addCalendarWorkYearSave() throws RequestPopulationException, SQLException
	{
		CalendarAddYearBean jbean = new  CalendarAddYearBean();
		PR.populateBeanFromRequest(jbean);

		//============
		//AddMore Mode
		//============
		Catalog.getRequest().setAttribute("addMore","1");

		//==========
		//Validation
		//==========
		Vector error = jbean.validate();
		if (error.size()>0){
			Catalog.getRequest().setAttribute("FeedBackPanel", error);
			return Page_AddYear(jbean);
		}

		//==========
		//Validation
		//==========
		if ( DB.exist("select * from ela_calendar_data where calendar_id=? and year=?", new Object[]{jbean.getCalendar_id(), new Integer(jbean.getYear()) } )) {
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.setup.yearAlreadyExist");
			return Page_AddYear(jbean);
		}

		//========
		//Database
		//========
		populateYear(jbean);

		//========
		//Callback
		//========
		Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.saved");
		return Page_AddYear(jbean);
	}

	//==================
	//3. Add New Holiday
	//==================
	public CalendarHolidayBeanGroup commonHolidayPopulator() throws RequestPopulationException
	{
		CalendarHolidayBeanGroup jbean = new CalendarHolidayBeanGroup();
		PR.populateBeanFromRequest(jbean);

		List list = new ArrayList(); //CalendarHolidayBeanGroup();
		PR.populateListFromRequest(list, CalendarHolidayBean.class, "table", "start_date" );

		jbean.setHolidayDetail(list);

		return jbean;
	}

	public final String Page_AddHoliday(CalendarHolidayBeanGroup jbean)
	{
		List records = new ArrayList();
		for (int i=1; i<=30; i++)
			records.add(new ValueLabelBean(i + "", i + ""));

		Catalog.getRequest().setAttribute("records", records);

		List nnday = new ArrayList();
		nnday.add(new ValueLabelBean("0.0", "0"));
		nnday.add(new ValueLabelBean("1.0", "1"));
		nnday.add(new ValueLabelBean("2.0", "2"));
		nnday.add(new ValueLabelBean("3.0", "3"));
		nnday.add(new ValueLabelBean("4.0", "4"));
		nnday.add(new ValueLabelBean("5.0", "5"));
		Catalog.getRequest().setAttribute("nnday", nnday);

		Catalog.getRequest().setAttribute("jbean", jbean);
		return "admin_calendar_addHolidays.jsp";
	}

	public final String onTypeChangeNumOfHoli() throws RequestPopulationException
	{
		String checkEdit = Catalog.getRequest().getParameter("checkEdit");
		if (CR.isNN(checkEdit) && checkEdit.equals("1"))
			Catalog.getRequest().setAttribute("checkEdit","1");
		return Page_AddHoliday(commonHolidayPopulator());
	}

	/**
	 * James Yong: Insert holidays info to ela_calendar_holidays. Used by more than one command.
	 */
	private final void function_insertHoliday(CalendarHolidayBeanGroup jbean) throws SQLException {

		for (int i=0; i<jbean.getNumberOfRecords().intValue(); i++)
		{
			CalendarHolidayBean subbean = (CalendarHolidayBean)jbean.getHolidayDetail().get(i);
			DB.insertSQL("insert into ela_calendar_holidays (calendar_id, start_date, description, nday) values (?, ?, ?, ?)",
				new Object[]{jbean.getCalendar_id(), subbean.getStart_date(), subbean.getDescription(), subbean.getNday()} );
		}
	}

	/**
	 * James Yong: Insert holidays info to ela_calendar_data. Used by more than one command.
	 */
	private final void function_updateCalendarWorkDays(CalendarHolidayBeanGroup jbean, boolean flag) throws SQLException {

		String login_name = (String)Catalog.getSession().getAttribute(CASFilter.CAS_FILTER_USER);
		System.out.println("LOGIN NAME ----> "+login_name);
		login_name = login_name.toUpperCase();

		GlobalSession session = new GlobalSession();
		String country_code = (String)session.getAttribute(login_name,"COUNTRY_CODE");
		char icon = ' ';
		if(country_code !=null && country_code.equals("KOR")){
			icon = 'K';
		}else{
			icon = 'P';
		}
		//2. Update ela_calendar_data
		Map daysPatternMap = DB.selectToCustomMap("select month, days  from ela_calendar_data where year=? and calendar_id=?", new Object[]{jbean.getYear(), jbean.getCalendar_id()}, "month", "days");

		//Reset any holiday entry in calendar data
		if (flag){
			//Get Rest days info
			List bean = DB.selectToList("select * from ela_calendar_wke where calendar_id=?",
					new Object[]{jbean.getCalendar_id()}, CalendarRestDayBean.class);

			Calendar cal = new GregorianCalendar(Integer.parseInt(jbean.getYear()), Calendar.JANUARY, 1);
			for (int i=1; i<=12; i++){
				cal.set(Calendar.MONTH, i-1);

				StringBuffer daysPattern = new StringBuffer().append((String)daysPatternMap.get(i+""));

				for (int j=0; j<daysPattern.length(); j++)
				{

					if (daysPattern.charAt(j) == icon)   //2011/12/27
					{
						cal.set(Calendar.DAY_OF_MONTH, j+1);//DAY_OF_MONTH

						//check if weekdays or restdays, and set accordingly
						if (bean.size()>0){
							for (Iterator iter = bean.iterator(); iter.hasNext();){
								CalendarRestDayBean crdBean = (CalendarRestDayBean)iter.next();
								//if it is a restday
								/*System.out.println(crdBean.getRest_day());
								System.out.println(cal.get(Calendar.DAY_OF_WEEK));
								System.out.println(crdBean.getRest_day_type().charAt(0));*/

								if (Integer.parseInt(crdBean.getRest_day())==cal.get(Calendar.DAY_OF_WEEK)){ //DAY_OF_WEEK
									daysPattern.setCharAt(j, crdBean.getRest_day_type().charAt(0));
									//Not a restday
								} else {
									daysPattern.setCharAt(j, 'W');
								}
							}
						} else {
							daysPattern.setCharAt(j, 'W');
						}

					}






				}
				daysPatternMap.put(i+"", daysPattern.toString());
			}
		}

		//Use to check the validity of the number of days in a month
		Calendar gc = new GregorianCalendar(
				Integer.parseInt(jbean.getYear()), Calendar.JANUARY, 1);

		for (int i = 0; i < jbean.getNumberOfRecords().intValue(); i++)
		{
			CalendarHolidayBean subBean = (CalendarHolidayBean)jbean.getHolidayDetail().get(i);
			Date date = subBean.getStart_date();
			//int year = date.getYear()+1900;
			int month = date.getMonth();
			int day = date.getDate();

			//Loop through the 12 months
			for (int k = 0; k < 12; k++){
				if (k == month){

					gc.set(Calendar.MONTH, k);
					int numOfDaysInMonth = gc.getActualMaximum(Calendar.DAY_OF_MONTH);

					//Get the days for the given month
					String dayspattern = (String)daysPatternMap.get((k+1)+"");

					//Check that the string length is correct
					if (dayspattern.length() == numOfDaysInMonth)
					{
						StringBuffer sb = new StringBuffer().append(dayspattern);

						for (int j=0; j<subBean.getNday().intValue(); j++)
						{

							if ((day+j)<=numOfDaysInMonth)
							{
								sb.setCharAt(day+j-1, icon); //2011/12/27
							} else {
							//James Yong: Crossover to next month
							//if in November or less
								if (k<11)
								{
									String dayspattern_next = (String)daysPatternMap.get((k+2)+"");
									StringBuffer sb_next = new StringBuffer().append(dayspattern_next);
									sb_next.setCharAt((day+j-1)-numOfDaysInMonth, icon);  //2011/12/27
									daysPatternMap.put((k+2)+"", sb_next.toString());
								}
							}
						}
						//return the changed values to the map
						daysPatternMap.put((k+1)+"", sb.toString());
					} else {
						System.out.println("Date doesn't correspond to the days' length in ela_calendar_data");
						throw new SQLException();
					}
				}
			}
		}

		for (int i=1; i<=12; i++ ){
			String days = (String)daysPatternMap.get(i+"");
			DB.updateSQL("update ela_calendar_data set days=? where month=? and year=? and calendar_id=?", new Object[]{days, new Integer(i), new Integer(jbean.getYear()), jbean.getCalendar_id()});
		}
	}

	public final String addHolidaySave() throws RequestPopulationException, SQLException
	{
		CalendarHolidayBeanGroup jbean = commonHolidayPopulator();

		//==========
		//Validation
		//==========
		Vector error = jbean.validate();
		if (error.size()>0){
			Catalog.getRequest().setAttribute("FeedBackPanel", error);
			return Page_AddHoliday(jbean);
		}

		//=========
		//Database
		//=========
		Connection conn = Catalog.getConnection();
		conn.setAutoCommit(false);

		try {

			function_insertHoliday(jbean);
			function_updateCalendarWorkDays(jbean, false);

			conn.commit();
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.saved");
		} catch (SQLException se){
			conn.rollback();
			System.out.println("Rollback occurs at addHolidaySave()");
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.saveFailed");
		} finally {
			conn.setAutoCommit(true);
		}

		return Page_AddHoliday(commonHolidayPopulator());
	}

	/*
	 * Allow deleting of holidays in editing mode
	 */
	public String deleteHoliday() throws RequestPopulationException, SQLException {

		String DateToDelete = Catalog.getRequest().getParameter("delete_start_date");

		return function_editHolidaySave(DateToDelete);
	}

	public final String editHolidayInfo() throws SQLException
	{
		//get the calendar id to show
		String calendar_id = Catalog.getRequest().getParameter("calendarId");
		String year = Catalog.getRequest().getParameter("year");
		String month = Catalog.getRequest().getParameter("month");


		Catalog.getRequest().setAttribute("month", month);
		//=========
		//Edit Mode
		//=========
		Catalog.getRequest().setAttribute("checkEdit","1");

		//==========
		//Validation
		//==========
		if (calendar_id == null || year == null) {
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.setup.calendarIsNotExist");
			return Page_AddCalendar(new CalendarNewBean());
		}

		CalendarHolidayBeanGroup jbean = new CalendarHolidayBeanGroup();
		jbean.setCalendar_id(calendar_id);
		jbean.setYear(year);

		//========
		//Database
		//========
		List subBeanList = DB.selectToList("select * from ela_calendar_holidays where calendar_id=? and Extract(YEAR from start_date)=?", new Object[]{calendar_id, year}, CalendarHolidayBean.class );
		if (subBeanList != null){
			jbean.setHolidayDetail(subBeanList);
			jbean.setNumberOfRecords(new Integer(subBeanList.size()));
		}

        return Page_AddHoliday(jbean);
	}

	private final String function_editHolidaySave(String DateToDelete) throws RequestPopulationException, SQLException
	{
		CalendarHolidayBeanGroup jbean = commonHolidayPopulator();

		//check if we need to remove holiday
		if (DateToDelete != null && !"".equals(DateToDelete)){
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			try {
				java.util.Date date = sdf.parse(DateToDelete);
				Date sqlDate = new Date(date.getTime());

				List holidayList = jbean.getHolidayDetail();

				for (int i=0; i<holidayList.size(); i++) {
					CalendarHolidayBean element = (CalendarHolidayBean) holidayList.get(i);
					if (element.getStart_date().equals(sqlDate)){
						holidayList.remove(i);
						int num = jbean.getNumberOfRecords().intValue();
						jbean.setNumberOfRecords(new Integer(num-1));
						break;
					}
				}
				jbean.setHolidayDetail(holidayList);
			} catch (ParseException e){   }
		} else {
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.error.cannotDeleteHoliday");
		}

		//for refreshing the opener
		String month = Catalog.getRequest().getParameter("month");

		//=========
		//Edit Mode
		//=========
		//Catalog.getRequest().setAttribute("checkEdit","1");

		//==========
		//Validation
		//==========
		Vector error = jbean.validate();
		if (error.size()>0){
			Catalog.getRequest().setAttribute("FeedBackPanel", error);
			Catalog.getRequest().setAttribute("checkEdit","1");
			return Page_AddHoliday(jbean);
		}

		//=========
		//Database
		//=========
		Connection conn = Catalog.getConnection();
		conn.setAutoCommit(false);

		try {
			//1. Delete & insert ela_calendar_holidays
			DB.deleteSQL("delete from ela_calendar_holidays where calendar_id=? and extract(year from start_date)=?", new Object[]{jbean.getCalendar_id(), jbean.getYear()} );
			function_insertHoliday(jbean);
			//2. Update ela_calendar_data
			function_updateCalendarWorkDays(jbean, true);

			conn.commit();
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.saved");
		} catch (SQLException se){
			conn.rollback();
			System.out.println("Rollback occurs at editHolidaySave()");
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.saveFailed");
		} finally {
			conn.setAutoCommit(true);
		}

		return Page_ViewCalendar(new AdminCalendarBean());
	}


	public final String editHolidaySave() throws RequestPopulationException, SQLException
	{
		return function_editHolidaySave("");
	}

	//=================
	//4. View Calandar
	//=================
	public final String Page_ViewCalendar(AdminCalendarBean jbean) throws SQLException
	{
		//List of calendar IDs
		List calendarId_List = DB.selectToList("select distinct calendar_id value, name label from ela_calendar order by calendar_id", null, ValueLabelBean.class);

		if (calendarId_List == null || calendarId_List.size() == 0){
			return "admin_calendar_empty_error.jsp";
		}

		Catalog.getRequest().setAttribute("calendarId_List", calendarId_List);

		//Give Calendar ID a value if null
		if (jbean.getCalendarId().equals("")
				&& calendarId_List != null
				&& calendarId_List.size()>0)
		{
			jbean.setCalendarId( ((ValueLabelBean)calendarId_List.get(0)).getValue() );
			//Get the corresponding description
			Catalog.getRequest().setAttribute("calendarId_Description", ((ValueLabelBean)calendarId_List.get(0)).getLabel());
		} else {
			for (int i = 0; i < calendarId_List.size(); i++){
				if ( ((ValueLabelBean)calendarId_List.get(i)).getValue().equals(jbean.getCalendarId()) ) {
					Catalog.getRequest().setAttribute("calendarId_Description", ((ValueLabelBean)calendarId_List.get(i)).getLabel());
					break;
				}
			}
		}

	   	//=================
	    //List of work days
	  	//=================
	   	List workday_list = new ArrayList();
	   	workday_list.add(new ValueLabelBean("W", "admin.calendar.header.full"));
	   	workday_list.add(new ValueLabelBean("H", "admin.calendar.header.half"));
	   	workday_list.add(new ValueLabelBean("R", "admin.calendar.header.rest"));
	   	workday_list.add(new ValueLabelBean("O", "admin.calendar.header.off"));
	   	Catalog.getRequest().setAttribute("workday_list", workday_list);

//	  List of month
		List month_list = new ArrayList();
		month_list.add(new ValueLabelBean("0", "Jan"));
		month_list.add(new ValueLabelBean("1", "Feb"));
		month_list.add(new ValueLabelBean("2", "Mar"));
		month_list.add(new ValueLabelBean("3", "Apr"));
		month_list.add(new ValueLabelBean("4", "May"));
		month_list.add(new ValueLabelBean("5", "Jun"));
		month_list.add(new ValueLabelBean("6", "Jul"));
		month_list.add(new ValueLabelBean("7", "Aug"));
		month_list.add(new ValueLabelBean("8", "Sep"));
		month_list.add(new ValueLabelBean("9", "Oct"));
		month_list.add(new ValueLabelBean("10", "Nov"));
		month_list.add(new ValueLabelBean("11", "Dec"));
		Catalog.getRequest().setAttribute("month_list", month_list);


	   	//============
		//List of year
	   	//============
		List year_list = null;
		if (!jbean.getCalendarId().equals("")){
			year_list = DB.selectToList("select distinct to_char(year) value, to_char(year) label  from ela_calendar_data where calendar_id=?", new Object[]{jbean.getCalendarId()}, ValueLabelBean.class);
		}
		Catalog.getRequest().setAttribute("year_list", year_list);
		if(year_list==null || year_list.size()<1)
		{
			Catalog.getRequest().setAttribute("nodatas","1");
			Catalog.getRequest().setAttribute("jbean", jbean);
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.nodatasetup");
			 return "admin_calendar_view.jsp";
		}
		boolean isCorrespond = false;
		for (int i = 0; i < year_list.size(); i++){
			if (  ((ValueLabelBean)year_list.get(i)).getValue().equals(jbean.getYear().intValue()+"")){
				isCorrespond = true;
				break;
			}
		}

		Calendar c  = Calendar.getInstance();
        // Get the date in day,month,year
        int year      = c.get(Calendar.YEAR);
        int month     = c.get(Calendar.MONTH);
        int day       = c.get(Calendar.DATE);
        int dayofweek = c.get(Calendar.DAY_OF_WEEK); // To get actual day in week minus 1.Sun=1, Mon=2 ..etc
		String temp = "";
		String value = "";
		// Give year a value if it doesn't have, or when it doesn't correspond
		if (year_list.size() > 0 && (jbean.getYear().intValue() == 0 || !isCorrespond) ) {
			/**
			 *  Added for calendar to display current year if the setup is done
			 */
			for(int i =0; i < year_list.size(); i++)
			{
				temp=((ValueLabelBean)year_list.get(i)).getValue();
				if(Integer.parseInt(temp)==year)
				{
					value = ((ValueLabelBean)year_list.get(i)).getValue();
					jbean.setMonth(new Integer(month));
				}

			}
			if(!CR.isNNNE(value))
			{
				value = ((ValueLabelBean)year_list.get(0)).getValue();

			}

			if (!value.equals("")) jbean.setYear( new Integer(value));
		}



		//Give month a value if it doesn't have
		if (jbean.getMonth().intValue() < 0) {
			jbean.setMonth(new Integer(0));
		}

		//Days Pattern i.e. WWWWRRWWWWWRRWWWWWRRWWWWWRRW
        String daysPattern = DB.selectToString("select days from ela_calendar_data where calendar_id =? and year=? and month =?",
        						new Object[]{jbean.getCalendarId(), jbean.getYear(), new Integer(jbean.getMonth().intValue()+1) } );

        Catalog.getRequest().setAttribute("daysPattern", daysPattern);
        if (daysPattern == null || daysPattern.length() == 0)
        	Catalog.getRequest().setAttribute("FeedBackPanel", "admin.setup.calendarIsNotExist");

       //Number of days in the month
       String arrMonthDay[] = {"31","28","31","30","31","30","31","31","30","31","30","31"};

       GregorianCalendar cal = new GregorianCalendar();
       cal.set(Calendar.YEAR, jbean.getYear().intValue());
       cal.set(Calendar.MONTH, jbean.getMonth().intValue());


       if (cal.isLeapYear(jbean.getYear().intValue()) ) arrMonthDay[1] = "29";

       //List of days for the whole month e.g : Thurs, Fri, Sat, Sun, Mon
       String arrWeekDays[]={"Sun","Mon","Tues","Wed","Thurs","Fri","Sat"};
       int getDays = Integer.parseInt(arrMonthDay[jbean.getMonth().intValue()]);   //amended by leon on 2012/8/1
   	   //get the days for the whole month
   	   String arrMonthDays[] = new String[getDays];
   	   for(int i = 0; i<getDays; i++){
   	   		cal.set(Calendar.DATE, i+1);
   	   		//the days for the whole month e.g : Thurs, Fri, Sat, Sun, Mon
   	   		arrMonthDays[i] = arrWeekDays[(cal.get(Calendar.DAY_OF_WEEK)-1)];
   	   }
   	   jbean.setArrMonth(arrMonthDays);

   	   //=============================================
   	   // Get the next bigger year for the calendar id
   	   //=============================================
   	   Integer nextBiggerYear = new Integer(0);
   	   if (!jbean.getCalendarId().equals("")){
   	   		Integer maxYear = DB.selectToInteger("select max(year) from ela_calendar_data where calendar_id=?", new Object[]{jbean.getCalendarId()} );
   	   		nextBiggerYear = new Integer(1 + maxYear.intValue());
   	   }
   	   Catalog.getRequest().setAttribute("nextBiggerYear", nextBiggerYear);

   	   //===================================================
   	   //if holiday is NOT set for the calendar for the year
   	   //===================================================
   	   if (!DB.exist("select calendar_id from ela_calendar_holidays where to_char(start_date, 'yyyy')=? and calendar_id=?",
   	   		new Object[]{jbean.getYear(), jbean.getCalendarId()}  )){
   	   		Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedbackpanel.holidaynotset");
   	   }


	   	//==============================
	    //List of holidays for the month
	  	//==============================
   	   Date datetoquery = new Date((new GregorianCalendar(jbean.getYear().intValue(), jbean.getMonth().intValue(), 1)).getTime().getTime());
   	   StringBuffer sql = new StringBuffer()
	   		.append("select * from ela_calendar_holidays ")
			.append("where calendar_id=? ")
			.append("and ( ")
			.append("( start_date>=(? - (Extract(DAY from ?)-1)) AND start_date<(LAST_DAY(?)+1) ) OR ")
			.append("( (start_date+nday-1>=(? - (Extract(DAY from ?)-1))) AND (start_date+nday-1<(LAST_DAY(?)+1)) ) ")
			.append(")");
   	   System.out.println("sql=================>"+sql.toString());
   	   System.out.println("date query"+datetoquery);
	   	List holiday_list = DB.selectToList(sql.toString(),
	   			new Object[]{jbean.getCalendarId(), datetoquery, datetoquery, datetoquery, datetoquery, datetoquery, datetoquery}, CalendarHolidayBean.class);

	    //================================
	    //Get Number of days for the month
	    //================================
	    int numOfDays = Integer.parseInt(arrMonthDay[jbean.getMonth().intValue()]);
	    int prevMonthNumOfDays = 0;
	    if (jbean.getMonth().intValue()>0){
	     	prevMonthNumOfDays = Integer.parseInt(arrMonthDay[jbean.getMonth().intValue()-1]);
	    } else {
	    	prevMonthNumOfDays = 31;
	    }

	    //================================
	    //Construct Holiday for the month
	    //================================
	    Map holidayDescriptionMap = new HashMap();
	    if (holiday_list.size() > 0){
	    	for (int i = 0; i < holiday_list.size(); i++){
	    		CalendarHolidayBean chBean = (CalendarHolidayBean)holiday_list.get(i);
	    		int date = chBean.getStart_date().getDate();

	    		//loop through the month
	    		for (int j = 1; j <= numOfDays; j++){
	    			//if start_date within same month
	    			if (jbean.getMonth().intValue() == chBean.getStart_date().getMonth()){

	    				//if within period
	    				if (
	    					(j >= date) &&
	    					(j <= (date + chBean.getNday().intValue()-1))
							){
	    					holidayDescriptionMap.put(j+"", chBean.getDescription());
	    				}
	    				//if start_date NOT within same month
	    			} else {
	    				if (j <= (date + (chBean.getNday().intValue()-1)- prevMonthNumOfDays)){
	    					holidayDescriptionMap.put(j+"", chBean.getDescription());
	    				}
	    			}
	    		}
	    	}
	    }
	    Catalog.getRequest().setAttribute("holidayDescriptionMap", holidayDescriptionMap);

	    //=============================================
	    //Get Extra Days info from ela_extraday_general
	    //=============================================
	    List extraDaysGeneral_list = new ArrayList();
	    extraDaysGeneral_list = DB.selectToList("Select * from ela_extraday_general where Extract(year from start_date)=? and calendar_id=?", new Object[]{jbean.getYear(), jbean.getCalendarId() }, ExtraDaysGeneralBean.class);
		Catalog.getRequest().setAttribute("extraDaysGeneral_list", extraDaysGeneral_list);

 	    Catalog.getRequest().setAttribute("jbean", jbean);
	    return "admin_calendar_view.jsp";
	}

	//James Yong: Save changes done in the Edit Mode
	public final String editCalendarSave() throws RequestPopulationException, SQLException
	{
		//=====================
		//Get data from request
		//=====================
		HttpServletRequest request = Catalog.getRequest();
        String[] allDaysType = request.getParameterValues("dayType");
        List dayTypeList = Arrays.asList(allDaysType);


        for (int i=0; i<dayTypeList.size(); i++){
        	System.out.print(allDaysType[i]+":");
        }

        AdminCalendarBean jbean = new AdminCalendarBean();
        PR.populateBeanFromRequest(jbean);

		//==========
		//Processing
		//==========
        String dayTypeResult = "";
        for (int i=0; i<dayTypeList.size(); i++){
            dayTypeResult = dayTypeResult + dayTypeList.get(i);
        }
        Integer Month = new Integer(jbean.getMonth().intValue() + 1);

        //========
        //Database
        //========
        String sql = "update ela_calendar_data set days=? where year=? and month=? and calendar_id=?";
        DB.updateSQL(sql, new Object[]{dayTypeResult, jbean.getYear(), Month, jbean.getCalendarId()} );

        //========
        //Callback
        //========
        return Page_ViewCalendar(jbean);
	}


	public String onChange_calendarID() throws RequestPopulationException, SQLException
	{
		AdminCalendarBean jbean = new AdminCalendarBean();
		PR.populateBeanFromRequest(jbean);

		return Page_ViewCalendar(jbean);
	}

	public String onChange_calendarMonth() throws RequestPopulationException, SQLException
	{
		AdminCalendarBean jbean = new AdminCalendarBean();
		PR.populateBeanFromRequest(jbean);

		return Page_ViewCalendar(jbean);
	}

	public String onChange_calendarYear() throws RequestPopulationException, SQLException
	{
		AdminCalendarBean jbean = new AdminCalendarBean();
		PR.populateBeanFromRequest(jbean);

		return Page_ViewCalendar(jbean);
	}

	//	James Yong: Edit which day is a halfday/fullday/publicholiday/offday
	public final String editCalendar() throws RequestPopulationException, SQLException
	{
		AdminCalendarBean jbean = new AdminCalendarBean();
		PR.populateBeanFromRequest(jbean);

		//James Yong: tells the jsp to behave in edit mode
		Catalog.getRequest().setAttribute("checkEdit","1");

		return Page_ViewCalendar(jbean);
	}

	public final String deleteCalendar() throws RequestPopulationException, SQLException
	{
		AdminCalendarBean jbean = new AdminCalendarBean();
		PR.populateBeanFromRequest(jbean);

		//==========
		//Validation
		//==========
		if ("".equals(jbean.getCalendarId()) ){
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.deletedFail");
			return Page_ViewCalendar(jbean);
		}

		//==========
		//Validation
		//==========
		Integer count = DB.selectToCount("select count(emp_calendar) from ela_job where emp_calendar=?", new Object[]{jbean.getCalendarId()} );
		System.out.println("Count:"+ count);
		if (count.intValue() > 0){
			Catalog.getRequest().setAttribute("DecisionPanel", "admin.calendar.decisionpanel.deleteCalendarWarning");
			return Page_ViewCalendar(jbean);
		}

		//========
		//Database
		//========
		//JAmes Yong; No need to prompt the user if the record is not in use by ela_job table
		function_deleteCalendar(jbean);

		return Page_ViewCalendar(new AdminCalendarBean());
	}

	//James Yong: When user clicks on NO in the decision panel
	public final String cancel() throws RequestPopulationException, SQLException
	{
		AdminCalendarBean jbean = new AdminCalendarBean();
		PR.populateBeanFromRequest(jbean);

		return Page_ViewCalendar(jbean);
	}

	//James Yong: Common function to delete the employee calendar
	private final void function_deleteCalendar(AdminCalendarBean jbean) throws SQLException
	{
		boolean autoCommitStatus = false;

		if (!"".equals(jbean.getCalendarId()))
		{
			System.out.println("Deleting Calendar: "+jbean.getCalendarId());
			try {
				autoCommitStatus = Catalog.getConnection().getAutoCommit();
				Catalog.getConnection().setAutoCommit(false);
				DB.deleteSQL("delete from ela_calendar_wke where calendar_id=?", new Object[]{jbean.getCalendarId()} );
				DB.deleteSQL("delete from ela_calendar_holidays where calendar_id=?", new Object[]{jbean.getCalendarId()} );
				DB.deleteSQL("delete from ela_calendar_data where calendar_id=?", new Object[]{jbean.getCalendarId()} );
				DB.deleteSQL("delete from ela_calendar where calendar_id=?", new Object[]{jbean.getCalendarId()} );
				Catalog.getConnection().commit();

				Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.deletedSuccess");
			} catch (SQLException se){
				Catalog.getConnection().rollback();

				System.out.println("Delete Calendar Fails");
				Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.deletedFail");
			} finally {
				Catalog.getConnection().setAutoCommit(autoCommitStatus);
			}
		}

		return;
	}

	//James Yong: When user clicks on YES in the decision panel
	public final String deleteCalendarConfirm() throws RequestPopulationException, SQLException
	{
		AdminCalendarBean jbean = new AdminCalendarBean();
		PR.populateBeanFromRequest(jbean);

		//========
		//Database
		//========
		function_deleteCalendar(jbean);

		return Page_ViewCalendar(new AdminCalendarBean());
	}

	//=============
	//5. Extra Days
	//=============
	public final String addCalendarExtraDays() throws SQLException
	{
		String calendarId = CR.nvlToBlank(Catalog.getRequest().getParameter("calendarId"));
		String year = CR.nvlToBlank(Catalog.getRequest().getParameter("year"));

		ExtraDaysGeneralBean jbean = new ExtraDaysGeneralBean();
		jbean.setCalendar_id(calendarId);
		if (CR.isNNNE(year)) jbean.setStart_date(new java.sql.Date( (new GregorianCalendar(Integer.parseInt(year),0,1)).getTime().getTime() ));

		return page_addExtraDays(jbean, year);
	}

	public final String AddCalendarExtraDays_Save() throws RequestPopulationException, SQLException
	{

		String yearString = CR.nvlToBlank(Catalog.getRequest().getParameter("year"));
		System.out.println("year "+yearString);
		int year = Integer.parseInt(yearString);
		ExtraDaysGeneralBean jbean = new ExtraDaysGeneralBean();
		PR.populateBeanFromRequest(jbean, new SimpleDateFormat("dd/MM/yyyy"));


		//==========
		//Validation
		//==========
		Vector error = jbean.validate(year);
		if (error.size()>0){
			Catalog.getRequest().setAttribute("FeedBackPanel", error);
			System.out.println("return error ");
			return page_addExtraDays(jbean, yearString);
			//return Page_ViewCalendar(new AdminCalendarBean());
			//return Page_ViewCalendar(jbean1);
		}

		//===================
		//Database Validation
		//===================
		if (DB.exist("select calendar_id from ela_extraday_general where calendar_id=? and start_date=? and leave_type=?",
				new Object[]{jbean.getCalendar_id(), jbean.getStart_date(), jbean.getLeave_type()}) ){
			Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.error.extradays.alreadyExist");
			System.out.println("DB exist ");
			return page_addExtraDays(jbean, yearString);
			//return Page_ViewCalendar(new AdminCalendarBean());
		//	return Page_ViewCalendar(jbean1);
		}

		//========
		//Database
		//========
		DB.insertSQL("insert into ela_extraday_general (calendar_id,start_date,leave_type,notes,nday) values( ?,?,?,?,?)",
				new Object[]{jbean.getCalendar_id(), jbean.getStart_date(), jbean.getLeave_type(), jbean.getNotes(), jbean.getNday()});

		Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.extradays.add.saved");
		//return page_addExtraDays(jbean, yearString); serene
		System.out.println("ibsert ");
		return Page_ViewCalendar(new AdminCalendarBean());
		//return Page_ViewCalendar(jbean1);

	}

	public final String editCalendarExtraDays() throws RequestPopulationException, SQLException
	{
		ExtraDaysGeneralBean jbean = new ExtraDaysGeneralBean();
		PR.populateBeanFromRequest(jbean);
		String year = CR.nvlToBlank(Catalog.getRequest().getParameter("year"));
		String month = CR.nvlToBlank(Catalog.getRequest().getParameter("month"));

//		get the calendar id to show

		System.out.println("id "+jbean.getCalendar_id());
		System.out.println("type "+jbean.getLeave_type());
		System.out.println("date "+jbean.getStart_date());
		ExtraDaysGeneralBean edgbean = (ExtraDaysGeneralBean)DB.selectToBean("Select * from ela_extraday_general where calendar_id=? and start_date=? and leave_type=?",
				new Object[]{jbean.getCalendar_id(), jbean.getStart_date(), jbean.getLeave_type()}, ExtraDaysGeneralBean.class);


		// tells the jsp to behave in edit mode
		Catalog.getRequest().setAttribute("checkEdit","1");
		Catalog.getRequest().setAttribute("month",month);
		/*
		System.out.println("calendar_id:" + edgbean.getCalendar_id());
		System.out.println("Leave_type:" + edgbean.getLeave_type());
		System.out.println("Start_date:" + edgbean.getStart_date());
		System.out.println("Notes:" + edgbean.getNotes());
		System.out.println("Nday:" + edgbean.getNday());
		*/
		//return page_addExtraDays(jbean, year);
		return page_addExtraDays(edgbean, year);
	//	return Page_ViewCalendar(new AdminCalendarBean());
	}

	public final String EditCalendarExtraDays_Save() throws RequestPopulationException, SQLException
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		ExtraDaysGeneralBean jbean = new ExtraDaysGeneralBean();
		PR.populateBeanFromRequest(jbean, sdf);

		AdminCalendarBean jbean1 = new AdminCalendarBean();
		PR.populateBeanFromRequest(jbean1);
		jbean1.setCalendarId(CR.nvlToBlank(Catalog.getRequest().getParameter("calendar_id")));



		String yearString = CR.nvlToBlank(Catalog.getRequest().getParameter("year"));
		int year = Integer.parseInt(yearString);

		//tells the jsp to behave in edit mode
		//Catalog.getRequest().setAttribute("checkEdit","1");

		//==========
		//Validation
		//==========
		Vector error = jbean.validate(year);
		if (error.size()>0){
			Catalog.getRequest().setAttribute("FeedBackPanel", error);
			return page_addExtraDays(jbean, yearString);
			//return Page_ViewCalendar(new AdminCalendarBean());
		}

		System.out.println("calendar_id:" + jbean.getCalendar_id());
		System.out.println("Leave_type:" + jbean.getLeave_type());
		System.out.println("Start_date:" + jbean.getStart_date());
		System.out.println("Notes:" + jbean.getNotes());
		System.out.println("Nday:" + jbean.getNday());


		DB.updateSQL("update ela_extraday_general set notes=?, nday=? where calendar_id=? and start_date=? and leave_type=?",
				new Object[]{jbean.getNotes(), jbean.getNday(), jbean.getCalendar_id(), jbean.getStart_date(), jbean.getLeave_type()});

		Catalog.getRequest().setAttribute("FeedBackPanel", "admin.calendar.feedback.extradays.add.saved");
		//return page_addExtraDays(jbean, yearString);
		return Page_ViewCalendar(jbean1);
	}

	public final String DeleteCalendarExtraDays() throws SQLException, RequestPopulationException
	{
		ExtraDaysGeneralBean jbean = new ExtraDaysGeneralBean();
		PR.populateBeanFromRequest(jbean);
		/*
		System.out.println(jbean.getCalendar_id());
		System.out.println(jbean.getLeave_type());
		System.out.println(jbean.getStart_date());
		*/
		DB.deleteSQL("delete from ela_extraday_general where calendar_id=? and start_date=? and leave_type=?",
				new Object[]{jbean.getCalendar_id(), jbean.getStart_date(), jbean.getLeave_type()});

		return Page_ViewCalendar(new AdminCalendarBean());
	}

	public final String page_addExtraDays(ExtraDaysGeneralBean jbean, String year) throws SQLException
	{
		Catalog.getRequest().setAttribute("year", year);

		//List of possible leave type
		List leaveType_list =
			DB.selectToList("select leavetype_id value, name label from ela_leavetype",
				null, ValueLabelBean.class);
		Catalog.getRequest().setAttribute("leaveType_list", leaveType_list);

		//List of number of days
		List numberOfDays_list = new ArrayList();
		/*
		 *  Edited By Vince for Extra Days option
		 */
		for(double i=0.5; i < 365.5;i=i+0.5)
		{numberOfDays_list.add(new ValueLabelBean(String.valueOf(i),String.valueOf(i)));}
		/*numberOfDays_list.add(new ValueLabelBean("2.0", "2.0"));
		numberOfDays_list.add(new ValueLabelBean("3.0", "3.0"));
		numberOfDays_list.add(new ValueLabelBean("4.0", "4.0"));
		numberOfDays_list.add(new ValueLabelBean("5.0", "5.0"));*/
		Catalog.getRequest().setAttribute("numberOfDays_list", numberOfDays_list);

		Catalog.getRequest().setAttribute("jbean", jbean);

		return "admin_calendar_extradays.jsp";
	}


    @Override
	public String execute(HttpServletRequest request,
                          HttpServletResponse response) throws SQLException
    {
    	Object obj = Catalog.getRequest().getSession().getAttribute("USER_SESSION");
    	System.out.println("object class:" + obj.getClass());

         return Page_ViewCalendar(new AdminCalendarBean());
    }

    //to replace the string for public holiday
    public String replaceCharAt(String s, int pos, String c)
    {
        pos = pos - 1;
        return s.substring(0,pos) + c + s.substring(pos+c.length());
    }

}