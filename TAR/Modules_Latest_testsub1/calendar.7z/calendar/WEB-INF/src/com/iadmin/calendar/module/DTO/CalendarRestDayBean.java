/*
 * Created on Aug 23, 2005
 */
package com.iadmin.calendar.module.DTO;

import com.iadmin.calendar.utility.Util;
/**
 * @author james.yong
 */
public class CalendarRestDayBean {
	//from 1 - 7 i.e. Monday - Sunday
	private String rest_day;
	//H=halfday, R=WholeDay
	private String rest_day_type;
	
	public String getRest_day() {
		return Util.nvlToBlank(this.rest_day);
	}
	public void setRest_day(String rest_day) {
		this.rest_day = rest_day;
	}
	public String getRest_day_type() {
		return Util.nvlToBlank(this.rest_day_type);
	}
	public void setRest_day_type(String rest_day_type) {
		this.rest_day_type = rest_day_type;
	}
}
