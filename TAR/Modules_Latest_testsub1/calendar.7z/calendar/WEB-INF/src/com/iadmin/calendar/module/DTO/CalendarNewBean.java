/*
 * Created on Aug 23, 2005
 */
package com.iadmin.calendar.module.DTO;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
/**
 * @author james.yong
 */
public class CalendarNewBean
{
	private String calendar_id;
	private String name;
	private String type;
	private List restDays; //CalendarRestDayBean
	
	public CalendarNewBean(){
		this.calendar_id="";
		this.name="";
		this.type="";
		this.restDays = new ArrayList();
	}
	
	public String getCalendar_id() {
		return this.calendar_id;
	}
	public void setCalendar_id(String calendar_id) {
		this.calendar_id = calendar_id;
	}
	
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return this.type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public List getRestDays() {
		return new ArrayList(this.restDays);
	}
	public void setRestDays(List restDays) {
		this.restDays = restDays;
	}
	
	public String restDayValue(int i) {
		if (this.restDays.size()>0 && i<this.restDays.size())
			return ((CalendarRestDayBean)this.restDays.get(i)).getRest_day();
		return "";
	}
	
	public String restDayTypeValue(int i) {
		if (this.restDays.size()>0 && i<this.restDays.size())
			return ((CalendarRestDayBean)this.restDays.get(i)).getRest_day_type();
		return "";
	}
	
	public Vector validate() {
		
		Vector error = new Vector();
		boolean x = false, y = false;
		
		if ("".equals(this.calendar_id)){
			error.add("admin.calendar.error.calendarid");
		}
		if ("".equals(this.name)){
			error.add("admin.calendar.error.description");
		}
		if ("".equals(this.type)){
			error.add("admin.calendar.error.type");
		}
		
		if (this.restDays.size()==0) return error;
		
		//check the rest day n type are filled
		for (int i=0; i<this.restDays.size(); i++){
			CalendarRestDayBean bean = ((CalendarRestDayBean)this.restDays.get(i));
			if (!x && bean.getRest_day().equals("")){
				error.add("admin.calendar.error.restday");
				x = true;
			}
			if (!y && bean.getRest_day_type().equals("")){
				error.add("admin.calendar.error.restdaytype");
				y = true;
			}
		}
		if (x==true || y==true) return error;
		
		double sum = 7;
		for (int i=0; i<this.restDays.size(); i++){
			String day = ((CalendarRestDayBean)this.restDays.get(i)).getRest_day_type();
			if ("R".equals(day)) sum -= 1;
			else if ("H".equals(day)) sum -= 0.5;
		}
		
		System.out.println("1:"+new Double(getType()).doubleValue());
		System.out.println("2:"+sum);
		
		if ( (new Double(getType()).doubleValue()) != sum ){
			error.add("admin.calendar.error.notmatched");
		}
		
		return error;
	}
	
}
