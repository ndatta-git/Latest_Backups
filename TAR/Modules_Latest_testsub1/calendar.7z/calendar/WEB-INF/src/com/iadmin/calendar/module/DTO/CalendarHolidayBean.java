/*
 * Created on Aug 26, 2005
 */
package com.iadmin.calendar.module.DTO;

import java.sql.Date;
import java.util.GregorianCalendar;

/**
 * @author james.yong
 */
public class CalendarHolidayBean
{
	private Date start_date;
	private String description;
	private Double nday;
	
	public CalendarHolidayBean()
	{
		this.start_date = new java.sql.Date( (new GregorianCalendar(1,0,1)).getTime().getTime() );
		this.description = "";
		this.nday = new Double(0.0d);
	}

	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Double getNday() {
		return this.nday;
	}
	public void setNday(Double nday) {
		this.nday = nday;
	}
	
	public Date getStart_date() {
		return this.start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
}
