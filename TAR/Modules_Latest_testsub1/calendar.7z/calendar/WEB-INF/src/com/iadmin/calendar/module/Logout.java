/*
 * Created on Jun 7, 2005
 */
package com.iadmin.calendar.module;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;

import catalog.Catalog;
import catalog.controller.Controller;
import catalog.sso.GlobalSession;
import edu.yale.its.tp.cas.client.filter.CASFilter;

/**
 * @author James.Yong
 */
public final class Logout extends Controller
{

	 //Vince: When user logs out from eLeave
	public String SSOLogOut() throws Exception
	{
		System.out.println("SSOLogout!!");
		HttpSession session = Catalog.getRequest().getSession();
		GlobalSession gsession = new GlobalSession();
		
		String login_name = (String)Catalog.getSession().getAttribute(CASFilter.CAS_FILTER_USER);
		login_name = login_name.toUpperCase();
		
		//Update database
		String logouturl=(String)gsession.getAttribute( login_name, "PORTAL_LOGOUT"); 
		System.out.println(logouturl);
		
		if (session!=null)
		{
			//Release Global Session
	 		gsession.release(login_name);
			
			//Invalidate session
			session.invalidate();

			System.out.println("Logout successfully");
			Catalog.setNewContextPath(logouturl);
			Catalog.setRedirect("");
		}
		
		return "";
    }
	
	//Vince: When user returns back Menu
	public String SSOMenu() throws Exception
	{
		String login_name = (String)Catalog.getSession().getAttribute(CASFilter.CAS_FILTER_USER);
		login_name = login_name.toUpperCase();
		
		System.out.println("SSOMenu!!");
		HttpSession session = Catalog.getRequest().getSession();

		GlobalSession gsession = new GlobalSession();
		String url = (String)gsession.getAttribute( login_name, "PORTAL_MENU" );
		String lang=(String)session.getAttribute("lang");
    	String lang1=null;
    	if(StringUtils.isNotEmpty(lang)){
			String val[]=lang.split("_");
			 lang1=val[1];
			}
			else
			{
				lang1="en";
			}
    	System.out.println("logout session:"+lang1);
    	//End here 5201
  
		// Invalidate session
	
		
		// Redirect to another module
		Catalog.setNewContextPath(url);
		Catalog.setRedirect("module=Login&lang="+lang1);
		session.invalidate();
		return "";
    }	
}
