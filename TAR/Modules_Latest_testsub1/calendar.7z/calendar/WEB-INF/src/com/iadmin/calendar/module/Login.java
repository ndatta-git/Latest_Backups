/*
 * Created on Jun 7, 2005
 */
package com.iadmin.calendar.module;

import javax.servlet.http.HttpSession;

import catalog.Catalog;
import catalog.constant.Constant;
import catalog.controller.UnSecureController;
import catalog.sso.GlobalSession;
import catalog.utility.CR;
import catalog.utility.DB;

import com.iadmin.calendar.security.UserSession;

import edu.yale.its.tp.cas.client.filter.CASFilter;

/**
 * @author James.Yong
 */
public final class Login extends UnSecureController
{
	public String SSOLogin() throws Exception {	
	
		String login_name = (String)Catalog.getSession().getAttribute(CASFilter.CAS_FILTER_USER);
		login_name = login_name.toUpperCase();
		
		//==================================
		//Perform app-related initialisation
		//==================================
		HttpSession session = Catalog.getRequest().getSession(true);
		UserSession user = new UserSession();
		session.setAttribute(Constant.USER_SESSION, user);
		session.setAttribute(Constant.SESSION_ID, session.getId());
		
		//=============
		//Get Form Data
		//=============
		GlobalSession gsession = new GlobalSession();

		String lang = (String)gsession.getAttribute(login_name, "LANG");
		if(!CR.isNNNE(lang))
		{
			lang="en";
		}

		//session.setAttribute(Constant.SESSION_LANG, jbean.getLang());
		session.setAttribute(Constant.SESSION_LANG, "i18n_" + lang);
		session.setAttribute("menulang", lang);
		
//		get the client name
		String client_name = (String)gsession.getAttribute(login_name, "CLIENT_DESC");
		System.out.println("comapny name is ==>"+client_name);
		if (CR.isNull(client_name))
		{
			client_name="";
		}
		session.setAttribute("CLIENT_DESC",client_name);
		
		String pid =(String)gsession.getAttribute(login_name,"P_ID");
		pid = pid.trim();

			//==================
			//Update UserSession
			//==================
			UserSession us = new UserSession();
			String sql = "select type from cal_user_group where id=(select cal_user_group_id from com_user_usergroup where p_id=?) ";
			String type = DB.selectToString( sql, new Object[]{ pid } );
			us.setUserType(type);
			
			StringBuffer sql_buffer = new StringBuffer()
				.append("select cuu.p_id, he.surname, he.givenname given_name from com_user_usergroup cuu, hris_emp he ")
				.append(" where cuu.p_id=? and ")
				.append(" cuu.p_id = he.p_id ");
			UserSession us_temp = (UserSession)DB.selectToBean(sql_buffer.toString(), new Object[]{ pid }, UserSession.class);

			//JY: In Calendar, Client HR will not have this info
			if( us_temp!=null ) {
				us.setLang( lang );
				us.setUserId( login_name );
				us.setP_id( pid );
				us.setSurname( us_temp.getSurname() );
				us.setGiven_name( us_temp.getGiven_name() );
			}
			
			if( !type.equalsIgnoreCase("HR"))
			{
				return "error_no_access.jsp";
			}
			
		session.setAttribute(Constant.USER_SESSION, us);
		// The Session ID is initialized by Login Module
		session.setAttribute(Constant.SESSION_ID, session.getId());
			
		Catalog.setRedirect("/catalog?module="+"AdminCalendar");
			
		return "";
	}
}
			
			

