package com.iadmin.calendar.utility;

/**
 * <p>Title: LeaveAdmin 3.0</p>
 * <p>Description: Program Pattern</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * The Util class consists of common functions for system
 * The class is been expanding during the development & support stages.
 */

import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.MessageDigest;
import java.text.StringCharacterIterator;
import java.util.Calendar;
import java.util.List;
import java.util.StringTokenizer;

public final class Util { 
	
	public static final int StringToInt(String x)
	{
		return(x.equals(""))? 0:Integer.parseInt(x);
	}

	public static final String getFullName(String given_name,String surname) {
	    
	    return given_name+" "+surname;
	}
	
  //member name: nvlToBlank,
  //funcationality: convert null string to a blank
  public static final String nvlToBlank(String a)
  {
  	return a==null?"":a;
  }

  //Member Name:getDaysOfYear
  //Functionality:get the days of a year
  public static final int getDaysOfYear(int iYear) {
    if ( (iYear % 4 == 0 && iYear % 100 != 0) || iYear % 400 == 0) {
      return 366;
    }

    return 365;

  }

  //Member Name:getCurrentYear
  //Functionality:get the current Year
  public static final String getCurrentYear() {
    Calendar c1 = Calendar.getInstance();
    String stemp = "" + c1.get(Calendar.YEAR);
    return stemp;
  }

  //Member Name:getCurrentMonth
  //Functionality:get the current Month
  public static final String getCurrentMonth() {
    Calendar c1 = Calendar.getInstance();
    /*java.util.Date d1=c1.getTime();
         SimpleDateFormat f1=new SimpleDateFormat("yyyyMMdd,EEE");
         String ftDate=f1.format(d1);
         String stemp=ftDate.substring(4,6);*/
    String stemp = "" + (c1.get(Calendar.MONTH) + 1);
    return stemp;

  }

  //Member Name:getCurrentDay
  //Functionality:get the current Day
  public static final String getCurrentDay() {
    Calendar c1 = Calendar.getInstance();
    String stemp = "" + c1.get(Calendar.DATE);
    return stemp;
  }

  //to obtain the extact value in utf-8 charset from WEB form parameters
  //iso8859-1 is used default for FORM data by servlet

  //IF HTML charset is setted by UTF-8 then,
  //HTML Form(ISO8859-1) -> Servlet.request -> Convert it to UTF-8 -> Oracle
  public static final String getWebUTF(String fmValue) throws Exception {
    return new String(fmValue.getBytes("iso8859_1"), "utf-8");
  }

  //to fetch utf-8 values from database
  //generally, can release the value to Web directly after unit test
  public static final String getDbUTF(String dbValue) throws Exception {
    // return new String(dbValue.getBytes("utf-8"),"utf-8");
    return dbValue;
  }

  //to display a string in binary hexdecimal mode.
  public static final String getHex(String v) throws Exception {
    int len = v.length();
    if (v == null || len < 1) {
      return "";
    }
    byte[] b1 = new byte[len];
    b1 = v.getBytes("utf-8");
    String stemp = "";
    for (int i = 0; i < b1.length; i++) {
      stemp += Integer.toHexString(b1[i]) + " ";
    }
    return stemp;
  }

  //Is number data?
  public static final boolean ifInteger(String value) {
    try {
      int i = Integer.parseInt(value);

    }
    catch (NumberFormatException e) {
      return false;
    }
    return true;
    //if codes in JSP only, then can try org.apache.commons.validator.GenericValidator.isFloat("200.11") just in JSP(not Servlet or Java Class)
  }

  //If the value is not integer, return 0 intead.
  public static int toInt(String value) {
    try {
      return Integer.parseInt(value);
    }
    catch (Exception e) {
      return 0;
    }
  }

  //check whether OS is UNIX or not
  public static final boolean ifUNIX() {
    String osName = java.lang.System.getProperty("os.name");
    if (osName.toLowerCase().startsWith("windows")) {
      return false;
    }

    return true;

  }

  private final static String[] hexDigits = {
      "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e",
      "f"};

  private static String byteArrayToHexString(byte[] b) {
    StringBuffer resultSb = new StringBuffer();
    for (int i = 0; i < b.length; i++) {
      resultSb.append(byteToHexString(b[i]));
    }
    return resultSb.toString();
  }

  private static String byteToHexString(byte b) {
    int n = b;
    if (n < 0) {
      n = 256 + n;
    }
    int d1 = n / 16;
    int d2 = n % 16;
    return hexDigits[d1] + hexDigits[d2];
  }

  //encryt information by MD5 method
  public static String MD5Encode(String origin) {
    String resultString = null;
    try {
      resultString = new String(origin);
      MessageDigest md = MessageDigest.getInstance("MD5");
      resultString =
          byteArrayToHexString(md.digest(resultString.getBytes()));
    }
    catch (Exception ex) {
    }
    return resultString;
  }

  /**
   * Returns an Exception stack trace as a string.
   */
  public static String getStackTrace(Throwable e) {
    StringWriter stackTrace = new StringWriter();
    PrintWriter stackStringWriter = new PrintWriter(stackTrace);
    e.printStackTrace(stackStringWriter);
    String rt = stackTrace.toString();
    try {
      stackStringWriter.close();
      stackTrace.close();
    }
    catch (Exception ex) {}
    return (rt);
  }

  /**
   * Returns an Exception stack trace as a string.
   */
  public static String getShortenStackTrace(Throwable e) {
    StringWriter stackTrace = new StringWriter();
    PrintWriter stackStringWriter = new PrintWriter(stackTrace);
    e.printStackTrace(stackStringWriter);
    String rt = stackTrace.toString();
    String tmp = "";
    if (rt.length() > ParamConst.MAX_ERROR_MSG_LENTH) {
      tmp = rt.substring(0, ParamConst.MAX_ERROR_MSG_LENTH);
      rt = tmp;
    }
    try {
      stackStringWriter.close();
      stackTrace.close();
    }
    catch (Exception ex) {}
    return rt;
  }

  //Just retrieve the list to display on web page
  public static List getShownRows(List allRows, int dockPage, int totalRows) throws
      Exception {
    //total records in last page
    int recRemainder = totalRows % ParamConst.MAX_ROWS_PER_PAGE;
    //all pages
    int pageTabs = totalRows / ParamConst.MAX_ROWS_PER_PAGE +
        (recRemainder > 0 ? 1 : 0);
    //total records in the current display page
    int recDockPage = ParamConst.MAX_ROWS_PER_PAGE;

    if (pageTabs < dockPage || dockPage < 1 || totalRows < 1) {
      return allRows;
    }
    else {
      //last page selected or only one page
      if (dockPage == pageTabs) {
        recDockPage = recRemainder;
      }
      if (pageTabs == 1) {
        recDockPage = totalRows;
      }
      List tmpList = allRows.subList( (dockPage - 1) *
                                     ParamConst.MAX_ROWS_PER_PAGE,
                                     (dockPage - 1) *
                                     ParamConst.MAX_ROWS_PER_PAGE + recDockPage);
      return tmpList;
    }
  }

  //member name: toNBSP,
  //funcationality: convert null Object to a blank
  public static final Object toNBSP(Object a) {
    String tmp = "&nbsp;";
    if (a == null) {
      return tmp;
    }
    return a;
  }
  
  //for String tokenizer
  public static String [] StringTokenizer(String stringData, String token){        
      int i=0;
      
      StringTokenizer st = new StringTokenizer(stringData,token);
      int countTokens = st.countTokens();   
      String arrResult[]=new String[countTokens];
      
      while (st.hasMoreTokens()) { 
          arrResult[i]=st.nextToken();
          i++;
      }         
      return arrResult;
  }


  public static String forRegex(String aRegexFragment){
    final StringBuffer result = new StringBuffer();

    final StringCharacterIterator iterator = new StringCharacterIterator(aRegexFragment);
    char character =  iterator.current();
    while (character != StringCharacterIterator.DONE ){
      /*
      * All literals need to have backslashes doubled.
      */
      /*if (character == '.') {
        result.append("\\.");
      }
      else*/ 
      if (character == '\\') {
        result.append("\\\\");
      }/*
      else if (character == '?') {
        result.append("\\?");
      }
      else if (character == '*') {
        result.append("\\*");
      }
      else if (character == '+') {
        result.append("\\+");
      }
      else if (character == '&') {
        result.append("\\&");
      }
      else if (character == ':') {
        result.append("\\:");
      }
      else if (character == '{') {
        result.append("\\{");
      }
      else if (character == '}') {
        result.append("\\}");
      }
      else if (character == '[') {
        result.append("\\[");
      }
      else if (character == ']') {
        result.append("\\]");
      }
      else if (character == '(') {
        result.append("\\(");
      }
      else if (character == ')') {
        result.append("\\)");
      }
      else if (character == '^') {
        result.append("\\^");
      }
      else if (character == '$') {
        result.append("\\$");
      }*/
      else if (character == '"') {
        result.append("\"");
      }
      else if (character == '\'') {
        result.append("\'");
      }
      else {
        //the char is not a special one
        //add it to the result as is
        result.append(character);
      }
      character = iterator.next();
    }
    return result.toString();
  }

  
  //The main() can do some unit tests as well if Junit hasn't been installed.
  public static void main(String[] args) throws Exception {
    System.out.println(Util.getCurrentYear());
    System.err.println(MD5Encode("a")); //MD5 ("a") = 0cc175b9c0f1b6a831c399e269772661
  }

}