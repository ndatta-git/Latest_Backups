/*
 * Created on Sep 21, 2005
 */
package com.iadmin.calendar.module.DTO;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.Vector;
/**
 */
public class ExtraDaysGeneralBean
{
	private String calendar_id;
	private Date start_date;
	private String leave_type;
	private String notes;
	private Double nday;
	
	public ExtraDaysGeneralBean(){
		this.calendar_id = "";
		this.start_date = new java.sql.Date( (new GregorianCalendar(1,0,1)).getTime().getTime() );
		this.leave_type = "";
		this.notes = "";
		this.nday = new Double(0);
	}

	public String getCalendar_id() {
		return this.calendar_id;
	}
	public void setCalendar_id(String calendar_id) {
		this.calendar_id = calendar_id;
	}
	public String getLeave_type() {
		return this.leave_type;
	}
	public void setLeave_type(String leave_type) {
		this.leave_type = leave_type;
	}
	public Double getNday() {
		return this.nday;
	}
	public void setNday(Double nday) {
		this.nday = nday;
	}
	public String getNotes() {
		return this.notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public Date getStart_date() {
		return this.start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	
	public String getStart_date_String() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(getStart_date());
	}
	
	public Vector validate(int year) {
		
		Vector error = new Vector();
		
		if ("".equals(getCalendar_id())){
			error.add("admin.calendar.error.extradays.calendar_id");
		}
		if ( (getStart_date().getYear()+1900) != year ){
			error.add("admin.calendar.error.extradays.start_date");
		}
		if ("".equals(getLeave_type())){
			error.add("admin.calendar.error.extradays.leave_type");
		}
		if ("".equals(getNotes())){
			error.add("admin.calendar.error.extradays.notes");
		}
		if ("".equals(getNday())){
			error.add("admin.calendar.error.extradays.nday");
		}
		
		return error;
	}
}
