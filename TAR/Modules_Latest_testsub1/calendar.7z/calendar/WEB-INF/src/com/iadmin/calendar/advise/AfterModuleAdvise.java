/*
 * Created on Aug 25, 2005
 */
package com.iadmin.calendar.advise;


import catalog.Catalog;
import catalog.events.IAdvise;
import catalog.utility.CR;

import com.iadmin.calendar.security.UserSession;
import com.iadmin.calendar.utility.ParamConst;

/**
 * @author james.yong
 */
public class AfterModuleAdvise implements IAdvise {
	
	private final static String ADMIN_NAVBAR_JSP = "common/admin_navbar.jsp";
	private final static String MANAGER_NAVBAR_JSP = "common/manager_navbar.jsp";
	private final static String EMP_NAVBAR_JSP = "common/employee_navbar.jsp";
	private final static String ADMINSETUP = "Admin_setup";

	public UserSession getUserSession()
	{
		return (UserSession)Catalog.getRequest().getSession().getAttribute("USER_SESSION");
	}
	
	public void execute()
	{
		//Prepares the tab info
		String tab = "";
		
		String nextBody = "";
		String nextSubMenu = "";
		String nextMenuItem = "";
		
		String nextPage = Catalog.getNextPage();
		
		if (nextPage != null && !nextPage.equals("")){
  			
			if (nextPage.startsWith("admin_")){
				
				if (nextPage.equals("admin_calendar_view.jsp")) {
  	  				nextSubMenu = ADMIN_NAVBAR_JSP;
  	  				nextMenuItem= ADMINSETUP;
  	  			}
  	  			else if (nextPage.equals("admin_calendar_empty_error.jsp")) {
  	  				nextSubMenu = ADMIN_NAVBAR_JSP;
  	  				nextMenuItem= ADMINSETUP;
  	  			}
  	  			else if (nextPage.equals("admin_calendar_add.jsp")) {
  	  				nextSubMenu = ADMIN_NAVBAR_JSP;
  	  				nextMenuItem= ADMINSETUP;
  	  			}
  	  			else if (nextPage.equals("admin_calendar_addHolidays.jsp")) {
  	  				nextSubMenu = ADMIN_NAVBAR_JSP;
  	  				nextMenuItem= ADMINSETUP;
  	  			}
  	  			else if (nextPage.equals("admin_calendar_addYear.jsp")) {
  	  				nextSubMenu = ADMIN_NAVBAR_JSP;
  	  				nextMenuItem= ADMINSETUP;
  	  			}
  	  			else if (nextPage.equals("admin_calendar_extradays.jsp")) {
  	  				nextSubMenu = ADMIN_NAVBAR_JSP;
  	  				nextMenuItem= ADMINSETUP;
  	  			}

			} 
  			
			nextBody = nextPage;
			
  			//generate tab info
  			if ( nextSubMenu.equals( EMP_NAVBAR_JSP ) ){
  				tab = ParamConst.TAB_EMPLOYEE;
  			} 
  			else if ( nextSubMenu.equals( MANAGER_NAVBAR_JSP ) ){
  				tab = ParamConst.TAB_MANAGER;
  			} 
  			else if ( nextSubMenu.equals( ADMIN_NAVBAR_JSP ) ){
  				tab = ParamConst.TAB_ADMIN;
  			}
  			
  			Catalog.getRequest().setAttribute("tab", tab);
  			
  			//=====================
  			//Simple Access Control
  			//=====================
  			String group_type = "";

  			UserSession us = getUserSession();
  			group_type = us.getUserType();

  			System.out.println("tab:" + tab + " / " + "group_type:" + group_type);
  			
			boolean error = false;
  			if ( CR.isNNNE(group_type) ){
  				if (tab == ParamConst.TAB_MANAGER) {
  					if (group_type.equalsIgnoreCase("EMP")) error = true;
  				} else if (tab == ParamConst.TAB_ADMIN) {
  					if ( group_type.equalsIgnoreCase("EMP") || group_type.equalsIgnoreCase("MGR") ) error = true;
   				}
  			}
  			//Will not check for those pages that don't have tab info
  			if (!"".equals(tab) && (error || "".equals(group_type))){
  				nextSubMenu = "";
  				Catalog.setNextPage("com_warning.jsp");
  				Catalog.getRequest().getSession().setAttribute("ERROR_MESSAGE", "You do not have sufficient Permission to access this page");
  			}
  			
  			System.out.println("Next Page: "+nextBody);
  			if (!nextSubMenu.equals("")) {
  				Catalog.setNextPage("BaseLayout.jsp");
  				Catalog.getRequest().setAttribute("nextSubMenu", nextSubMenu);
  				Catalog.getRequest().setAttribute("nextBody", nextBody);
  				Catalog.getRequest().setAttribute("nextMenuItem", nextMenuItem);
  			}
  		}
	}
}
