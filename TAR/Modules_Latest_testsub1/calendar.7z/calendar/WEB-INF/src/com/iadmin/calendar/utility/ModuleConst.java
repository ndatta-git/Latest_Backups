/*
 * Created on Jun 27, 2005
 */
package com.iadmin.calendar.utility;

/**
 * @author Terry.Tan
 */
public final class ModuleConst
{
	public static final String LOGIN = "Login";
	public static final String ADMIN_EMPMANAGEMENT = "AdminEmpManagement";
	public static final String ADMIN_EMPAPPLICATION = "AdminEmpApplication";
	public static final String ADMIN_LEAVEMANAGEMENT = "AdminLeaveManagement";
	public static final String ADMIN_ACCESSCONTROL = "AdminAccessControl";
	public static final String ADMIN_APPROVAL = "AdminApproval";
	public static final String ADMIN_LEAVEGRADE = "AdminLeaveGrade";
	public static final String ADMIN_ACCESSGROUP = "AdminAccessGroup";
	public static final String ADMIN_USERGROUP = "AdminUserGroup";	
	public static final String ADMIN_BASETABLE = "AdminBaseTable";
	public static final String ADMIN_CALENDAR = "AdminCalendar";
	public static final String ADMIN_REPORT = "AdminReport";
	public static final String ADMIN_AUDITREPORT = "AdminAuditReport";
	public static final String ADMIN_AUDIT = "AdminAudit";
	public static final String ADMIN_WEBACCESS = "AdminWebAccess";
	public static final String ADMIN_LEAVEBALANCE = "AdminLeaveBalance";
	public static final String ADMIN_UPLOAD = "AdminUpload";
   
	public static final String MANAGER_APPROVAL = "ManagerApproval";
    
	public static final String EMPLOYEE_SUMMARY = "EmployeeSummary";
	public static final String EMPLOYEE_APPLICATION = "EmployeeApplication";
	public static final String EMPLOYEE_LEAVEPLANNER = "EmployeeLeavePlanner";
	public static final String EMPLOYEE_CHANGE_PASSWORD = "EmployeeChangePassword";

	public static final String MANAGER_LEAVESCHEDULER = "ManagerLeaveScheduler";
	public static final String MANAGER_REMINDER = "ManagerReminder";
	public static final String MANAGER_DELEGATE = "ManagerDelegate";
	public static final String MANAGER_REPORT = "ManagerReport";
	public static final String MANAGER_EMPMANAGEMENT = "ManagerEmpManagement";
	public static final String MANAGER_LEAVEMANAGEMENT = "ManagerLeaveManagement";
	
	public static final String CONTACT = "Contact";
}
