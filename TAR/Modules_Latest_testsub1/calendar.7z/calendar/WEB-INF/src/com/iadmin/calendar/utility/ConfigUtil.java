/*
 * Created on Feb 7, 2006
 */
package com.iadmin.calendar.utility;


/**
 * @author james.yong
 */
public class ConfigUtil {
	
	public static final String configPath="config.xml";
	
	public static String getConfigFilePath(){
		
	    return configPath;
	}
}
