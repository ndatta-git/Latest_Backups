/*
 * Created on Aug 22, 2005
 */
package com.iadmin.calendar.module.DTO;

import java.util.Vector;

import com.iadmin.calendar.utility.Util;

/**
 * @author james.yong
 */
public class CalendarAddYearBean
{
	String calendar_id;
	String year;
	
	public String getCalendar_id() {
		return Util.nvlToBlank(this.calendar_id);
	}
	public void setCalendar_id(String calendar_id) {
		this.calendar_id = calendar_id;
	}
	public String getYear() {
		return Util.nvlToBlank(this.year);
	}
	public void setYear(String year) {
		this.year = year;
	}
	
	public Vector validate()
	{
		Vector error = new Vector();
		
		if ("".equals(this.year))
			error.add("admin.calendar.addyear.year.error");
		
		return error;
	}
}
