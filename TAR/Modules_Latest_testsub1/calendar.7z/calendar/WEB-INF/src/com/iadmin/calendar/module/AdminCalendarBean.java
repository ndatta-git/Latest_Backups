package com.iadmin.calendar.module;


public class AdminCalendarBean {
	//James Yong: Current selections
    private Integer year;
    private Integer month;
    private String calendarId;
    // James Yong: get the days for the whole month e.g : Thurs, Fri, Sat, Sun, Mon
    private String arrMonth[];
    
	public AdminCalendarBean() {
		super();
		this.year = new Integer(0);
		this.month =new Integer(-1);
		this.calendarId = "";
		this.arrMonth = new String[]{""};
	}
    /**
     * @return Returns the month.
     */
    public Integer getMonth() {
        return this.month;
    }
    /**
     * @param month The month to set.
     */
    public void setMonth(Integer month) {
        this.month = month;
    }
    /**
     * @return Returns the year.
     */
    public Integer getYear() {
        return this.year;
    }
    /**
     * @param year The year to set.
     */
    public void setYear(Integer year) {
        this.year = year;
    }
    
    /**
     * @return Returns the arrMonth.
     */
    public String[] getArrMonth() {
        return this.arrMonth;
    }
    /**
     * @param arrMonth The arrMonth to set.
     */
    public void setArrMonth(String[] arrMonth) {
        this.arrMonth = arrMonth;
    }
    
    /**
     * @return Returns the company.
     */
    public String getCalendarId() {
        return this.calendarId;
    }
    /**
     * @param company The company to set.
     */
    public void setCalendarId(String calendarId) {
        this.calendarId = calendarId;
    }
}