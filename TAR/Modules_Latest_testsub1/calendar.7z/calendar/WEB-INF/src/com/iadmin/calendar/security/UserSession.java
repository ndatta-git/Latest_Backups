/*
 * Created on Sep 21, 2005
 */
package com.iadmin.calendar.security;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import catalog.constant.Constant;

/**
 * Stores information about user's session.
 * @author James Yong
 * @version
 */
public class UserSession implements Serializable
{
	private transient String sessionId;
	private Date startTime;
	private Date lastVisit;
	private long sessionTime;
	
	public String poolName;
	public String userId;
	private String p_id;
	private String comp_id;
	public String lang;
	public String surname;
	public String given_name;

	public String module;
	public String command;
	private String userType; //James Yong: whether emp, mgr or hr
	
	//James Yong: Specifically used by the user with userType = 'HR' for the selection of access_id
	private String accessId; //James Yong: The current access group the user is using
	private List accessIdList; //James Yong: All access group that the user belongs to
	
	private String loginURL;
	
	public UserSession()
	{
		this.sessionId = "";
		this.startTime = new java.sql.Date( (new GregorianCalendar(1,0,1)).getTime().getTime() );
		this.lastVisit = new java.sql.Date( (new GregorianCalendar(1,0,1)).getTime().getTime() );
		this.sessionTime = 0;
		
		this.poolName = "";
		this.userId = "";
		this.p_id = "";
		this.lang = "";
		this.comp_id="";
		this.module = "";
		this.command = "";
		this.userType = "";
		
		this.accessId="";
		this.accessIdList = new ArrayList();
		
		this.loginURL="";
	}

	/**
	 * @return Returns the comp_id.
	 */
	public String getComp_id() {
		return comp_id;
	}
	/**
	 * @param comp_id The comp_id to set.
	 */
	public void setComp_id(String comp_id) {
		this.comp_id = comp_id;
	}
	public String getSessionId() {
		return this.sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	public Date getStartTime() {
		return this.startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	
	public Date getLastVisit() {
		return this.lastVisit;
	}
	public void setLastVisit(Date lastVisit) {
		this.lastVisit = lastVisit;
	}

	public long getSessionTime() {
		return this.sessionTime;
	}
	public void setSessionTime(long sessionTime) {
		this.sessionTime = sessionTime;
	}
	
	public String getPoolName()
	{
		return this.poolName;
	}
	public void setPoolName(String poolName)
	{
		this.poolName = poolName;
	}
	
	/**
	 * @return Returns the userID.
	 */
	public String getUserId()
	{
		return this.userId;
	}
	/**
	 * @param userID The userID to set.
	 */
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	
	public String getP_id() {
		return this.p_id;
	}
	public void setP_id(String p_id) {
		this.p_id = p_id;
	}
	
	public String getLang(){
		return this.lang;
	}
	public void setLang(String lang){
		this.lang=lang;
	}

	public String getModule()
	{
		return this.module;
	}
	public void setModule(String module)
	{
		this.module = module;
	}
	
	public String getCommand()
	{
		return this.command;
	}
	public void setCommand(String command)
	{
		this.command = command;
	}
	
	public String getUserType() {
		return this.userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	public String getAccessId() {
		return this.accessId;
	}
	public void setAccessId(String accessId) {
		this.accessId = accessId;
	}
	
	public List getAccessIdList() {
		return this.accessIdList;
	}
	public void setAccessIdList(List accessIdList) {
		this.accessIdList = accessIdList;
	}
	
	/**
	 * Checks if the user is a HR Officer
	 * 
	 * @return <code>true</code> if the user has HR Officer rights
	 */
	public boolean isHrOfficer()
	{
		return this.userType.equalsIgnoreCase(Constant.PERM_HR_OFFICER);
	}
	
	/**
	 * Checks if the user is a Manager
	 * 
	 * @return <code>true</code> if the user is a Manager
	 */
	public boolean isManager()
	{
		return this.userType.equalsIgnoreCase(Constant.PERM_MANAGER);
	}

	/**
	 * Checks if the user is an employee
	 * 
	 * @return <code>true</code> if the user is an employee
	 */
	public boolean isEmployee()
	{
		return this.userType.equalsIgnoreCase(Constant.PERM_EMPLOYEE);
	}

	/**
	 * @return Returns the given_name.
	 */
	public String getGiven_name() {
		return this.given_name;
	}
	/**
	 * @param given_name The given_name to set.
	 */
	public void setGiven_name(String given_name) {
		this.given_name = given_name;
	}
	/**
	 * @return Returns the surname.
	 */
	public String getSurname() {
		return this.surname;
	}
	/**
	 * @param surname The surname to set.
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}
	/**
	 * @return Returns the loginURL.
	 */
	public String getLoginURL() {
		return this.loginURL;
	}
	/**
	 * @param loginURL The loginURL to set.
	 */
	public void setLoginURL(String loginURL) {
		this.loginURL = loginURL;
	}
}