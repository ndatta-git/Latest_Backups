/*
 * Created on Sep 22, 2005
 */
package com.iadmin.calendar.advise;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletConfig;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;

import catalog.Catalog;
import catalog.cache.CacheEngine;
import catalog.connection.ConnectionPool;
import catalog.connection.DataSourceBean;
import catalog.events.ICacheAdvise;
import catalog.utility.DB;

import com.iadmin.calendar.db.OracleRowProcessor;
import com.iadmin.calendar.module.AdminCalendar;
import com.iadmin.calendar.utility.ConfigUtil;

/**
 * @author james.yong
 */
public class RepositoryAdvise implements ICacheAdvise {
	
	private static Collection dataSources = new java.util.ArrayList();
	private static Map dataSources_detail = new HashMap();
	
	public void execute(CacheEngine cache, ServletConfig servletConfig)
	{
		try {
			//=======================================
			//Loads the datasources allowed in eLeave
			//=======================================
			
			ConfigurationFactory factory = new ConfigurationFactory(ConfigUtil.configPath);
			Configuration config = factory.getConfiguration();
			Object prop = config.getProperty("names.name");
			if(prop instanceof Collection)
			{
				dataSources = (Collection)prop;
			} else {
				dataSources.add(prop);
			}
			populateDetails(config);
			
		} catch (ConfigurationException ce){
			System.out.println("==========================");
			System.out.println("==ConfigurationException==");
			System.out.println("=="+ce.getMessage());
			System.out.println("==========================");
		}
		
		//Set processor for dbutils
		DB.setProcessor(OracleRowProcessor.instance());
		
		//Mapping
		Map map = new HashMap();
		map.put("AdminCalendar", AdminCalendar.class.getName());
		Catalog.setModuleMap(map);
	}
	
	
	
	private static void populateDetails(Configuration config) {
		Collection c = dataSources;
		
		ConnectionPool cp = new ConnectionPool();
		
		for (Iterator iter = c.iterator(); iter.hasNext();) {
			String element = (String) iter.next();
			
			switch (ConnectionPool.pref) {
			case JNDI:
				cp.initializeConnectionPool(element);
				break;
			case POOL:
			case SINGLE:
				DataSourceBean dsb = new DataSourceBean();
				dsb.setAlias(element);
				dsb.setDriver((String)config.getProperty("datasources."+element+".driver"));
				dsb.setUrl((String)config.getProperty("datasources."+element+".url"));
				dsb.setUser((String)config.getProperty("datasources."+element+".user"));
				dsb.setPassword((String)config.getProperty("datasources."+element+".password"));
				dsb.setMin_pool_size( Integer.valueOf((String)config.getProperty("datasources."+element+".min_pool_size")) );
				dsb.setMax_pool_size( Integer.valueOf((String)config.getProperty("datasources."+element+".max_pool_size")) );
				dsb.setAcquire_increment( Integer.valueOf((String)config.getProperty("datasources."+element+".acquire_increment")) );
				dataSources_detail.put(element, dsb);
				
				//================================
				//Get Ready the connection pooling
				//================================
				cp.initializeConnectionPool(element, dsb);
				break;
			}
		}
			
	}
	
	
	
	
	public static Collection getDataSources(){
		Collection c = dataSources;
		return c;
	}
	
	public static DataSourceBean getDataSources_detail( String name ){
		synchronized( dataSources_detail ){
			if ( dataSources_detail.get( name )!=null ){
				return ( DataSourceBean ) dataSources_detail.get( name );
			} 
			return new DataSourceBean();
		}
	}
}
