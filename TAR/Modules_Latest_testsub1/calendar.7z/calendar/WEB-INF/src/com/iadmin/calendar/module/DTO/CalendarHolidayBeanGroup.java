/*
 * Created on Aug 27, 2005
 */
package com.iadmin.calendar.module.DTO;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

/**
 * @author james.yong
 */
public class CalendarHolidayBeanGroup
{
	private String calendar_id;
	private String year;
	private Integer numberOfRecords;
	
	private List holidayDetail; //CalendarHolidayBean
	
	public CalendarHolidayBeanGroup() {
		this.calendar_id = "";
		this.year = "";
		this.numberOfRecords = new Integer(0);
		this.holidayDetail = new ArrayList();
	}
	
	public Integer getNumberOfRecords() {
		return this.numberOfRecords;
	}
	public void setNumberOfRecords(Integer numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}

	public String getCalendar_id() {
		return this.calendar_id;
	}
	public void setCalendar_id(String calendar_id) {
		this.calendar_id = calendar_id;
	}
	
	public String getYear() {
		return this.year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	
	public List getHolidayDetail() {
		return this.holidayDetail;
	}
	public void setHolidayDetail(List hoildayDetail) {
		this.holidayDetail = hoildayDetail;
	}
	
	public String Start_dateValue(int i)
	{
		Date date = new java.sql.Date( (new GregorianCalendar(1,0,1)).getTime().getTime() );
		if (this.holidayDetail.size()>0 && i<this.holidayDetail.size()){
			date = ((CalendarHolidayBean)this.holidayDetail.get(i)).getStart_date();
		} 
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(date);
	}
	
	public String descriptionValue(int i)
	{
		if (this.holidayDetail.size()>0 && i<this.holidayDetail.size()){
			return ((CalendarHolidayBean)this.holidayDetail.get(i)).getDescription();
		} 
		return "";
	}
	
	public String nndayValue(int i)
	{
		if (this.holidayDetail.size()>0 && i<this.holidayDetail.size()){
			return String.valueOf(((CalendarHolidayBean)this.holidayDetail.get(i)).getNday().doubleValue());
		} 
		return "";
	}
	
	public Vector validate()
	{
		Vector error = new Vector();
		boolean x = false, y = false, z = false, m = false;
		
		if ("".equals(calendar_id)){
			error.add("admin.calendar.error.nocalendarid");
		}
		
		if (this.holidayDetail.size()==0) {
			error.add("admin.calendar.error.noholiday");
			return error;
		}
		
		Set set = new HashSet();
		for (int i=0; i<this.holidayDetail.size(); i++){
			CalendarHolidayBean bean = ((CalendarHolidayBean)holidayDetail.get(i));
			
			//Check selected date is within the year 
			if (!x && ((bean.getStart_date().getYear()+1900)!= Integer.parseInt(year)) ){
				error.add("admin.calendar.error.datenotwithinyear");
				x = true;
			}
			//Check description is filled
			if (!y && bean.getDescription().equals("")){
				error.add("admin.calendar.title.add.holiday.descriptionnotfilled");
				y = true;
			}
			//Check nday is non-zero
			if (!z && (bean.getNday().doubleValue()==0.0) ){
				error.add("admin.calendar.title.add.holiday.ndaynotfilled");
				z = true;
			}
			//Check date is not repeated
			if (!m && !set.add( bean.getStart_date() ) ){
				error.add("admin.calendar.title.add.holiday.repeateddate");
				m = true;
			}
		}
		return error;
	}
}
