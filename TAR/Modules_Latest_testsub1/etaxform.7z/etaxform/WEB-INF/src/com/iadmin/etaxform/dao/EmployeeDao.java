package com.iadmin.etaxform.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import catalog.utility.DB;

import com.iadmin.etaxform.bean.EmployeeInfo;

public class EmployeeDao {
	public int totleEmployee(String client, String poolname) throws SQLException{
		int ret = 0;
		
		// edit by zaza @ 25Feb2010
		StringBuffer sb;
		if (poolname.startsWith("etax_")) {
			sb = new StringBuffer("select count(*) from tax_sin_per_data t where t.company_id=?");
		} else {
			sb = new StringBuffer("select count(*) from etaxform_emp_info t where t.company_id=?");
		}
		
		ret = DB.selectToCount(sb.toString(), new Object[]{client}).intValue();
		return ret;
	}
	public int totleEmployee(String para,String value,String client, String poolname) throws SQLException{
		int ret = 0;
		String condi = "beid";
		if(para.equals("name"))
			condi = "last_name||' '||first_name";
		
		// edit by zaza @ 25Feb2010
		StringBuffer sb;
		if (poolname.startsWith("etax_")) {
			sb = new StringBuffer("select count(*) from tax_sin_per_data where company_id=? and "+condi+" like '%"+value+"%'");
		} else {
			sb = new StringBuffer("select count(*) from etaxform_emp_info where company_id=? and "+condi+" like '%"+value+"%'");
		}
			
		ret = DB.selectToCount(sb.toString(), new Object[]{client}).intValue();
		return ret;
	}
	public List<EmployeeInfo> getEmployeeList(int startRow,int endRow,String client, String poolname) throws SQLException {
		List<EmployeeInfo> retList = new ArrayList<EmployeeInfo>();
		String subsql = "";
		
		// edit by zaza @ 25Feb2010
		StringBuffer sb;
		if (poolname.startsWith("etax_")) {
			subsql = "          from (select t.beid, t.last_name||' '||t.first_name name\n";
			sb = new StringBuffer(
					"select p_id, name\n" +
					"  from (select rownum     num,\n" + 
					"               beid       p_id,\n" + 
					"               name\n"+				
					subsql+
					"                  from tax_sin_per_data t where t.company_id=? " + 
					"                 order by length(beid), beid, name))\n" + 
					" where num between ? and ?"
					);
		} else {
			subsql = "          from (select t.beid, t.name\n";
			sb = new StringBuffer(
					"select p_id, name\n" +
					"  from (select rownum     num,\n" + 
					"               beid       p_id,\n" + 
					"               name\n"+				
					subsql+
					"                  from etaxform_emp_info t where t.company_id=? " + 
					"                 order by length(beid), beid, name))\n" + 
					" where num between ? and ?"
					);
		}

		retList = DB.selectToList(sb.toString(), new Object[]{client, startRow,endRow}, EmployeeInfo.class);
		return retList;
	}
	/**
	 * 
	 * @param startRow
	 * @param endRow
	 * @param para   [ beid, first_name, last_name]
	 * @param value
	 * @return
	 * @throws SQLException
	 */
	public List<EmployeeInfo> getEmployeeByParameter(int startRow,int endRow,String para,String value,String client, String poolname) throws SQLException {
		List<EmployeeInfo> retList = new ArrayList<EmployeeInfo>();
		String condi = "beid";
		if(para.equals("name"))
			condi = "last_name||' '||first_name";
		String subsql = "";
		
		// edit by zaza @ 25Feb2010
		StringBuffer sb;
		if(poolname.startsWith("etax_")){
			subsql = "                  from (select t.beid,t.last_name, t.first_name, t.last_name||' '||t.first_name name\n";
			sb = new StringBuffer(
					"select p_id, name\n" +
					"  from (select rownum     num,\n" + 
					"               beid       p_id,\n" + 				
					"               name\n" + 
					"          from (select beid, name\n" + 
					subsql +
					"                          from tax_sin_per_data t where t.company_id=? " + 
					"                         order by length(beid), beid, name)\n" + 
					"                 where "+condi+" like '%"+value+"%')\n" + 
					"        )\n" + 
					" where num between ? and ?"
				);
		}else{
			subsql = "          from (select t.beid, t.name\n";
			sb = new StringBuffer(
					"select p_id, name\n" +
					"  from (select rownum     num,\n" + 
					"               beid       p_id,\n" + 				
					"               name\n" + 
					"          from (select beid, name\n" + 
					subsql +
					"                          from etaxform_emp_info t where t.company_id=? " + 
					"                         order by length(beid), beid, name)\n" + 
					"                 where "+condi+" like '%"+value+"%')\n" + 
					"        )\n" + 
					" where num between ? and ?"
				);
		}

		retList = DB.selectToList(sb.toString(), new Object[]{client,startRow,endRow}, EmployeeInfo.class);
		return retList;
	}
}
