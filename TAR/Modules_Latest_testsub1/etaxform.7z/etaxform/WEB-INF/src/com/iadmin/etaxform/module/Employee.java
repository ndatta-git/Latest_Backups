package com.iadmin.etaxform.module;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;

import catalog.Catalog;
import catalog.constant.Constant;
import catalog.controller.UnSecureController;
import catalog.utility.CR;

import com.iadmin.etaxform.dao.EmployeeDao;

public final class Employee extends UnSecureController{
	
	 public static final String LOCAL = "LOCAL";
	
	public String execute(HttpServletRequest request,
            HttpServletResponse response) throws SQLException, ConfigurationException{
		request.getSession().setAttribute("searchBody","");
		request.getSession().setAttribute("searchText","");
		String client = (String) request.getSession().getAttribute("CLIENT_NAME");
		String poolname = (String) request.getSession().getAttribute(Constant.POOL_NAME);
		System.out.println("1<><><><><><>"+request.getSession().getAttribute("lang"));
		
		
		this.creatList(null, null,client,poolname);
		return "employee_list.jsp";
	}
	
	public String search() throws ConfigurationException, SQLException{
		HttpServletRequest request = Catalog.getRequest();
		String para  = request.getParameter("para");
		String value  = request.getParameter("paravalue");
		if(CR.isNNNE(value)){			
			request.getSession().setAttribute("searchBody", para);
			request.getSession().setAttribute("searchText", value);			
		}else{
			request.getSession().setAttribute("searchBody","");
			request.getSession().setAttribute("searchText","");			
		}
		String client = (String) request.getSession().getAttribute("CLIENT_NAME");
		String poolname = (String) request.getSession().getAttribute(Constant.POOL_NAME);
		this.creatList(para, value,client,poolname);
		return "employee_list.jsp";
	}
	
	public String search2() throws SQLException, ConfigurationException{
		HttpServletRequest request = Catalog.getRequest();		
		String para  = (String)request.getSession().getAttribute("searchBody");
		String value  = (String)request.getSession().getAttribute("searchText");
		String client = (String) request.getSession().getAttribute("CLIENT_NAME");
		String poolname = (String) request.getSession().getAttribute(Constant.POOL_NAME);
		this.creatList(para, value,client,poolname);
		return "employee_list.jsp";
	}
	
	public void creatList(String para, String value,String client, String poolname) throws SQLException, ConfigurationException{
		EmployeeDao dao = new EmployeeDao();
		HttpServletRequest request = Catalog.getRequest();
		
		String currentPage = request.getParameter("currentPage");
		int countRow = 0;
		if(CR.isNNNE(value)){
			countRow = dao.totleEmployee(para,value, client, poolname);	
		}else{
			countRow = dao.totleEmployee(client, poolname);
		}
		int pageNum;
		if(CR.isNNNE(currentPage))
			pageNum = Integer.parseInt(currentPage);	
		else
			pageNum = 1;
		request.setAttribute("pageNum", new Integer(pageNum));
		request.setAttribute("countRow", new Integer(countRow));
		
		int rowsPerPage = 0;		
		ConfigurationFactory factory = new ConfigurationFactory("config.xml");
		Configuration config = factory.getConfiguration();
		rowsPerPage = config.getInt("pagination.value");
		request.setAttribute("rowsPerPage", new Integer(rowsPerPage));
		
		int startRow = pageNum*rowsPerPage-rowsPerPage+1;
		int endRow = ((pageNum*rowsPerPage)>countRow)?countRow:(pageNum*rowsPerPage);
		
		ArrayList list = new ArrayList();
		if(CR.isNNNE(value))
			list = (ArrayList) dao.getEmployeeByParameter(startRow, endRow, para, value, client, poolname);
		else 
			list = (ArrayList) dao.getEmployeeList(startRow, endRow, client, poolname);
		request.setAttribute("jbean", list);
	}
}
