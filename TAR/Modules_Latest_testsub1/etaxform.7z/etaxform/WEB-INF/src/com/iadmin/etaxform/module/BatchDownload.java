package com.iadmin.etaxform.module;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationFactory;

import com.iadmin.etaxform.bean.EmployeeInfo;
import com.iadmin.etaxform.security.FileEncryption;
import com.iadmin.etaxform.utility.ConfigUtil;

import catalog.Catalog;
import catalog.constant.Constant;
import catalog.controller.Controller;
import catalog.sso.GlobalSession;
import catalog.utility.DB;
import edu.yale.its.tp.cas.client.filter.CASFilter;


public class BatchDownload extends Controller
{
	public String execute(HttpServletRequest request,
			HttpServletResponse response) throws Exception 
	{
		return null;
	}
	
	public String selectDownloadDetails() throws Exception 
	{
		return "select_download_details.jsp";
	}
	
	public String doDownload() throws Exception
	{
		HttpServletRequest request = Catalog.getRequest();
		HttpServletResponse response = Catalog.getResponse();
		String client = (String) request.getSession().getAttribute(
				"CLIENT_NAME");			
	    String downloadAll = request.getParameter("downloadAllField");
	    String confirmDownload = request.getParameter("confirmDownload");
	    String confirmDownloadfortaxform = request.getParameter("confirmDownloadfortaxform");
	    String[] pidArray = request.getParameter("selectedIds").split(",");	     
	    List<String> filePathList = new ArrayList<String>();
	    String poolname = (String) request.getSession().getAttribute(Constant.POOL_NAME);
		ConfigurationFactory factory = new ConfigurationFactory("config.xml");
		Configuration config= factory.getConfiguration();;
	     if(downloadAll.equals("true"))
	     {
	    	 List<EmployeeInfo> pidList = new ArrayList<EmployeeInfo>();
	    	 if(poolname.startsWith("etax_"))
	    	 {
	    		 pidList= DB.selectToList("select beid p_id from tax_sin_per_data where company_id='"+client+"'",null , EmployeeInfo.class);
	    		 for(EmployeeInfo ei:pidList)
	    		 {
	    			 assembleFilePathList(request,response,ei.getP_id(),filePathList,config,confirmDownload,confirmDownloadfortaxform);
	    		 }
	    	 }
	    	 else
	    	 {
	    		 pidList= DB.selectToList("select beid p_id from etaxform_emp_info where company_id='"+client+"'",null , EmployeeInfo.class);
	    		 for(EmployeeInfo ei:pidList)
	    		 {
	    			 assembleFilePathList(request,response,ei.getP_id(),filePathList,config,confirmDownload,confirmDownloadfortaxform);
	    		 }
	    	 }
	    	 
	     }
	     else if(downloadAll.equals("false"))
	     {
	    	 for(int i=0;i<pidArray.length;i++)
	    	 {
	    		 String pid = pidArray[i];
	    		assembleFilePathList(request,response,pid,filePathList,config,confirmDownload,confirmDownloadfortaxform);
	    	 }
	     }
	     //generate zip file	     
	     String pdfArchivePath = getZipPath(config)+client+"_certPdf_"+request.getParameter("selectedYear")+".zip";
	     
	     
			if (!filePathList.isEmpty()) {
				FileOutputStream fo = new FileOutputStream
				(pdfArchivePath);
				ZipOutputStream zo = new ZipOutputStream(fo);
				// delete temporary file
				for (String filePath : filePathList) {
					doZipFile(zo, filePath);
					new File(filePath).delete();
				}
			   // end
				zo.close();
				fo.close();
				if(confirmDownloadfortaxform.equals("true")){
					runFileExport(response, new FileInputStream(pdfArchivePath),
				      		  client+"_taxform_pdf_"+request.getParameter("selectedYear")+".zip");
				}
				else{
			    runFileExport(response, new FileInputStream(pdfArchivePath),
			      		  client+"_certPdf_"+request.getParameter("selectedYear")+".zip");}
			}
			else
			{
				return "file_not_found.jsp";
			}
			
			return null;

	}
	     


	
	  private String getZipPath(Configuration config) {
		// TODO Auto-generated method stub
			String osName = java.lang.System.getProperty("os.name");
			if (osName.startsWith("Windows")) {
				return config.getString("zippath.windows");
			
			} else {
				return config.getString("zippath.unix");
				
			}	
	}

	private List<String>  assembleFilePathList(HttpServletRequest request , 
			  HttpServletResponse response,String pid,List<String> filePathList,Configuration config,String confirmDownload,String confirmDownloadfortaxform) throws Exception
	  {
			/**
			 * prepare common variables
			 */
			String path = "";
			String path_forTWT = "";
			String filename = "";
			String filename_forTWT = "";
			String year = request.getParameter("selectedYear");
			String nextYear = Integer.parseInt(year)+1+"";

			String basepath = "";
			String slipStr = "";
			String client = (String) request.getSession().getAttribute(
			"CLIENT_NAME");		
			String login_name = (String)request.getSession().getAttribute(CASFilter.CAS_FILTER_USER);
			String location = (String) new GlobalSession().getAttribute(login_name.toUpperCase(), "COUNTRY_CODE");
	        //set path separator by operation system
			String osName = java.lang.System.getProperty("os.name");
				if (osName.startsWith("Windows")) {
					basepath = config.getString("filepath.windows");
					slipStr = "\\\\";
				} else {
					basepath = config.getString("filepath.unix");
					slipStr = "/";
				}			
			//set file path by location 	
			if(location.equalsIgnoreCase("TW"))
			{
				if(confirmDownload.equals("true")){
				path = basepath + slipStr + client + slipStr + year + slipStr + "TW_CERT" + slipStr;}
			else
			{
				path = basepath + slipStr + client + slipStr + year + slipStr+"EWC"+slipStr;
				path_forTWT = basepath + slipStr + client + slipStr + year + slipStr+"TWT"+slipStr;
			}
			}

			//get Secret Key for decryption
			SecretKey key = ConfigUtil.getSecretkey();
			FileEncryption fileEncryption = new FileEncryption(key);
			
			/**
			 * retrieve the files needed
			 */
			if(confirmDownloadfortaxform.equals("true")){
				 filename = "TAX_FORM_" + client + "_" + pid + "_"
				  			+ new Integer(year).toString()
				  			+ new Integer(nextYear).toString()+"_EWC" + ".pdf";
				 filename_forTWT = "TAX_FORM_" + client + "_" + pid + "_"
				  			+ new Integer(year).toString()
				  			+ new Integer(nextYear).toString() +"_TWT"+ ".pdf";
			}
			else{
	  	    filename = "TAX_CERTIFICATE_FORM_" + client + "_" + pid + "_"
 			+ new Integer(year).toString()
 			+ new Integer(nextYear).toString() + ".pdf";}
	  	    File formFile = new File(path+filename+".encrypted");
	  	  File formFile_forTWT = new File(path_forTWT+filename_forTWT+".encrypted");
	  	    if(formFile_forTWT.isFile()){
	  	    	 InputStream inputStream = fileEncryption
	  		  			.decrypt(new FileInputStream(formFile_forTWT
	  		  					.getPath()));
	  		   	 FileOutputStream fos = new FileOutputStream(path_forTWT+filename_forTWT);
	  		   	 int numRead = 0;
	  		  			byte[] buf = new byte[1024];
	  		  			while ((numRead = inputStream.read(buf)) >= 0) {
	  		  				fos.write(buf, 0, numRead);
	  		  			}
	  		  			fos.close();
	  		  			inputStream.close();
	  		  			filePathList.add(path_forTWT+filename_forTWT);
	  	    }
	    if(formFile.isFile() && formFile.exists())
	    {
	   	 InputStream inputStream = fileEncryption
	  			.decrypt(new FileInputStream(formFile
	  					.getPath()));
	   	 FileOutputStream fos = new FileOutputStream(path+filename);
	   	 int numRead = 0;
	  			byte[] buf = new byte[1024];
	  			while ((numRead = inputStream.read(buf)) >= 0) {
	  				fos.write(buf, 0, numRead);
	  			}
	  			fos.close();
	  			inputStream.close();
	  			filePathList.add(path+filename);
	    }
	    return filePathList;
	    
	  }
	
	private void runFileExport(HttpServletResponse response, InputStream f,
			String filename) {
		try {
			// Output the blob to the HttpServletResponse
			// response.setContentType( "zip" );
			response.setHeader("Content-disposition", "attachment;filename="
					+ filename);
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-Control", "max-age=0");

			BufferedOutputStream out = new BufferedOutputStream(response
					.getOutputStream());
			byte by[] = new byte[32768];
			int index = f.read(by, 0, 32768);
			while (index != -1) {
				out.write(by, 0, index);
				index = f.read(by, 0, 32768);
			}
			out.flush();
			out.close();
  
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
private static void doZipFile(ZipOutputStream zo, String fn) throws FileNotFoundException, IOException {
FileInputStream fi;
ZipEntry ze;
ze = new ZipEntry(new File(fn).getName());
fi = new FileInputStream(new File(fn));
zo.putNextEntry(ze);
copy(fi, zo);
fi.close();
}


	
private static void copy(InputStream in, OutputStream out) throws IOException {
int cache;
cache = in.read();
while (cache != -1) {
	out.write(cache);
	cache = in.read();
}

}
}
