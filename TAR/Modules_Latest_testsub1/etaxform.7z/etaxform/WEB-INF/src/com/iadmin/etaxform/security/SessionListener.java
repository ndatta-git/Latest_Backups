package com.iadmin.etaxform.security;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import catalog.sso.GlobalSession;

import edu.yale.its.tp.cas.client.filter.CASFilter;

public class SessionListener implements HttpSessionListener {

	public void sessionCreated(HttpSessionEvent event) {
	}

	public void sessionDestroyed(HttpSessionEvent event) {
		HttpSession session = event.getSession();
		String login_name = (String) session
				.getAttribute(CASFilter.CAS_FILTER_USER);
		String logout = (String) session.getAttribute("logout");
		if(login_name!=null && "1".equals(logout)){
			GlobalSession gsession = new GlobalSession();
			gsession.release(login_name);
			System.out.println("---- destroy " + login_name + " ----");
		}
	}
}
