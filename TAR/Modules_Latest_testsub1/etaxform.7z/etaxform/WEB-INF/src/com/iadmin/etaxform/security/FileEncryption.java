package com.iadmin.etaxform.security;

import java.io.InputStream;
import java.io.OutputStream;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

public class FileEncryption {

	Cipher dcipher;

	public FileEncryption(SecretKey key) {
		// Create an 8-byte initialization vector
		byte[] iv = new byte[] { (byte) 0x8E, 0x12, 0x39, (byte) 0x9C, 0x07,
				0x72, 0x6F, 0x5A };

		AlgorithmParameterSpec paramSpec = new IvParameterSpec(iv);
		try {
			dcipher = Cipher.getInstance("DESede/CBC/PKCS5Padding");

			// CBC requires an initialization vector
			dcipher.init(Cipher.DECRYPT_MODE, key, paramSpec);
		} catch (java.security.InvalidAlgorithmParameterException e) {
			e.printStackTrace();
		} catch (javax.crypto.NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (java.security.NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (java.security.InvalidKeyException e) {
			e.printStackTrace();
		}
	}

	// Buffer used to transport the bytes from one stream to another
	byte[] buf = new byte[1024];

	public InputStream decrypt(InputStream in) {
		in = new CipherInputStream(in, dcipher);
		return in;
	}
}
