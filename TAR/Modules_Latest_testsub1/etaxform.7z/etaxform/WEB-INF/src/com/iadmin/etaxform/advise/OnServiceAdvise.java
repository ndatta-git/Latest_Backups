package com.iadmin.etaxform.advise;

import javax.servlet.http.HttpSession;

import catalog.Catalog;
import catalog.constant.Constant;
import catalog.events.IAdvise;

import com.iadmin.etaxform.security.UserSession;

public class OnServiceAdvise implements IAdvise {

	public void execute()
	{
		HttpSession session = Catalog.getRequest().getSession();
		
		//============
		//User Session
		//============
		UserSession pobj = (UserSession) session.getAttribute(Constant.USER_SESSION);
		// create a new UserSession object for the anonymous user
		if (pobj == null) {
			pobj = new UserSession();
			//English (en) is set as default for I18N
			pobj.setLang((String)session.getAttribute(Constant.SESSION_LANG)); //English locale
		}
		pobj.setPoolName((String)session.getAttribute(Constant.POOL_NAME));
		pobj.setModule(Catalog.getModule());
		pobj.setCommand(Catalog.getCommand());
		session.setAttribute(Constant.USER_SESSION, pobj);
		
		//==================
		//Locate Module Path
		//==================
		Catalog.setModulePath("com.iadmin.etaxform.module");
		
	}
}
