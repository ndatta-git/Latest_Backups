package com.iadmin.etaxform.dao;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.iadmin.etaxform.bean.PdfInfoBean;

import catalog.utility.DB;

/**
 * @deprecated
 * @author xie
 *
 */
public class TaxInfoDao {
	public List<PdfInfoBean> pdfList(String beid) throws SQLException {
		List<PdfInfoBean> reList = new ArrayList<PdfInfoBean>();
		StringBuffer sb = new StringBuffer(
				"select * from tax_sin_finish t where t.beid = ? order by t.taxyear desc");
		reList = DB.selectToList(sb.toString(), new Object[] { beid },
				PdfInfoBean.class);
		return checkFile(reList);
	}

	public List<PdfInfoBean> checkFile(List list) {
		List<PdfInfoBean> reList = new ArrayList<PdfInfoBean>();
		if (!list.isEmpty()) {
			for (int i = 0; i < list.size(); i++) {
				PdfInfoBean pb = (PdfInfoBean) list.get(i);
				File file = new File(pb.getTax_file());
				if (file.isFile()) {
					reList.add(pb);
				}
			}
		}
		return reList;
	}
}
