package com.iadmin.etaxform.utility;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Calendar;
import java.util.Date;

import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import org.apache.commons.configuration.ConfigurationException;

public class ConfigUtil {

	public static final String configPath = "config.xml";

	public static String tybegin = "";

	public static String tyend = "";

	public static String basepath = "";
	
	private static boolean bool = false;
	
	public static String getConfigFilePath() {
		return configPath;
	}

	public static SecretKey getSecretkey() throws ConfigurationException{
		String osName = java.lang.System.getProperty("os.name");
		File ff= null;
		SecretKey key = null;
		if (osName.startsWith("Windows")) {
			ff = new File("E:/Tomcat5.5/Tomcat5.5/fileencryptionkey.key");// visent test
		} else {
			ff = new File("/usr/local/tomcat/bin/fileencryptionkey.key");
		}
		try{
			DataInputStream in = new DataInputStream(new FileInputStream(ff));
			byte[] rawkey = new byte[(int)ff.length()];
			in.readFully(rawkey);
			in.close();
			// Convert the raw bytes to a secret key like this
			DESedeKeySpec keyspec = new DESedeKeySpec(rawkey);
			SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("DESede");
			key = keyfactory.generateSecret(keyspec);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return key;
	}
	
	public static String currentYear(){
		String cy = "";
		Date d = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cy = new Integer(cal.get(Calendar.YEAR)).toString();
		return cy;		
	}

	public static void printOut(String str) {
		if (bool)
			System.out.println(str);
	}

	public static String getTybegin() {
		return tybegin;
	}

	public static String getTyend() {
		return tyend;
	}

	public static String getBasepath() {
		return basepath;
	}
}
