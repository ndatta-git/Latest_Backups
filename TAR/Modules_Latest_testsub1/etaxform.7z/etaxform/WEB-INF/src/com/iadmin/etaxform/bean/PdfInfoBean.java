package com.iadmin.etaxform.bean;

public class PdfInfoBean {
	private String beid;
	private String company_id;
	private Integer taxyear;
	private String tax_file;
	private String hkyear;
	private boolean isTwTaxForm;
	private boolean isTwTaxFormTWT; //added by mani
	private boolean isTwTaxFormEWC; //added by mani
	private boolean isThaTaxForm;
	private boolean isSlipJawapan = false;
	public boolean isSlipJawapan() {
		return isSlipJawapan;
	}
	public void setSlipJawapan(boolean isSlipJawapan) {
		this.isSlipJawapan = isSlipJawapan;
	}
	public boolean isThaTaxForm() {
		return isThaTaxForm;
	}
	public void setThaTaxForm(boolean isThaTaxForm) {
		this.isThaTaxForm = isThaTaxForm;
	}
	public boolean isTwTaxForm() {
		return isTwTaxForm;
	}
	public void setTwTaxForm(boolean isTwTaxForm) {
		this.isTwTaxForm = isTwTaxForm;
	}
	public String getHkyear() {
		return hkyear;
	}
	public void setHkyear(String hkyear) {
		this.hkyear = hkyear;
	}
	public String getBeid() {
		return beid;
	}
	public void setBeid(String beid) {
		this.beid = beid;
	}
	public String getCompany_id() {
		return company_id;
	}
	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}
	
	public Integer getTaxyear() {
		return taxyear;
	}
	public void setTaxyear(Integer taxyear) {
		this.taxyear = taxyear;
	}
	public String getTax_file() {
		return tax_file;
	}
	public void setTax_file(String tax_file) {
		this.tax_file = tax_file;
	}	
	public boolean isTwTaxFormTWT() {//added by mani
		return isTwTaxFormTWT;
	}
	public void setTwTaxFormTWT(boolean isTwTaxFormTWT) {
		this.isTwTaxFormTWT = isTwTaxFormTWT;
	}
	public boolean isTwTaxFormEWC() {//added by mani
		return isTwTaxFormEWC;
	}
	public void setTwTaxFormEWC(boolean isTwTaxFormEWC) {
		this.isTwTaxFormEWC = isTwTaxFormEWC;
	}
}
