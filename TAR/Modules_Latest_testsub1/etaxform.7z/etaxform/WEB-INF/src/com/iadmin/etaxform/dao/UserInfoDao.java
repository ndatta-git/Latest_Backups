package com.iadmin.etaxform.dao;

import java.sql.SQLException;

import catalog.utility.DB;

public class UserInfoDao {
	public UserInfoDao(){
		
	}
	
	public String getUserTypeByPID(String pid,String client) throws SQLException{
		String rule = null;
		StringBuffer sb = new StringBuffer(
				"select t.group_id from etaxform_user t where t.p_id=? and t.comp_id=?"
			);
		rule = DB.selectToString(sb.toString(), new Object[]{pid,client});
		return rule;
	}
}
