/*
 * Created on Sep 21, 2005
 */
package com.iadmin.etaxform.security;

import java.io.Serializable;

@SuppressWarnings("unchecked")
public class UserSession implements Serializable {

	private static final long serialVersionUID = 1L;
	private transient String sessionId;

	public String poolName;
	public String userId;
	private String p_id;
	private String comp_id;
	public String lang;
	public String surname;
	public String given_name;
	private String userType;
	public String module;
	public String command;
	private String loginURL;

	public UserSession() {
		sessionId = "";
		poolName = "";
		userId = "";
		p_id = "";
		lang = "";
		this.module = "";
		this.command = "";
		comp_id = "";
		userType = "";
		loginURL = "";
	}

	/**
	 * @return Returns the comp_id.
	 */
	public String getComp_id() {
		return comp_id;
	}

	/**
	 * @param comp_id
	 *            The comp_id to set.
	 */
	public void setComp_id(String comp_id) {
		this.comp_id = comp_id;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getPoolName() {
		return poolName;
	}

	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}

	/**
	 * @return Returns the userID.
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userID
	 *            The userID to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getP_id() {
		return p_id;
	}

	public void setP_id(String p_id) {
		this.p_id = p_id;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * @return Returns the given_name.
	 */
	public String getGiven_name() {
		return given_name;
	}

	/**
	 * @param given_name
	 *            The given_name to set.
	 */
	public void setGiven_name(String given_name) {
		this.given_name = given_name;
	}

	/**
	 * @return Returns the surname.
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * @param surname
	 *            The surname to set.
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * @return Returns the loginURL.
	 */
	public String getLoginURL() {
		return loginURL;
	}

	/**
	 * @param loginURL
	 *            The loginURL to set.
	 */
	public void setLoginURL(String loginURL) {
		this.loginURL = loginURL;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}
	
}