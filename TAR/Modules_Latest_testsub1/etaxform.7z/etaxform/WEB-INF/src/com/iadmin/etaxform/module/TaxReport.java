package com.iadmin.etaxform.module;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.crypto.SecretKey;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;

import sun.misc.BASE64Decoder;
import catalog.sso.GlobalSession;

import com.iadmin.etaxform.security.FileEncryption;
import com.iadmin.etaxform.utility.ConfigUtil;

import edu.yale.its.tp.cas.client.filter.CASFilter;

public class TaxReport extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("TaxReport : EtaxForm While download");
		ConfigurationFactory factory = new ConfigurationFactory("config.xml");
		Configuration config;
		String basepath = "";
		String path = "";
		String filename = "";
		String slipStr = "";
		String client = (String) request.getSession().getAttribute(
				"CLIENT_NAME");
		// String fullPath = request.getParameter("path");
		String type = (String)request.getSession().getAttribute("USERTYPE");
		GlobalSession gsession = new GlobalSession();
		String login_name = (String)request.getSession().getAttribute(CASFilter.CAS_FILTER_USER);
		login_name = login_name.toUpperCase();
		String pid="";
		if(type.equals("HR_ADMIN")){
			 pid = (String) request.getSession().getAttribute("viewid");
		}else{
			pid = (String) gsession.getAttribute(login_name, "P_ID");
		}
		//String pid = (String) request.getSession().getAttribute("viewid");// commented by mani on 4 march 2015*/

		// add by zaza
		
		
		String location = (String) gsession.getAttribute(login_name, "COUNTRY_CODE");

		String stryear = request.getParameter("link");
		System.out.println("TaxReport Encrypted link value "+ stryear);
		String year_temp = decrypt(stryear);
		  // adding by mani on 4 march 2015
		//add a new boolean to mark whether the file is tw tax form
		boolean isTwTaxForm = false;
		boolean isThaTaxForm = false;
		boolean isSlipJawapan = false;
		boolean isTwTaxFormTWT=false;//added by mani paliwal for etaxTW on 14 october
		boolean isTwTaxFormEWC=false;
		String encryptUnique=pid+client;
		if(year_temp.endsWith(encryptUnique)){
			year_temp=year_temp.substring(0, year_temp.indexOf(encryptUnique));
		}
		if(year_temp.endsWith("_TWCERT")){
			isTwTaxForm = true;
			year_temp = year_temp.substring(0, year_temp.indexOf(encryptUnique+"_TWCERT"));
		}
		//added by mani for taxTW form according to tax subject
		if(year_temp.endsWith("_TWT")){
			isTwTaxFormTWT = true;
			year_temp = year_temp.substring(0, year_temp.indexOf(encryptUnique+"_TWT"));
		}
		if(year_temp.endsWith("_EWC")){
			isTwTaxFormEWC = true;
			year_temp = year_temp.substring(0, year_temp.indexOf(encryptUnique+"_EWC"));
		}
		//add for THA Certificate
		if(year_temp.endsWith("_THACERT")){
			isThaTaxForm = true;
			year_temp = year_temp.substring(0, year_temp.indexOf(encryptUnique+"_THACERT"));
		}
		
		if(year_temp.endsWith("SLIP_JAWAPAN")){
			isSlipJawapan = true;
			year_temp = year_temp.substring(0, year_temp.indexOf(encryptUnique+"SLIP_JAWAPAN"));
		}
		
		int year = 0;
		try {
			year = Integer.parseInt(year_temp);
			
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}

		ServletOutputStream out = response.getOutputStream();
		try {
			config = factory.getConfiguration();
			String osName = java.lang.System.getProperty("os.name");
			if (osName.startsWith("Windows")) {
				basepath = config.getString("filepath.windows");
				slipStr = "\\\\";
			} else {
				basepath = config.getString("filepath.unix");
				slipStr = "/";
			}
		} catch (ConfigurationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		System.out.println("TaxReport : EtaxForm While download before generating filepath::basePath "+basepath+":: client"+client+":: p_id ::"+pid+"::location "+location);
		
		int nextyear = year + 1;
		if(isTwTaxForm){
			path = basepath + slipStr + client + slipStr + year + slipStr + "TW_CERT" + slipStr;
			filename = "TAX_CERTIFICATE_FORM_" + client + "_" + pid + "_"
			+ new Integer(year).toString()
			+ new Integer(nextyear).toString() + ".pdf";
		}else if(isTwTaxFormTWT){     //add by mani paliwal for Taiwan Tax Form
			path = basepath + slipStr + client + slipStr + year + slipStr + "TWT" + slipStr;
			filename = "TAX_FORM_" + client + "_" + pid + "_"
			+ new Integer(year).toString()
			+ new Integer(nextyear).toString()+"_TWT" + ".pdf";
		}
		else if(isTwTaxFormEWC){     //add for Taiwan Tax Form
			path = basepath + slipStr + client + slipStr + year + slipStr + "EWC" + slipStr;
			filename = "TAX_FORM_" + client + "_" + pid + "_"
			+ new Integer(year).toString()
			+ new Integer(nextyear).toString()+"_EWC" + ".pdf";
		}
		
		else if(isThaTaxForm){     //add for Tha Certificate
			path = basepath + slipStr + client + slipStr + year + slipStr + "THA_CERT" + slipStr;
			filename = "TAX_CERTIFICATE_FORM_" + client + "_" + pid + "_"
			+ new Integer(year).toString()
			+ new Integer(nextyear).toString() + ".pdf";
		}else if(isSlipJawapan){     
			path = basepath + slipStr + client + slipStr + year + slipStr + "SLIP_JAWAPAN" + slipStr;
			filename = "TAX_FORM_SJ_" + client + "_" + pid + "_"
			+ new Integer(year).toString()
			+ new Integer(nextyear).toString() + ".pdf";
		}else{
			path = basepath + slipStr + client + slipStr + year + slipStr;
			filename = "TAX_FORM_" + client + "_" + pid + "_"
			+ new Integer(year).toString()
			+ new Integer(nextyear).toString() + ".pdf";
			
		}
		File f = new File(path + filename);
		System.out.println("TaxReport : EtaxForm While download before generating filepath before encryption::"+path + filename+":: client"+client+":: p_id ::"+pid);
		/** ****** unEncryption file ******** */
		SecretKey key = null;
		try {
			key = ConfigUtil.getSecretkey();
			FileEncryption fileEncryption = new FileEncryption(key);
			InputStream in = fileEncryption.decrypt(new FileInputStream(f
					.getPath()
					+ ".encrypted"));
			// add by zaza for tw cert download
			if (location != null && ("TW".equalsIgnoreCase(location) || "HK".equalsIgnoreCase(location) || "THA".equalsIgnoreCase(location)  || "MAL".equalsIgnoreCase(location)) ) {
				System.out.println("TaxReport : EtaxForm While download before decrypt filepath::"+basepath+":: client"+client+":: p_id ::"+pid);
				runPdfFileExport(response, in, filename);
			} else {
				System.out.println("TaxReport : EtaxForm While download before decrypt filepath before encryption for SG client::");
				int numRead = 0;
				response.setContentType("application/pdf");
				byte[] buf = new byte[1024];
				while ((numRead = in.read(buf)) >= 0) {
					out.write(buf, 0, numRead);
				}
				System.out.println("TaxReport : EtaxForm While download before decrypt filepath before encryption for SG client::");
				response.setContentLength(buf.length);
				
				System.out.println("response.setContentLength(buf.length) value is::::::"+buf.length);
				out.close();
			}

		} catch (ConfigurationException e1) {
			e1.printStackTrace();
		}

		/** ******************************** */
//		try {
//			response.setContentType("application/pdf");
//
//			// Read the file into buffer
//			//FileInputStream in = new FileInputStream(f);
//
//			byte[] buf = new byte[(int) f.length()];
//			response.setContentLength(buf.length);
//			int byteRead = in.read(buf, 0, buf.length);
//			in.close();
//
//			out.write(buf);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}
	
	// add by zaza for tw pdf cert download
	private void runPdfFileExport(HttpServletResponse response, InputStream blobStream, String filename) {
		System.out.println("TaxReport : EtaxForm While download before decrypt filepath runPdfFileExport");
	     try {
	        ServletOutputStream sos = response.getOutputStream();
	        response.setContentType("application/pdf");
	        response.setHeader("Content-Disposition", "attachment;filename="+filename);   
	        response.setHeader("Pragma", "public");
			response.setHeader("Cache-Control", "max-age=0");
			
			ServletOutputStream outStream = response.getOutputStream();
			byte[] buffer = new byte[10 * 1024];
			int nbytes = 0;
			while ( (nbytes = blobStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, nbytes);
			}
			outStream.flush();
			outStream.close();
			blobStream.close();
	        sos.flush();
	     } catch (IOException e) {
	        e.printStackTrace();
	     }
	     System.out.println("TaxReport : EtaxForm While download decrypt completed");
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	private String decrypt(String input) {
		System.out.println("TaxReport : EtaxForm While download decrypt begin");
		String output = "";
		try {
			BASE64Decoder decode = new BASE64Decoder();
			output = new String(decode.decodeBuffer(input), "utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("TaxReport : EtaxForm While download decrypt End");
		return output;
	}
}
