package com.iadmin.etaxform.module;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;

import sun.misc.BASE64Encoder;

import catalog.Catalog;
import catalog.controller.Controller;
import catalog.sso.GlobalSession;
import catalog.utility.DB;

import com.iadmin.etaxform.bean.PdfInfoBean;

import edu.yale.its.tp.cas.client.filter.CASFilter;

public final class TaxInfo extends Controller{
	public String execute(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String currentPage = (String)request.getParameter("pageNum");	
		String p_id = "";
		String type = (String)request.getSession().getAttribute("USERTYPE");
		
		HttpSession session1 = Catalog.getSession();
		String login_name = (String) session1.getAttribute(CASFilter.CAS_FILTER_USER);
		login_name = login_name.toUpperCase();
		GlobalSession gsession = new GlobalSession();
		System.out.println("TaxInfo : data from globalsession : client"+(String) request.getSession().getAttribute("CLIENT_NAME")+"::P_id:"+gsession.getAttribute(login_name, "P_ID")+":location ");
		if(type.equals("HR_ADMIN"))
			p_id = (String)request.getParameter("id");
		else if(type.equals("EMP_USER")){
			String pid = (String) gsession.getAttribute(login_name, "P_ID");
			p_id = pid.trim();	
		}
		
		//String p_id = request.getParameter("id")==null?(String)request.getSession().getAttribute("PID"):request.getParameter("id");
		String client = (String) request.getSession().getAttribute("CLIENT_NAME");
		//List taxList = dao.pdfList(p_id);
		//get location
		
		String location = (String) gsession.getAttribute(login_name,
				"COUNTRY_CODE");
		System.out.println("TaxInfo : data from globalsession location :"+location);
		//ADD by zhoukai for get the city code of china client 13Mar2008
		String city = (String) gsession.getAttribute(login_name,
				"CITY_CODE");
		if (location != null && location.equalsIgnoreCase("SGP")) {
			location = "LOC_SG";
		} else if (location != null) {
			location = "LOC_" + location;
		}
		request.getSession().setAttribute("viewid", p_id); 
		List locked_tax_year = new ArrayList();
		if(location.equals("LOC_SG")){
			locked_tax_year = DB.selectToList("select distinct taxyear status  from taxform_lock_status where status=0", null, String.class);
		}
		List<PdfInfoBean> taxList = pdfList(p_id, client,location,locked_tax_year);
		request.setAttribute("linkList", taxList);
		request.setAttribute("location", location);
		request.setAttribute("currentPage", currentPage);
		return "e-tax.jsp";
	}
	
	public List<PdfInfoBean> pdfList(String pid,String client,String location,List locked_tax_year) throws ConfigurationException{
		List<PdfInfoBean> reList = new ArrayList<PdfInfoBean>();
		ConfigurationFactory factory = new ConfigurationFactory("config.xml");
		Configuration config = factory.getConfiguration();
		String osName = java.lang.System.getProperty("os.name");
		String basepath = "";
		String path = "";
		String SlipJawapanPath = "";
		String filename = "";
		String slipStr = "";
		String encryptUnique=pid+client;
		if (osName.startsWith("Windows")) {
			basepath = config.getString("filepath.windows");
			slipStr = "\\\\";
		}else{
			basepath = config.getString("filepath.unix");
			slipStr = "/";
		}
		int viewyear = config.getInt("viewyear.value");
		int thisyear = 0;
		Date d = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		thisyear = cal.get(Calendar.YEAR);
		String usertype = (String) Catalog.getSession().getAttribute("USERTYPE");				
		System.out.println("TaxInfo : pdfList method: usertype"+usertype);
		for(int i=0;i<viewyear;i++){
			PdfInfoBean pb = new PdfInfoBean();
			int year = thisyear-i;
			if(location.equals("LOC_SG") && usertype.equals("EMP_USER") && locked_tax_year.contains(String.valueOf(year))){
				System.out.println("TaxInfo : pdfList method: location "+location);
				continue;
			}

			
			path = basepath+slipStr+client+slipStr+year+slipStr;
			int nextyear = year+1;
			filename = "TAX_FORM_"+client+"_"+pid+"_"+new Integer(year).toString() +new Integer(nextyear).toString()+".pdf.encrypted"; 
			File f = new File(path+filename);
			if(f.isFile()){
				if(location.equals("LOC_HK")){
					pb.setHkyear(year+"/"+new Integer(year+1).toString());
				}
				pb.setTaxyear(new Integer(year));
				System.out.println("Tax info Encryted link :"+encript(new Integer(year).toString()+encryptUnique));
				pb.setTax_file(encript(new Integer(year).toString()+encryptUnique));
				reList.add(pb);
			}
		}
		
		if(location.equals("LOC_MAL")){
			System.out.println("TaxInfo : pdfList method: location type MAL"+location);
			for(int i=0;i<viewyear;i++){
				int year = thisyear-i;
				int nextyear = year+1;

				PdfInfoBean pb1 = new PdfInfoBean();
				filename = "TAX_FORM_SJ_"+client+"_"+pid+"_"+new Integer(year).toString() +new Integer(nextyear).toString()+".pdf.encrypted";
				SlipJawapanPath = basepath+slipStr+client+slipStr+year+slipStr+"SLIP_JAWAPAN"+slipStr;
				File SlipJawapan = new File(SlipJawapanPath+filename);
				if(SlipJawapan.isFile()){
					pb1.setTaxyear(new Integer(year));
					pb1.setTax_file(encript(new Integer(year).toString()+encryptUnique+"SLIP_JAWAPAN"));
					pb1.setSlipJawapan(true);
					reList.add(pb1);
				}
			}
		}
		//**********added by Mani Paliwal for the TW Tax for to get tax form by tax subject TWT and EWC on 14 october 2014**********//
		if(location.equals("LOC_TW")){
			for(int i=0;i<viewyear;i++){
				PdfInfoBean pb = new PdfInfoBean();
				int year = thisyear-i;
				path = basepath+slipStr+client+slipStr+year+slipStr+"TWT"+slipStr;
				int nextyear = year+1;
				filename = "TAX_FORM_"+client+"_"+pid+"_"+new Integer(year).toString() +new Integer(nextyear).toString()+"_TWT"+".pdf.encrypted"; 	 
				File f = new File(path+filename);
				if(f.isFile()){
					pb.setTaxyear(new Integer(year));
					pb.setTax_file(encript(new Integer(year).toString() +encryptUnique +"_TWT"));
					pb.setTwTaxFormTWT(true);
					reList.add(pb);
				}
			}
		}
		//**********added by Mani Paliwal for the TW Tax for to get tax form by tax subject EWC on 14 october 2014**********//
		if(location.equals("LOC_TW")){
			for(int i=0;i<viewyear;i++){
				PdfInfoBean pb = new PdfInfoBean();
				int year = thisyear-i;
				path = basepath+slipStr+client+slipStr+year+slipStr+"EWC"+slipStr;
				int nextyear = year+1;
				filename = "TAX_FORM_"+client+"_"+pid+"_"+new Integer(year).toString() +new Integer(nextyear).toString()+"_EWC"+".pdf.encrypted"; 	 
				File f = new File(path+filename);
				if(f.isFile()){
					pb.setTaxyear(new Integer(year));
					pb.setTax_file(encript(new Integer(year).toString() + encryptUnique+"_EWC"));
					pb.setTwTaxFormEWC(true);
					reList.add(pb);
				}
			}
		}
		//**********added by kevin for TW Certificate form start**********//
		if(location.equals("LOC_TW")){
			for(int i=0;i<viewyear;i++){
				PdfInfoBean pb = new PdfInfoBean();
				int year = thisyear-i;
				path = basepath+slipStr+client+slipStr+year+slipStr+"TW_CERT"+slipStr;
				int nextyear = year+1;
				filename = "TAX_CERTIFICATE_FORM_"+client+"_"+pid+"_"+new Integer(year).toString() +new Integer(nextyear).toString()+".pdf.encrypted"; 
				File f = new File(path+filename);
				if(f.isFile()){
					pb.setTaxyear(new Integer(year));
					pb.setTax_file(encript(new Integer(year).toString() + encryptUnique+"_TWCERT"));
					pb.setTwTaxForm(true);
					reList.add(pb);
				}
			}
		}
		//**********added by kevin for TW Certificate form end**********//
		
		//**********added by Leon for THA Certificate form start**********//
		if(location.equals("LOC_THA")){
			for(int i=0;i<viewyear;i++){
				PdfInfoBean pb = new PdfInfoBean();
				int year = thisyear-i;
				path = basepath+slipStr+client+slipStr+year+slipStr+"THA_CERT"+slipStr;;
				int nextyear = year+1;
				filename = "TAX_CERTIFICATE_FORM_"+client+"_"+pid+"_"+new Integer(year).toString() +new Integer(nextyear).toString()+".pdf.encrypted"; 
				File f = new File(path+filename);
				if(f.isFile()){
					pb.setTaxyear(new Integer(year));
					pb.setTax_file(encript(new Integer(year).toString() + encryptUnique+"_THACERT"));
					pb.setThaTaxForm(true);
					reList.add(pb);
				}
			}
		}
		//**********added by Leon for THA Certificate form end**********//
		
		return reList;
	}
	private String encript(final String year){
		String ret = "";
		String str = year;
		BASE64Encoder encode = new BASE64Encoder();
		try {
			ret = encode.encode(str.getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return ret;
	}	
}
