package com.iadmin.etaxform.module;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpSession;

import catalog.Catalog;
import catalog.constant.Constant;
import catalog.controller.UnSecureController;
import catalog.sso.GlobalSession;
import catalog.utility.CR;
import catalog.utility.DB;

import com.iadmin.etaxform.dao.UserInfoDao;
import com.iadmin.etaxform.security.UserSession;

import edu.yale.its.tp.cas.client.filter.CASFilter;
 
public final class Login extends UnSecureController {
	public String SSOLogin() throws Exception {	
		
		//==================================
		//Perform app-related initialisation
		//==================================
		
		HttpSession session = Catalog.getRequest().getSession(true);
		UserSession user = new UserSession();
		session.setAttribute(Constant.USER_SESSION, user);
		session.setAttribute(Constant.SESSION_ID, session.getId());
		
		GlobalSession gsession = new GlobalSession();
		UserInfoDao dao = new UserInfoDao();

		String login_name = (String) Catalog.getSession().getAttribute(
				CASFilter.CAS_FILTER_USER);
		login_name = login_name.toUpperCase();
		

		String pid = (String) gsession.getAttribute(login_name, "P_ID");
		pid = pid.trim();	
		String client_name = (String)gsession.getAttribute(login_name, "CLIENT_NAME");
		if (CR.isNull(client_name))  client_name="";
		
		String etaxform_db = (String)gsession.getAttribute(login_name, "ETAXFORM_DB" )==null?"":(String)gsession.getAttribute(login_name, "ETAXFORM_DB" );
		session.setAttribute(Constant.POOL_NAME, etaxform_db );
		
		session.setAttribute("CLIENT_NAME",client_name);
		String login_url = (String)gsession.getAttribute( login_name, "PORTAL_SESSIONEXPIRED");
		Catalog.getSession().setAttribute("SESSIONEXPIRED",login_url);
		String lang = (String)gsession.getAttribute(login_name, "LANG");
		if( CR.isNOE(lang) ) lang = "en";
		Catalog.getSession().setAttribute(Constant.SESSION_LANG, "i18n_"+lang);
		//modified by praveen on 26/11/2013
		
		String location = (String) gsession.getAttribute(login_name,"COUNTRY_CODE");
		
		/** check user account */
		String status = "1";
		System.out.println("SSOLOGIN of eTaxForm : data from globalsession : client"+client_name+"::P_id:"+pid);
		String rule = dao.getUserTypeByPID(pid,client_name);
		if (CR.isNNNE(rule)) {
			System.out.println("SSOLOGIN of eTaxForm : data from globalsession inside rule : client"+client_name+"::P_id:"+pid+"location "+location);
			Catalog.getSession().setAttribute("PID", pid);
			Catalog.getSession().setAttribute("USERTYPE", rule);
			
	        if(location.equals("SGP")){ 
			ResultSet rs = null;
			Connection conn = DB.getConnection();
			Statement st = conn.createStatement();
			String sql = "select status from taxform_lock_status where taxyear = (select max(taxyear) from taxform_lock_status)" ;
			rs =  st.executeQuery(sql);
			while(rs.next()){
				status = rs.getString("status");
				}
			rs.close();
			}
			if(location.equals("MAL"))//added by mani paliwal for MAL country
				{
				System.out.println("SSOLOGIN of eTaxForm : data from globalsession inside rule : client"+client_name+"::P_id:"+pid+"location "+location);
				ResultSet rs = null;
					Connection conn = DB.getConnection();
					Statement st = conn.createStatement();
					String sql1="select e.exclude_p_id from pay_exclude e where e.exclude_type = 'EXCLUDE'";
					String sql2 = "select status from taxform_lock_status where taxyear = (select max(taxyear) from taxform_lock_status)" ;
					rs =  st.executeQuery(sql2);
					while(rs.next()){
						status = rs.getString("status");}
					rs =  st.executeQuery(sql1);
					while(rs.next()){
						String exclude_p_id = rs.getString("exclude_p_id");
						if(exclude_p_id.equals(pid)){
							status="0";}
						           }
					rs.close();
				}
			System.out.println("SSOLOGIN of eTaxForm : data from globalsession inside rule : client"+client_name+"::P_id:"+pid+"location "+location+"lockstatus "+status);
			if (rule.equals("HR_ADMIN")) {
				Catalog.setRedirect("/catalog?module=Employee");
			} else if(rule.equals("EMP_USER")&&status.equals("1")){
				System.out.println("SSOLOGIN of eTaxForm : data from globalsession inside rule : client"+client_name+"::P_id:"+pid+"location "+location+"lockstatus "+status);
				Catalog.getSession().setAttribute("isEmp", "1");
				Catalog.setRedirect("/catalog?module=TaxInfo");
			}else{
				return "error_no_access.jsp";
			}
		} else {
			Catalog.getSession().removeAttribute("PID");
			return "error_no_access.jsp";
		}
		return "";
	}
}
