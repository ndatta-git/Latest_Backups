/*
 * Created on Aug 25, 2005
 */
package com.iadmin.etaxform.advise;


import catalog.events.IAdvise;

public class AfterModuleAdvise implements IAdvise {
	
	
	public void execute()
	{

	}
}
