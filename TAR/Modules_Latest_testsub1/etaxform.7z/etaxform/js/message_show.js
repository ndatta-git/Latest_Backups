function ShowMsg(){
	document.writeln("<div id=\"msgdiv\" style=\"height:120px;position:absolute;display:none;border:2px solid #AFCEF9;z-index:999\"><\/div>");
	document.writeln("<div id=\"overdiv\" style=\"height:120px;position:absolute;display:none;z-index:999\">");
	document.writeln("<\/div>");
	//call back
	this.ok_callback=function(){};
	this.cancel_callback=function(){};
	this.msgobjname=""
	this.show=function(msgtitle,msgcontent,selecttype){
		var tempobj1=document.getElementById("msgdiv");
		var tempobj2=document.getElementById("overdiv");
		var msgobj=this.msgobjname;
  		tempobj2.style.filter="alpha(opacity=75)";
  		tempobj2.style.MozOpacity = 75/100;
    	tempobj2.style.backgroundColor = "#000000";
	  	tempobj2.style.display = '';
    	tempobj2.style.zIndex= 100;
    	tempobj2.style.height= document.body.clientHeight+"px";
    	tempobj2.style.width= document.body.clientWidth+"px";
		tempobj2.style.left=0;
		tempobj2.style.top=0;
		tempobj1.style.display="none";
    	tempobj1.style.left= (document.body.clientWidth)/3+"px";
    	tempobj1.style.top= (document.body.scrollTop+(document.body.clientHeight)/3)+"px";
    	tempobj1.style.display= '';
    	tempobj1.style.width=400+"px";
    	tempobj1.style.height=120+"px";
    	tempobj1.style.zIndex= 200;
    	tempobj1.style.backgroundColor = "#CDDAF1";
    	var OutStr;
    	OutStr="<div style=\"font-weight:bolder;text-align:center;height:20px;font-size:14px;background-color:#6088D2;cursor:move\" canmove=\"true\" forid=\"msgdiv\">"+msgtitle+"</div>"
    	OutStr=OutStr+"<div style=\"height:60px;text-align:center;font-size:12px;\">"+msgcontent+"</div>"
   		if(selecttype==1){
    		OutStr=OutStr+"<div style=\"height:40px;text-align:center;font-size:12px;\"><input type=\"button\" value=\"Yes\" onclick=\""+msgobj+".ok()\">    <input type=\"button\" value=\"No\" onclick=\""+msgobj+".cancel()\"></div>"
    	}
   	 	else if(selecttype==2){
    		OutStr=OutStr+"<div style=\"height:40px;text-align:center;font-size:12px;\"><input type=\"button\" value=\"Yes\" onclick=\""+msgobj+".ok()\"></div>"
    	}
    	
    	tempobj1.innerHTML=OutStr;
    	var md=false,mobj,ox,oy
     	document.onmousedown=function(ev)
     	{
			var ev=ev||window.event;
			var evt=ev.srcElement||ev.target;
         	if(typeof(evt.getAttribute("canmove"))=="undefined")
         	{
            	 return;
         	}
         	if(evt.getAttribute("canmove"))
         	{
             	md = true;
             	mobj = document.getElementById(evt.getAttribute("forid"));
             	ox = mobj.offsetLeft - ev.clientX;
             	oy = mobj.offsetTop - ev.clientY;
         	}
     	}
     	document.onmouseup= function(){md=false;}
     	document.onmousemove= function(ev)
     	{
			var ev=ev||window.event;
         	if(md)
         	{
             	mobj.style.left= (ev.clientX + ox)+"px";
             	mobj.style.top= (ev.clientY + oy)+"px";
         	}
     	}
		}
		this.ok = function()
		{
			document.getElementById('msgdiv').style.display='none';
			document.getElementById('overdiv').style.display='none';
			this.ok_callback();
		}
		this.cancel=function(){
			document.getElementById('msgdiv').style.display='none';
			document.getElementById('overdiv').style.display='none';
			this.cancel_callback();
		}
	}

var ShowMsgo=new ShowMsg();

ShowMsgo.msgobjname="ShowMsgo";

ShowMsgo.ok_callback=function(){
		 
	$.ajax({
	   type: "POST",
	   url: "catalog?module=Logout&cmd=renew",
	   success: function(msg){
	   	 
	   }
	});
	showAllSelect();
	InitializeTimer();
	$.ajax({
	   type: "POST",
	   url: "https://sub1.i-admin.com/portal/catalog?module=Login&cmd=reNewSession",
	   //url: "https://[localhost | ehrstage.i-admin.com | sub1.i-admin.com]/portal/catalog?module=Login&cmd=reNewSession",
	   success: function(msg){
	   		
	   }
	});
}
ShowMsgo.cancel_callback=function(){
	showAllSelect();
	document.logout__.submit();
}
