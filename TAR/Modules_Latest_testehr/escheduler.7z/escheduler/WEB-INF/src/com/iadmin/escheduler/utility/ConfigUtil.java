package com.iadmin.escheduler.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;

public class ConfigUtil {

	public static final String configPath = "config.xml";

	public static String tybegin = "";

	public static String tyend = "";

	public static String basepath = "";
	
	private static boolean bool = false;

	public static String getConfigFilePath() {
		return configPath;
	}

	public static void init() throws ConfigurationException {
		String osName = java.lang.System.getProperty("os.name");
		ConfigurationFactory factory = new ConfigurationFactory("config.xml");
		Configuration config = factory.getConfiguration();
		if (osName.startsWith("Windows")) {
			basepath = config.getString("filepath.windows");
		} else {
			basepath = config.getString("filepath.unix");
		}
		tybegin = config.getString("taxyear.begin");
		tyend = config.getString("taxyear.end");
		String flag = config.getString("debug.value");
		if (flag.equals("true"))
			bool = true;
	}
	
	public static String currentYear(){
		String cy = "";
		Date d = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cy = new Integer(cal.get(Calendar.YEAR)-1).toString();
		return cy;		
	}
	
	public static String currentTime(String format){
		Calendar c1 = Calendar.getInstance();
		Date d = c1.getTime();
		format = format.replaceAll("m","M");
		SimpleDateFormat sf = new SimpleDateFormat(format);
		String ret = sf.format(d);
		return ret;
	}
	
	public static String formatStringDate(String date,String format,String format2) throws ParseException{
		String ret = "";
		SimpleDateFormat sf = new SimpleDateFormat(format);
		SimpleDateFormat sf2 = new SimpleDateFormat(format2);
		Date d = sf.parse(date);
		ret = sf2.format(d);
		return ret;
	}
	
	public static String getEndPath(){
		String osName = java.lang.System.getProperty("os.name");
		
		String end_path="";
		if (osName.startsWith("Windows")) {
			end_path = "\\\\";
			} else {
				end_path = "/";
				
			}
		return end_path;
	}

	public static void printOut(String str) {
		if (bool)
			System.out.println(str);
	}

	public static String getTybegin() {
		return tybegin;
	}

	public static String getTyend() {
		return tyend;
	}

	public static String getBasepath() {
		return basepath;
	}
	
	public static void main(String[] args) throws ParseException{
		
			System.out.println(formatStringDate("01/06/2007","dd/MM/yyyy","yyyyMMdd"));
		
	}
}
