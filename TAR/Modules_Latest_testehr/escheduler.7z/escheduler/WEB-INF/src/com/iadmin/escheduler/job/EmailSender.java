package com.iadmin.escheduler.job;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.configuration.ConfigurationException;

import catalog.CatalogTemplate;

public class EmailSender {
	
	private static final String SEMICOLON = ";";
	private static final String MAIL_TEMPLATE_CHARSET = "UTF-8";
	private static final String SUBJECT = ""; // default email subject
	private static final String LEAVEGRADE_REMIDNER_TEMPLATE = "leavegrade_reminder.txt";
	
	public boolean sendEmail(PayScheduleReminderBean bean,String mailHost) {
				
		try {
			
			Properties props = System.getProperties();

			props.put("mail.smtp.host", mailHost);
			Session session = Session.getDefaultInstance(props, null);

			MimeMessage message = new MimeMessage(session);
			
			// get 'from' address from bean and  set it into MimeMessage message.
			message.setFrom(new InternetAddress(bean.getFromAddress()));
			
			// get 'to' addresses from bean, change it into InternetAddress[] type and set into recipients type of TO
			String toStr = bean.getToStr();
			InternetAddress[] recipients = getListByStrSplit(toStr, SEMICOLON);
			message.setRecipients(Message.RecipientType.TO, recipients);
			
			// get 'cc' addresses from bean, change it into InternetAddress[] type and set into recipients type of TO
			String ccStr = bean.getCcStr();
			if (ccStr != null && !"".equals(ccStr.trim())) {
				InternetAddress[] cciter = getListByStrSplit(ccStr, SEMICOLON);
				message.setRecipients(Message.RecipientType.CC, cciter);
			}

			// get 'subject' from bean and set it into MimeMessage message.
			String subject = bean.getSubject();
			if (subject != null && !"".equals(subject.trim())) {
				message.setSubject(subject);
			} else {
				message.setSubject(SUBJECT);
			}
			message.setSentDate(Calendar.getInstance().getTime());

			// split Parameter String gotten from bean by "$" and put the result array into Map params
			Map<String, String> params = new HashMap<String, String>();
			String parameter = bean.getParameter();
			if (parameter != null && !"".equals(parameter.trim())) {
				if (bean.getParameter().indexOf("##") != -1) {
					String parameters[] = parameter.split("##");
					for (int j = 0; j < parameters.length; j++) {
						params.put("value" + j, parameters[j]);
					}
				} else {
					params.put("value" + 0, parameter);
				}
			}
			
			// get template file name from bean
			String msgFile = "/" + bean.getTemplateFile();
			
			// get the real mail content by read the template file replaced by params
			String messageText = this.getMessageText(params, msgFile);

			// fill message
			message.setContent(messageText, "text/plain; charset="
					+ MAIL_TEMPLATE_CHARSET);

			// Send the message
			Transport.send(message);
			
			return true;
		} catch (ConfigurationException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			return false;
		}
	}
	
	public boolean sendEmail(LeaveGradeReminderBean bean,String mailHost) {
		
		try {
			
			Properties props = System.getProperties();

			props.put("mail.smtp.host", mailHost);
			Session session = Session.getDefaultInstance(props, null);

			MimeMessage message = new MimeMessage(session);
			// get 'from' address from bean and  set it into MimeMessage message.
			message.setFrom(new InternetAddress("payenquiry@i-admin.com"));
			
			// get 'to' addresses from bean, change it into InternetAddress[] type and set into recipients type of TO
			String toStr = bean.getEmails();
			InternetAddress[] recipients = getListByStrSplit(toStr, SEMICOLON);
			message.setRecipients(Message.RecipientType.TO, recipients);

			// get 'subject' from bean and set it into MimeMessage message.
			String subject = bean.getTitle();
			if (subject != null && !"".equals(subject.trim())) {
				message.setSubject(subject);
			} else {
				message.setSubject(SUBJECT);
			}
			message.setSentDate(Calendar.getInstance().getTime());

			// split Parameter String gotten from bean by "$" and put the result array into Map params
			Map<String, String> params = new HashMap<String, String>();
			String parameter = bean.getParameter();
			if (parameter != null && !"".equals(parameter.trim())) {
				if (bean.getParameter().indexOf("##") != -1) {
					String parameters[] = parameter.split("##");
					for (int j = 0; j < parameters.length; j++) {
						params.put("value" + j, parameters[j]);
					}
				} else {
					params.put("value" + 0, parameter);
				}
			}
			
			// get template file name from bean
			String msgFile = "/" + this.LEAVEGRADE_REMIDNER_TEMPLATE;
			
			// get the real mail content by read the template file replaced by params
			String messageText = this.getMessageText(params, msgFile);

			// fill message
			message.setContent(messageText, "text/plain; charset="
					+ MAIL_TEMPLATE_CHARSET);

			// Send the message
			Transport.send(message);
			
			return true;
		} catch (ConfigurationException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			return false;
		}
	}

	protected String getMessageText(Map<String, String> params,
			String messageFile) throws Exception {
		return CatalogTemplate.getMessage(messageFile, params,
				MAIL_TEMPLATE_CHARSET);
	}
	
	// Split the str by regex and put the result string into an InternetAddress[]-type array
	private InternetAddress[] getListByStrSplit(String str, String regex) {
		InternetAddress[] address;
		try {
			if (str.indexOf(regex) != -1) {
				String splitArray[] = str.split(regex);
				address = new InternetAddress[splitArray.length];
				for (int i = 0; i < splitArray.length; i++) {
					address[i] = new InternetAddress(splitArray[i]);
				}
			} else {
				address = new InternetAddress[1];
				address[0] = new InternetAddress(str);
			}
			return address;
		} catch (AddressException e) {
			e.printStackTrace();
		}
		return null;
	}

}
