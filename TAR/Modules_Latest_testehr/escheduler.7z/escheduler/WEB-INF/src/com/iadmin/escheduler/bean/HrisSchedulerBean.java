package com.iadmin.escheduler.bean;

import java.util.Date;

public class HrisSchedulerBean {
	private String comid;
	private String scheduler_id;
	private String sche_description;
	private String status;
	private String schedule_type;
	private String table_type;
	private String table_name;
	private String column_name;
	private String unit;
	private String amount;
	private String send_time;
	private String template_name;
	private String sender;
	private String to_address;
	private String cc_address;
	private String subject;
	private String sendto_employee;
	private String para_name;
	private String anniversary_year;
	
	public String getComid() {
		return comid;
	}
	public void setComid(String comid) {
		this.comid = comid;
	}
	public String getScheduler_id() {
		return scheduler_id;
	}
	public void setScheduler_id(String schedulerId) {
		scheduler_id = schedulerId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSchedule_type() {
		return schedule_type;
	}
	public void setSchedule_type(String scheduleType) {
		schedule_type = scheduleType;
	}
	public String getTable_type() {
		return table_type;
	}
	public void setTable_type(String tableType) {
		table_type = tableType;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getSendto_employee() {
		return sendto_employee;
	}
	public void setSendto_employee(String sendtoEmployee) {
		sendto_employee = sendtoEmployee;
	}
	public String getAnniversary_year() {
		return anniversary_year;
	}
	public void setAnniversary_year(String anniversaryYear) {
		anniversary_year = anniversaryYear;
	}
	public String getSche_description() {
		return sche_description;
	}
	public void setSche_description(String scheDescription) {
		sche_description = scheDescription;
	}
	public String getTable_name() {
		return table_name;
	}
	public void setTable_name(String tableName) {
		table_name = tableName;
	}
	public String getColumn_name() {
		return column_name;
	}
	public void setColumn_name(String columnName) {
		column_name = columnName;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getSend_time() {
		return send_time;
	}
	public void setSend_time(String sendTime) {
		send_time = sendTime;
	}
	public String getTemplate_name() {
		return template_name;
	}
	public void setTemplate_name(String templateName) {
		template_name = templateName;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getTo_address() {
		return to_address;
	}
	public void setTo_address(String toAddress) {
		to_address = toAddress;
	}
	public String getCc_address() {
		return cc_address;
	}
	public void setCc_address(String ccAddress) {
		cc_address = ccAddress;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getPara_name() {
		return para_name;
	}
	public void setPara_name(String paraName) {
		para_name = paraName;
	}
	
	
}
