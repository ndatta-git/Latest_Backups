package com.iadmin.escheduler.job;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import catalog.utility.DB;

import com.iadmin.escheduler.bean.HrisRemindBean;
import com.iadmin.escheduler.db.DBConnection;

public class terminatedUserCloseJob  implements Job {

	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		// TODO Auto-generated method stub
		System.out.println("...get mainportal conection...");
		Connection mainPortalConn = DBConnection.getSSOConnection("mainportal");
		try {
//			mainPortalConn.setAutoCommit(false);
			String selectSql =  "select to_char(c.client_id) comid, t.comid subject,t.p_id,nvl(t.close_date,'') send_time\n" +
								"  from terminated_user_status_table t, client c\n" + 
								" where t.comid = c.client_name\n" + 
								"   and t.status = '0'\n";
			String updateSql = "update users set lock_status=1 where client_id=? and employee_id=?";
			String updateSql2 = "update terminated_user_status_table set status = '1' where comid=? and p_id=?";
			List toCloseList = DB.selectToList(selectSql, null, HrisRemindBean.class, mainPortalConn);
			System.out.println("The size of toCloseList: "+toCloseList.size());
			for(Iterator it = toCloseList.iterator();it.hasNext();){
				HrisRemindBean eachBean = (HrisRemindBean)it.next();
				String[] closeDateArr = eachBean.getSend_time().split("-");
				Calendar sysCal = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String sysDateStr = sdf.format(sysCal.getTime());
				System.out.println("System Date: " + sysDateStr);
				System.out.println("Close Date for " + eachBean.getP_id() + " " + eachBean.getSend_time());
//				if(sysCal.get(Calendar.YEAR)==Integer.parseInt(closeDateArr[0])&&sysCal.get(Calendar.MONTH)+1==Integer.parseInt(closeDateArr[1])
//				   &&sysCal.get(Calendar.DATE)==Integer.parseInt(closeDateArr[2])){
				if(sysDateStr.equals(eachBean.getSend_time())){
					int i = 0,j = 0;
					i = DB.updateSQL(updateSql, new Object[]{eachBean.getComid(),eachBean.getP_id()}, mainPortalConn);
					if(i==1){
						System.out.println("users table has been updated for "+eachBean.getP_id()+" of "+" Company "+eachBean.getComid());
					}else{
						System.out.println("failed to update users table for"+eachBean.getP_id()+" of "+" Company "+eachBean.getComid());
					}
					j = DB.updateSQL(updateSql2, new Object[]{eachBean.getSubject(),eachBean.getP_id()}, mainPortalConn);
					if(j==1){
						System.out.println("terminated_user_status table has been updated for "+eachBean.getP_id()+" of "+" Company "+eachBean.getComid());
					}else{
						System.out.println("failed to update terminated_user_status table for"+eachBean.getP_id()+" of "+" Company "+eachBean.getComid());
					}
//					System.out.println("Close user access for "+eachBean.getP_id()+" of "+" Company "+eachBean.getComid());
				}
			}
//			mainPortalConn.commit();
//			System.out.println("...Changes Commit...");
//			mainPortalConn.setAutoCommit(true);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				if(null != mainPortalConn){
					mainPortalConn.close();
					System.out.println("...Close mainportal conection...");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
