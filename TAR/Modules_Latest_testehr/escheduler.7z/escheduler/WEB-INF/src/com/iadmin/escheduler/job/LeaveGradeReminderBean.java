package com.iadmin.escheduler.job;

import java.math.BigDecimal;

public class LeaveGradeReminderBean {

	private BigDecimal clientId;
	private String clientName;
	private String emails;
	private String parameter;
	public BigDecimal getClientId() {
		return clientId;
	}
	public void setClientId(BigDecimal clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getEmails() {
		return emails;
	}
	public void setEmails(String emails) {
		this.emails = emails;
	}
	
	public String getTitle() {
		return "Information for eLeave System";
	}
	
	public String getParameter() {
		return parameter;
	}
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + clientId.intValue();
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LeaveGradeReminderBean other = (LeaveGradeReminderBean) obj;
		if (clientId.intValue() != other.clientId.intValue())
			return false;
		return true;
	}


	
}

