package com.iadmin.escheduler.job;

import java.util.Date;

public class PayScheduleReminderBean {
	
	private String comid;
	private String reminder;
	private String payyear;
	private String paymonth;
	private String batch;
	private Date reminderDate;
	private String templateFile;
	private String subject;
	private String fromAddress;
	private String toStr;
	private String ccStr;
	private String parameter;
	
	/**
	 * @return the comid
	 */
	public String getComid() {
		return comid;
	}
	/**
	 * @param comid the comid to set
	 */
	public void setComid(String comid) {
		this.comid = comid;
	}
	/**
	 * @return the reminder
	 */
	public String getReminder() {
		return reminder;
	}
	/**
	 * @param reminder the reminder to set
	 */
	public void setReminder(String reminder) {
		this.reminder = reminder;
	}
	/**
	 * @return the payyear
	 */
	public String getPayyear() {
		return payyear;
	}
	/**
	 * @param payyear the payyear to set
	 */
	public void setPayyear(String payyear) {
		this.payyear = payyear;
	}
	/**
	 * @return the paymonth
	 */
	public String getPaymonth() {
		return paymonth;
	}
	/**
	 * @param paymonth the paymonth to set
	 */
	public void setPaymonth(String paymonth) {
		this.paymonth = paymonth;
	}
	/**
	 * @return the batch
	 */
	public String getBatch() {
		return batch;
	}
	/**
	 * @param batch the batch to set
	 */
	public void setBatch(String batch) {
		this.batch = batch;
	}
	/**
	 * @return the reminderDate
	 */
	public Date getReminderDate() {
		return reminderDate;
	}
	/**
	 * @param reminderDate the reminderDate to set
	 */
	public void setReminderDate(Date reminderDate) {
		this.reminderDate = reminderDate;
	}
	/**
	 * @return the templateFile
	 */
	public String getTemplateFile() {
		return templateFile;
	}
	/**
	 * @param templateFile the templateFile to set
	 */
	public void setTemplateFile(String templateFile) {
		this.templateFile = templateFile;
	}
	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}
	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}
	/**
	 * @return the fromAddress
	 */
	public String getFromAddress() {
		return fromAddress;
	}
	/**
	 * @param fromAddress the fromAddress to set
	 */
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}
	/**
	 * @return the toStr
	 */
	public String getToStr() {
		return toStr;
	}
	/**
	 * @param toStr the toStr to set
	 */
	public void setToStr(String toStr) {
		this.toStr = toStr;
	}
	/**
	 * @return the ccStr
	 */
	public String getCcStr() {
		return ccStr;
	}
	/**
	 * @param ccStr the ccStr to set
	 */
	public void setCcStr(String ccStr) {
		this.ccStr = ccStr;
	}
	/**
	 * @return the parameter
	 */
	public String getParameter() {
		return parameter;
	}
	/**
	 * @param parameter the parameter to set
	 */
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	
}
