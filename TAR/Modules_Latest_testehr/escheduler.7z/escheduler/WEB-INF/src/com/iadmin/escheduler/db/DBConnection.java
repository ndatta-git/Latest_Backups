package com.iadmin.escheduler.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBConnection {
	
	public static Connection getSSOConnection(String database){

		Connection conn = null;

		//obtain the context of the servlet container
		Context ctx = null;
		DataSource ds = null;
		Context initContext = null;
		Context envContext = null;
		try {
			ctx = new InitialContext();
		
			if (ctx == null) return conn;

			initContext = new InitialContext();
			envContext  = (Context)initContext.lookup("java:/comp/env");
			//look up a datasource
			ds = (DataSource)envContext.lookup(database);
			
		} catch(NamingException e){
			System.out.println("Cannot get context: Naming Exception: ");
		}
		
		//get the connection from the datasource
		try {
			conn = ds.getConnection();
		} catch (SQLException e){
			System.out.println("Cannot get SSO Connection");
		}
		
		try {
			if (envContext!=null) envContext.close();
			if (initContext!=null) initContext.close();
		} catch(NamingException e){
			System.out.println("Cannot close context:");
		}
		
		if (conn==null) {
			System.out.println("Cannot get sso connection because it is null");
		}

		return conn;
	}

}
