package com.iadmin.escheduler.job;

import java.beans.Statement;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.commons.dbutils.ResultSetHandler;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;



import com.iadmin.escheduler.bean.HrisSchedulerBean;
import com.iadmin.escheduler.bean.LabelDateBean;
import com.iadmin.escheduler.db.DBConnection;

import catalog.connection.ConnectionPool;
import catalog.db.QueryRunnerExt;
import catalog.model.ValueLabelBean;
import catalog.utility.CR;
import catalog.utility.DB;

public class HrisFilterJob implements Job {
	private ConnectionPool cp;
	private Connection conn;
	private Connection compConn;
	private java.sql.PreparedStatement pstm;
	private String comid ;
	private String db_name;

	
	public HrisFilterJob(){
		cp = new ConnectionPool();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		
	}

	public void execute(JobExecutionContext arg0) throws JobExecutionException {
			
			System.out.println("################################################################\n"+new Date() + "#########################################################");
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			Date currentTime = new Date();
			Calendar curr = Calendar.getInstance();
			curr.setTime(currentTime);
			curr.set(Calendar.HOUR, 0);
			curr.set(Calendar.MINUTE, 0);
			curr.set(Calendar.SECOND, 0);
			int currYear = curr.get(Calendar.YEAR);
			int currMonth = curr.get(Calendar.MONTH) + 1 ; //month is begin from 0
			int currDate = curr.get(Calendar.DATE);
			
			int valueYear = 0;
			int valueMonth = 0;
			int valueDate = 0;
			
			
			String sql = "";
			String insertSql = "insert into hris_scheduler_record values (?,?,?,?,?,?,?)";
			conn = DBConnection.getSSOConnection("ehr_schedule");
			System.out.println("ehr_schedule connection successfully (filter job)");
//			List test = DB.selectToList("select * from TEST", new Object[]{}, String.class, conn);
			// get comid & db_name from ehr_schedule module
			List runComList = null;
			try {
				runComList = DB.selectToList("select comid as label, db_name as value from scheduler_mapping where scheduler_type = 'hris_scheduler_reminder'", new Object[]{}, ValueLabelBean.class, conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(0);
			} finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
			Iterator it = runComList.iterator();
			
			while(it.hasNext()){
				ValueLabelBean vlb = (ValueLabelBean) it.next();
				comid = vlb.getLabel();
				db_name = vlb.getValue();
				
				try {
					compConn =  DBConnection.getSSOConnection(db_name);
					System.out.println(db_name + " connection successfully (filter job)");
					pstm = compConn.prepareStatement("insert into hris_scheduler_record values(?,?,?,?,?,?,?)");
				
				compConn.setAutoCommit(false);
				sql = "select comid,to_char(scheduler_id) scheduler_id,sche_description,to_char(status) status,to_char(schedule_type) schedule_type,to_char(table_type) table_type,table_name,column_name,unit,to_char(amount) amount,send_time,template_name,sender,to_address,cc_address," +
						"subject,to_char(sendto_employee) sendto_employee,para_name, to_char(anniversary_year) anniversary_year from hris_scheduler where comid = ? and status = 1";
				// get all scheduler to a list
				List schedulerList = DB.selectToList(sql, new Object[]{comid}, HrisSchedulerBean.class, compConn);
				Iterator sl = schedulerList.iterator();
				while(sl.hasNext()){
					HrisSchedulerBean hsb = (HrisSchedulerBean) sl.next();
					String getDateSql = "";
					List empList =null;	
					if("1".equals(hsb.getTable_type())){
							getDateSql = "select tb.p_id label,tb."+ hsb.getColumn_name() + " value from " + hsb.getTable_name() +" tb,v_hris_job_latest v where tb.p_id = v.p_id and v.job_action <> 5";
							empList = DB.selectToList(getDateSql, new Object[]{}, LabelDateBean.class, compConn);
					}else if("2".equals(hsb.getTable_type())){
							getDateSql = "select tb.p_id label,tb.value value from " + hsb.getTable_name() + " tb,v_hris_job_latest v where tb.comp_id = ? and tb.field_id = ? and tb.p_id = v.p_id and v.job_action <> 5";
							empList = DB.selectToList(getDateSql, new Object[]{ comid, hsb.getColumn_name()}, ValueLabelBean.class, compConn);
					}
							Iterator empIt = empList.iterator();
								while(empIt.hasNext()){
									String paraString = "";
									String p_id = "";
									Date date = null;
									Date saveDate = null;
									Date originalDate = null;
									LabelDateBean  ldb = null;
									ValueLabelBean vlb1 = null;
									Calendar eeCal = Calendar.getInstance();
									if("1".equals(hsb.getTable_type())){
										ldb = (LabelDateBean) empIt.next();	
										p_id = ldb.getLabel();
										date = ldb.getValue();
										originalDate = date;
									}else if("2".equals(hsb.getTable_type())){
										vlb1 = (ValueLabelBean)empIt.next();
										p_id = vlb1.getLabel();
										if(p_id.equals("W00780")){
										p_id = vlb1.getLabel();
										}	try {
											date = sdf1.parse(vlb1.getValue());
										} catch (ParseException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
										originalDate = date;
									}
//										System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(date));
										if("1".equals(hsb.getSchedule_type())){
											eeCal.setTime(date);
										}else if("2".equals(hsb.getSchedule_type())){
											eeCal.setTime(date);
											eeCal.set(Calendar.YEAR, currYear);
										}
											if(hsb.getAnniversary_year()!=null){
												eeCal.add(Calendar.YEAR, Integer.parseInt(hsb.getAnniversary_year()));
												saveDate = eeCal.getTime();
											}
											
											if("D".equals(hsb.getUnit())){
												eeCal.add(Calendar.DATE, -Integer.parseInt(hsb.getAmount()));
											}else if("M".equals(hsb.getUnit())){
												eeCal.add(Calendar.MONTH,-Integer.parseInt(hsb.getAmount()));
											}else if("W".equals(hsb.getUnit())){
												eeCal.add(Calendar.WEEK_OF_YEAR, -Integer.parseInt(hsb.getAmount()));
											}else{
												eeCal.add(Calendar.YEAR, -Integer.parseInt(hsb.getAmount()));
											}
											valueYear = eeCal.get(Calendar.YEAR);
											valueMonth = eeCal.get(Calendar.MONTH) + 1 ; //month is begin from 0
											valueDate = eeCal.get(Calendar.DATE);
											
											if(("1".equals(hsb.getSchedule_type())&&currYear == valueYear && currMonth == valueMonth && currDate == valueDate)||("2".equals(hsb.getSchedule_type())&&currMonth == valueMonth && currDate == valueDate)){
												if("2".equals(hsb.getSchedule_type())){
													Calendar temp = Calendar.getInstance();
													temp.setTime(saveDate);
													if(valueYear < currYear){
														temp.set(Calendar.YEAR, currYear + 1);
														saveDate = temp.getTime();
													}
												}
												String param = hsb.getPara_name();
												String []everyParam = param.split("##");
												String tableName = "";
												String columnName = "";
												String insertParamValue = "";
												for(int i = 0;i<everyParam.length;i++){
													 String addValue = "";
													 if("REMINDER_DATE".equals(everyParam[i])){
														 addValue = "##" + sdf.format(saveDate);
														 paraString = paraString + addValue;
														 continue;
													 }
													 if("ORIGINAL_DATE".equals(everyParam[i])){
														 addValue = "##" + sdf.format(originalDate);
														 paraString = paraString + addValue;
														 continue;
													 }
													 String []para = everyParam[i].split("\\$");
													 if(para.length>1){
													 if(para[0]!= null&&para[1]!=null){
														 tableName = para[0];
														 columnName = para[1];
														 String innerSql = "select "+columnName+" from "+tableName+" where p_id = ?";
														 List value = DB.selectToList(innerSql, new Object[]{p_id},String.class,compConn);
														 
														 for(int j = 0;j<value.size();j++){
															 Object temp = value.get(j);
															 if(null == temp){
																 break;
															 }
															 if(temp instanceof java.util.Date){
																 addValue = sdf.format(temp);
															 }else{
																 addValue = temp.toString();
															 }
														 }
														 if(CR.isNNNE(addValue)){
															 paraString = paraString + "##" + addValue;
														 }else{
															 paraString = paraString + "##" + "N/A"; 
														 }
														 
													 }
													 }
												}
												String unit = hsb.getUnit();
												String unitAmt = hsb.getAmount();
												String unitDesc = "";
												switch(unit.charAt(0)){
													case 'Y': unitDesc = "Year(s)";break;
													case 'M': unitDesc = "Month(s)";break;
													case 'D': unitDesc = "Day(s)";break;
													case 'W': unitDesc = "Week(s)";break;
												
												}
												if(paraString.startsWith("##")){
													paraString = paraString.substring(2);
												}
												paraString = unitAmt + "##" + unitDesc + "##" + paraString;
												pstm.setString(1, comid);
												pstm.setInt(2, Integer.parseInt(hsb.getScheduler_id()));
												pstm.setString(3, p_id);
												pstm.setDate(4, new java.sql.Date(currentTime.getTime()));
//												Date st = hsb.getSend_time();
//												SimpleDateFormat sdf1 = new SimpleDateFormat("hh:mm:ss");
												pstm.setString(5, hsb.getSend_time());
												pstm.setInt(6, 0);
												pstm.setString(7, paraString);
												pstm.addBatch();
											}
										}
					}
					pstm.executeBatch();
					compConn.commit();
					compConn.close();
					System.out.println(comid + " has been filtered successfully");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally{
					if(compConn!=null){
						try {
							compConn.close();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
	}
	}
}
