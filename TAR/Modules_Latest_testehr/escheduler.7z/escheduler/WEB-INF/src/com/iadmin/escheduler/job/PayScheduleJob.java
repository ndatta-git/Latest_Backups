/**
 * Created on Sep 25, 2009
 */

package com.iadmin.escheduler.job;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationFactory;
import org.quartz.Job;
import org.quartz.JobExecutionContext;

import catalog.utility.DB;

import com.iadmin.escheduler.db.DBConnection;

/**
 * Job Reminder
 * 
 * @author zaza.shen
 */
public class PayScheduleJob implements Job {

	Connection dbConn;
	Connection dbConnMainportal;
	String months[] = new String [] {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	
	public PayScheduleJob() {
	}

	public void execute(JobExecutionContext context) {
		try {
			Calendar cal = Calendar.getInstance();
			Date systemDate = cal.getTime();
			SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm");
			String sysTime = sdfTime.format(systemDate);
			
			ConfigurationFactory factory = new ConfigurationFactory("config.xml");
			Configuration config = factory.getConfiguration();
			String mailHost = config.getString("mail.default.mailHost");
			
			dbConn = DBConnection.getSSOConnection("ehr_schedule");
			dbConnMainportal = DBConnection.getSSOConnection("mainportal");
			String sqlGetTime = "select t.jid from daily_schedule t where t.runtime = ?";
			String jid = DB.selectToString(sqlGetTime, new Object[] {sysTime}, dbConn);
			
			if (jid != null && !"".equals(jid.trim())) {
				
				String sql ="select t.comid,\n" +
							"       t.reminder,\n" + 
							"       t.payyear,\n" + 
							"       t.paymonth,\n" + 
							"       t.batch,\n" + 
							"       t.rmd_date reminderDate,\n" + 
							"       t.email_template templateFile,\n" + 
							"       t.subject,\n" + 
							"       t.from_address fromAddress,\n" + 
							"       t.to_address toStr,\n" + 
							"       t.cc_list ccStr,\n" + 
							"       t.parameter\n" + 
							"  from pay_schedule t\n" +
							" where t.jid = ?\n" +
							"   and t.status <> 1\n" +
							"   and t.locked_flag <> 1";

				List beanList = DB.selectToList(sql, new Object[] {jid}, PayScheduleReminderBean.class, dbConn);
				
				sql = "select t.description from client t where t.client_name = ?";

				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String sysDate = sdf.format(systemDate);
				
				for (int i = 0; i < beanList.size(); i++) {
					PayScheduleReminderBean bean = (PayScheduleReminderBean)beanList.get(i);
					String reminderDate = sdf.format(bean.getReminderDate());
					
					String payYear = bean.getPayyear();
					String payMonth = bean.getPaymonth();
					
					payMonth = months[Integer.parseInt(payMonth) - 1];
					
					bean.setSubject(bean.getSubject()+ " for " + payMonth + "-" + payYear);
					
					if (sysDate.equals(reminderDate)) {
						System.out.println("=======email send start========Time : " + cal.getTime());
						
						String comid = bean.getComid();
						String companyName = DB.selectToString(sql, new Object[]{comid}, dbConnMainportal);
						bean.setSubject(bean.getSubject() + " (" + companyName + ")");
						EmailSender sender = new EmailSender();
						boolean sendSuccess = sender.sendEmail(bean, mailHost);
						
						if (sendSuccess) {
							// if mail is sent successfully, table pay_schedule will update column status into 1
							String reminder = bean.getReminder();
							String payyear = bean.getPayyear();
							String paymonth = bean.getPaymonth();
							String batch = bean.getBatch();
							
							String sqlUpdateStatus ="update pay_schedule t\n" +
													"set t.status = 1\n" + 
													"where t.comid = ?\n" + 
													"  and t.reminder = ?\n" + 
													"  and t.payyear = ?\n" + 
													"  and t.paymonth = ?\n" + 
													"  and t.batch = ?";
							DB.updateSQL(sqlUpdateStatus, new Object[] {comid, reminder, payyear, paymonth, batch}, dbConn);
						}
						System.out.println("=======email send end========Time : " + cal.getTime());
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (dbConn != null) {
				try {
					dbConn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (dbConnMainportal != null) {
				try {
					dbConnMainportal.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}
}
