package com.iadmin.escheduler.bean;

import java.util.Date;

public class HrisRemindBean {
	private String comid;
	private String scheduler_id;
	private String p_id;
	private Date send_date;
	private String send_time;
	private int status;
	private String para_value;
	private String subject;
	private String sender;
	private String to_address;
	private String cc_address;
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getTo_address() {
		return to_address;
	}
	public void setTo_address(String toAddress) {
		to_address = toAddress;
	}
	public String getCc_address() {
		return cc_address;
	}
	public void setCc_address(String ccAddress) {
		cc_address = ccAddress;
	}
	public String getTemplate_name() {
		return template_name;
	}
	public void setTemplate_name(String templateName) {
		template_name = templateName;
	}
	public String getSendto_employee() {
		return sendto_employee;
	}
	public void setSendto_employee(String sendtoEmployee) {
		sendto_employee = sendtoEmployee;
	}
	private String template_name;
	private String sendto_employee;
	
	public HrisRemindBean(){
		String comid = null;
		String scheduler_id = null;
		String p_id = null;
		Date send_date = null;
		String send_time = null;
		int status = 0;
		String para_value = null;
	}
	public String getComid() {
		return comid;
	}
	public void setComid(String comid) {
		this.comid = comid;
	}
	public String getScheduler_id() {
		return scheduler_id;
	}
	public void setScheduler_id(String schedulerId) {
		scheduler_id = schedulerId;
	}
	public String getP_id() {
		return p_id;
	}
	public void setP_id(String pId) {
		p_id = pId;
	}
	public Date getSend_date() {
		return send_date;
	}
	public void setSend_date(Date sendDate) {
		send_date = sendDate;
	}
	public String getSend_time() {
		return send_time;
	}
	public void setSend_time(String sendTime) {
		send_time = sendTime;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getPara_value() {
		return para_value;
	}
	public void setPara_value(String paraValue) {
		para_value = paraValue;
	}
	
	

}
