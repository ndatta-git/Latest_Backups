package com.iadmin.escheduler.job;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.iadmin.escheduler.bean.HrisRemindBean;
import com.iadmin.escheduler.db.DBConnection;

import catalog.connection.ConnectionPool;
import catalog.model.ValueLabelBean;
import catalog.utility.CR;
import catalog.utility.DB;

public class HrisReminderJob implements Job {
	
	private ConnectionPool cp;
	private Connection conn;
	private Connection compConn;
	private java.sql.PreparedStatement pstm;
	private String comid ;
	private String db_name;
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm");
		SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy");
		Date currentTime = new Date();
		String currentTimeStr = sdf2.format(currentTime);
		Calendar curr = Calendar.getInstance();
		curr.setTime(currentTime);
		curr.set(Calendar.HOUR, 0);
		curr.set(Calendar.MINUTE, 0);
		curr.set(Calendar.SECOND, 0);
		int currYear = curr.get(Calendar.YEAR);
		int currMonth = curr.get(Calendar.MONTH) + 1 ; //month is begin from 0
		int currDate = curr.get(Calendar.DATE);
		
		int valueYear = 0;
		int valueMonth = 0;
		int valueDate = 0;
		Date fireTime = arg0.getFireTime();
		String fireTimeStr = sdf1.format(fireTime);
		System.out.println(fireTimeStr);
		
		cp = new ConnectionPool();
			conn = DBConnection.getSSOConnection("ehr_schedule");
			System.out.println("ehr_schedule connection successfully (reminder job)");
			List runComList = null;
			try {
				runComList = DB.selectToList("select comid as label, db_name as value from scheduler_mapping where scheduler_type = 'hris_scheduler_reminder'", new Object[]{}, ValueLabelBean.class, conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
			Iterator it = runComList.iterator();
			while(it.hasNext()){
				ValueLabelBean vlb = (ValueLabelBean)it.next();
				comid = vlb.getLabel();
				db_name = vlb.getValue();
				try {
				compConn = DBConnection.getSSOConnection(db_name);
				System.out.println(db_name + " connection successfully (reminder job)");
				String sendSql = 	"select r.comid, to_char(r.scheduler_id) scheduler_id, r.p_id, r.send_date, r.send_time, r.para_value,s.template_name,s.sender,s.to_address,s.cc_address,s.subject,to_char(s.sendto_employee) sendto_employee\n" +
									"  from hris_scheduler_record r, hris_scheduler s\n" + 
									" where r.send_date = to_date(?, 'mm/dd/yyyy')\n" + 
									"   and r.send_time = ?\n" + 
									"   and s.scheduler_id = r.scheduler_id\n" + 
									"   and r.status = '0'";
				String updateSql = "";
				String empEmail = "";
				List sendList;
				
					sendList = DB.selectToList(sendSql, new Object[]{currentTimeStr,"9:00" }, HrisRemindBean.class, compConn);
			
				Iterator itSend = sendList.iterator();
				while(itSend.hasNext()){
					HrisRemindBean hrb = (HrisRemindBean) itSend.next();
					if("1".equals(hrb.getSendto_employee())){
						empEmail = DB.selectToString("select work_email from hris_emp where p_id = ?", new Object[]{hrb.getP_id()}, compConn);
						if(CR.isNNNE(empEmail)){
							String temp = "";
							if(CR.isNNNE(hrb.getCc_address())){
								temp = hrb.getCc_address().concat(";"+empEmail);
							}else{
								temp = empEmail;
							}
							hrb.setCc_address(temp);
						}
					}
					HrisEmailSender sender = new HrisEmailSender();
					boolean sendSuccess = sender.sendEmail(hrb);
					
					if (sendSuccess) {
						System.out.println("###################################\n Mail Sent Successfully\n****************************************");
						updateSql = "update hris_scheduler_record set status = 1 where comid = ? and scheduler_id = ? and p_id = ? and send_date = ?";
						int i = DB.updateSQL(updateSql, new Object[]{hrb.getComid(),hrb.getScheduler_id(),hrb.getP_id(),hrb.getSend_date()}, compConn);
						if(i != -1){
							System.out.println("status changed");
						}
					}
				}
				System.out.println(comid + " has finished the handling ");
				compConn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally{
					if(compConn!=null){
						try {
							compConn.close();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		
	}

}
