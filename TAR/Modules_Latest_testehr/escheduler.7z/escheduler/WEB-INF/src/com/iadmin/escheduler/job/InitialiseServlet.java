/*
 * Copyright James House (c) 2001-2004
 * 
 * All rights reserved.
 *   
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met: 1.
 * Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer. 2. Redistributions in
 * binary form must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other
 * materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 */

package com.iadmin.escheduler.job;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationFactory;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.impl.StdSchedulerFactory;

import catalog.CatalogTemplate;
import catalog.connection.ConnectionPool;
import catalog.utility.DB;

import com.iadmin.escheduler.bean.HrisSchedulerBean;
import com.iadmin.escheduler.utility.ConfigUtil;

/**
 * <p>
 * A Servlet that can be used to initialize Quartz, if configured as a
 * load-on-startup servlet in a web application.
 * </p>
 * 
 * <p>
 * You'll want to add something like this to your WEB-INF/web.xml file:
 * 
 * <pre>
 *  &lt;servlet&gt; 
 *      &lt;servlet-name&gt;
 *          QuartzInitializer
 *      &lt;/servlet-name&gt; 
 *      &lt;display-name&gt;
 *          Quartz Initializer Servlet
 *      &lt;/display-name&gt; 
 *      &lt;servlet-class&gt;
 *          org.quartz.ee.servlet.QuartzInitializerServlet
 *      &lt;/servlet-class&gt; 
 *      &lt;load-on-startup&gt;
 *          1
 *      &lt;/load-on-startup&gt;
 *      &lt;init-param&gt;
 *          &lt;param-name&gt;config-file&lt;/param-name&gt;
 *          &lt;param-value&gt;/some/path/my_quartz.properties&lt;/param-value&gt;
 *      &lt;/init-param&gt;
 *      &lt;init-param&gt;
 *          &lt;param-name&gt;shutdown-on-unload&lt;/param-name&gt;
 *          &lt;param-value&gt;true&lt;/param-value&gt;
 *      &lt;/init-param&gt;
 *  &lt;/servlet&gt;
 * </pre>
 * </p>
 * The init parameter 'config-file' can be used to specify the path (and 
 * filename) of your Quartz properties file.  If you leave out this parameter, 
 * the default ("quartz.properties") will be used.
 * 
 * The init parameter 'shutdown-on-unload' can be used to specify whether you
 * want scheduler.shutdown() called when the servlet is unloaded (usually when
 * the application server is being shutdown).  Possible values are "true" or
 * "false".  The default is "true".
 * 
 * @author James House
 */
public class InitialiseServlet extends HttpServlet {

	private static final long serialVersionUID = -1190230871482404079L;
	
	private boolean performShutdown = true;
    private String payScheduleJob;
    private String hris_filter_time;
    private String hris_reminder_time;
    private String leaveGradeReminderJob;
    private String terminatedUserCloseJob;
    public void init( ServletConfig cfg ) throws javax.servlet.ServletException {
        super.init(cfg);
        
		//get template folder real path
		try {
			//Configure the template engine
			freemarker.template.Configuration templateCfg = new freemarker.template.Configuration();
			templateCfg.setDirectoryForTemplateLoading(new File(cfg.getServletContext().getRealPath("") + "/WEB-INF/template"));
			templateCfg.setTemplateUpdateDelay(2);			
			CatalogTemplate.setTemplateConfig(templateCfg);
		} catch (IOException e){
			e.printStackTrace();
		}

        log("Quartz Initializer Servlet loaded, initializing Scheduler...");
        
        StdSchedulerFactory factory;
        try {
        	String configFile = cfg.getInitParameter("config-file");
            String shutdownPref = cfg.getInitParameter("shutdown-on-unload");
            
            if(shutdownPref != null)
                this.performShutdown = Boolean.valueOf(shutdownPref).booleanValue();
                
            // get Properties
            if (configFile != null)
            {
                factory = new StdSchedulerFactory(configFile);
            }
            else
            {
                factory = new StdSchedulerFactory();
            }
    
            Scheduler scheduler = factory.getScheduler();
          
            /**
             * init scheduler time
             */
            ConfigurationFactory cf = new ConfigurationFactory(ConfigUtil.configPath);
			Configuration config = cf.getConfiguration();
			payScheduleJob     =       config.getString("pay_schedule_job");
			hris_filter_time = config.getString("hris_filter_job");
			hris_reminder_time = config.getString("hris_reminder_job");
			leaveGradeReminderJob = config.getString("leavegrade_reminder_job"); 
			terminatedUserCloseJob = config.getString("terminated_user_close_job");
			
			System.out.println("=============================================");
			System.out.println("            escheduler run time         ");
			System.out.println("     pay schedule job:        "+payScheduleJob);
			System.out.println("     hris filter job:        "+hris_filter_time);
			System.out.println("     hris reminder job:        "+hris_reminder_time);
			System.out.println("    leaveGradeReminderJob:        "+leaveGradeReminderJob);
			System.out.println("    terminatedUserCloseJob:        "+terminatedUserCloseJob);
			System.out.println("=============================================");
            //==================
			//Create job details
            //==================
			
			// Test Job
			JobDetail jobDetailPaySchedule = new JobDetail("PayScheduleJob", Scheduler.DEFAULT_GROUP, PayScheduleJob.class);
			JobDetail jobDetailHrisFilter = new JobDetail("HrisFilterJob", Scheduler.DEFAULT_GROUP, HrisFilterJob.class);
			JobDetail jobDetailHrisReminder = new JobDetail("HrisReminderJob", Scheduler.DEFAULT_GROUP, HrisReminderJob.class);
			JobDetail leaveGradeReminderSchedule = new JobDetail("leaveGradeReminderJob",Scheduler.DEFAULT_GROUP,LeaveGradeReminderJob.class);
			JobDetail terminatedUserCloseSchedule = new JobDetail("terminatedUserCloseJob",Scheduler.DEFAULT_GROUP,terminatedUserCloseJob.class);
			
			// Create trigger to activate job
			CronTrigger triggerPaySchedule = new CronTrigger("PayScheduleTrigger",Scheduler.DEFAULT_GROUP);
			CronTrigger triggerHrisFilter = new CronTrigger("HrisFilterTrigger", Scheduler.DEFAULT_GROUP);
			CronTrigger triggerHrisReminder = new CronTrigger("HrisReminderTrigger", Scheduler.DEFAULT_GROUP);
			CronTrigger triggerLeaveGradeSchedule = new CronTrigger("leaveGradeReminderTrigger",Scheduler.DEFAULT_GROUP);
			CronTrigger triggerTerminatedUserClose = new CronTrigger("terminatedUserCloseTrigger",Scheduler.DEFAULT_GROUP);
			
			//For Debugging purposes
			// Set time for trigger to run
			triggerPaySchedule.setCronExpression(payScheduleJob);
			triggerHrisFilter.setCronExpression(hris_filter_time);
			triggerHrisReminder.setCronExpression(hris_reminder_time);	
			triggerLeaveGradeSchedule.setCronExpression(leaveGradeReminderJob);
			triggerTerminatedUserClose.setCronExpression(terminatedUserCloseJob);
			
			scheduler.scheduleJob(jobDetailPaySchedule, triggerPaySchedule);
			scheduler.scheduleJob(jobDetailHrisFilter, triggerHrisFilter);
			scheduler.scheduleJob(jobDetailHrisReminder, triggerHrisReminder);
			scheduler.scheduleJob(leaveGradeReminderSchedule, triggerLeaveGradeSchedule);
			scheduler.scheduleJob(terminatedUserCloseSchedule,triggerTerminatedUserClose);
			scheduler.start();

          } catch (Exception e) {
              log("Quartz Scheduler failed to initialize: " + e.toString());
              throw new ServletException(e);
          }
    }

    public void destroy() {
        
        if( !this.performShutdown )
            return;
        
        try {
            Scheduler sched = StdSchedulerFactory.getDefaultScheduler();

            if (sched != null) sched.shutdown();
        } catch (Exception e) {
            log("Quartz Scheduler failed to shutdown cleanly: " + e.toString());
            e.printStackTrace();
        }

        log("Quartz Scheduler successful shutdown.");
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendError(HttpServletResponse.SC_FORBIDDEN);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendError(HttpServletResponse.SC_FORBIDDEN);
    }

}
