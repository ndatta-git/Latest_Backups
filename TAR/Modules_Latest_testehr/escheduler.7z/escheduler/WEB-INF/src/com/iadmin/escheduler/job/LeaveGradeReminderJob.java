package com.iadmin.escheduler.job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationFactory;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import catalog.concurrent.Result;
import catalog.utility.DB;

import com.iadmin.escheduler.db.DBConnection;

public class LeaveGradeReminderJob implements Job {
	
	Connection scheduleConn;
	Connection mainportalConn;
	public LeaveGradeReminderJob()
	{
		
	}

	public void execute(JobExecutionContext context) throws JobExecutionException {		

		try
		{
		System.out.println("LeaveGradeReminderJob fired at "+context.getFireTime());	
		scheduleConn = DBConnection.getSSOConnection("ehr_schedule");
		mainportalConn = DBConnection.getSSOConnection("mainportal");
        EmailSender emailSender = new EmailSender();
		ConfigurationFactory factory = new ConfigurationFactory("config.xml");
		Configuration config = factory.getConfiguration();
		String mailHost = config.getString("mail.default.mailHost");
        String sql ="select distinct cs.client_id clientId,c.client_name clientName from clientservice cs,client c" +
        		" where cs.client_id = c.client_id and " +
        		"exists(select * from clientservice cs2 where cs2.client_id=cs.client_id and cs2.service_id='003') and " +
        		"exists(select * from clientservice cs2 where cs2.client_id=cs.client_id and cs2.service_id='020') order by cs.client_id";       
		//get all clients with both etemplate and eleave module enabled
        List<LeaveGradeReminderBean> totalClientList  = DB.selectToList(sql,new Object[]{}, LeaveGradeReminderBean.class, mainportalConn);
       
        sql = "select client_id clientId,emails from leavegrade_reminder order by client_id";
        //get these clients which are configured in ehr_schedule
        List<LeaveGradeReminderBean> configuredClientList  = DB.selectToList(sql,new Object[]{}, LeaveGradeReminderBean.class, scheduleConn);

        //store the clients that are eligible for receiving reminder emails
        List<LeaveGradeReminderBean> availableClientList = new ArrayList<LeaveGradeReminderBean>();
        //calendar object that represents current date
        GregorianCalendar currentCalendar  = new GregorianCalendar();
        //check eligible clients
        if(totalClientList.size()>0 && configuredClientList.size()>0)
        {
        for(LeaveGradeReminderBean reminderBean:configuredClientList)
        {
        	int index = totalClientList.indexOf(reminderBean);
        	if(index != -1)
        	{
        		LeaveGradeReminderBean reminderBeanInTotal = totalClientList.get(index);
        		if(getSendFlag(getRemindCalendar(currentCalendar.get(Calendar.YEAR), currentCalendar.get(Calendar.MONTH)+1, reminderBeanInTotal.getClientName()),
        				currentCalendar))
        		{
        		reminderBean.setClientName(reminderBeanInTotal.getClientName());	
        		availableClientList.add(reminderBean);
        		}
        	}
        }
    
      for(int i=0;i<availableClientList.size();i++)
      {
    	  LeaveGradeReminderBean reminderBean = availableClientList.get(i);
    	 System.out.println("start sending email to "+reminderBean.getClientName());
    	 try
    	 {
    	 emailSender.sendEmail(reminderBean, mailHost); 	   	 
    	 }catch (Exception e) {
			e.printStackTrace();
			 System.out.println("Error when sending email to "+reminderBean.getClientName());	
			continue;
		}
    	 System.out.println("finish sending email to "+reminderBean.getClientName());
      } 
      
        }    
        
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}finally
		{
			try
			{
			 mainportalConn.close();
			  scheduleConn.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	//get certain client's payroll cut-off remind date
	private GregorianCalendar getRemindCalendar(int payyear,int paymonth,String comId)
	{
		String sql = "select rmd_date from pay_schedule where comid=? and payyear=? and paymonth=? and reminder='payroll_cutoff'";
		java.sql.Date remindDate =null;
		GregorianCalendar remindCalendar = null;
		try {
			PreparedStatement ps = scheduleConn.prepareStatement(sql);
			ps.setString(1, comId);
			ps.setString(2, new Integer(payyear).toString());
			ps.setString(3, new Integer(paymonth).toString());
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				remindDate = rs.getDate(1);
			}
			rs.close();
			ps.close();
			if(remindDate != null)
			{ 
			remindCalendar = new GregorianCalendar();
			remindCalendar.setTimeInMillis(remindDate.getTime());
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return remindCalendar;
	}
	
	//decide whether system should to send email to certain client
	private boolean getSendFlag(GregorianCalendar remindCalendar,GregorianCalendar currentCalendar)
	{
		if(remindCalendar == null)
		{
			return false;
		}
		//use tempCalendar as send date
		GregorianCalendar tempCalendar = (GregorianCalendar)remindCalendar.clone();
		//send email one day before payroll cut-off date
		tempCalendar.add(Calendar.DATE, -1);
	   //if that day is Saturday,pull back one more day
	   if(tempCalendar.get(Calendar.DAY_OF_WEEK)==7)
	   {
		   tempCalendar.add(Calendar.DATE, -1) ;  
	   }
	   //if that day is Sunday,pull back two more days
	   if(tempCalendar.get(Calendar.DAY_OF_WEEK)==1)
	   {
		   tempCalendar.add(Calendar.DATE, -2);
	   }
	   //if the month of temp calendar has changed,then the send date should be set to original remind date
	   if(tempCalendar.get(Calendar.MONTH) != currentCalendar.get(Calendar.MONTH))
	   {
		   tempCalendar = remindCalendar;
	   }
	   //if send date is exactly the day which current calendar represents, then the email should be sent
		if(tempCalendar.get(Calendar.YEAR) == currentCalendar.get(Calendar.YEAR) && tempCalendar.get(Calendar.MONTH)== currentCalendar.get(Calendar.MONTH)
			&& tempCalendar.get(Calendar.DAY_OF_MONTH) == currentCalendar.get(Calendar.DAY_OF_MONTH) )
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
//	public static void main(String args[])
//	{
//		GregorianCalendar c = new GregorianCalendar();
//		GregorianCalendar cc = (GregorianCalendar)c.clone();
//		cc.set(2011,0, 1);
//		cc.set(Calendar.DATE, -1);
//		System.out.println(cc.getTime());
//		System.out.println(c.getTime());
//	}

}
