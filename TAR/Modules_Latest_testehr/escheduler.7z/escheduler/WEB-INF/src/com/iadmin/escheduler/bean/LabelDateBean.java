package com.iadmin.escheduler.bean;

import java.util.Date;

public class LabelDateBean {
	
	private String Label;
	private Date value;
	public LabelDateBean(){
		Label = "";
		value = new Date();
	}
	public String getLabel() {
		return Label;
	}
	public void setLabel(String label) {
		Label = label;
	}
	public Date getValue() {
		return value;
	}
	public void setValue(Date value) {
		this.value = value;
	}
	
	

}
